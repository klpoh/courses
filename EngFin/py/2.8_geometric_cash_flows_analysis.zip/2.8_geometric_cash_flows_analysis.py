# -*- coding: utf-8 -*-
# 2.8_Geometric_Cash_Flows_analysis.py
""" 2.8 Geometric Cash Flow series analsyis using GeomCashFlows class """
from EngFinancialPy import GeomCashFlows

# Geometric cash flows example in Section 2.2.9
i  = 0.25
f  = 0.20
A1 = 1000
N = 4

# Create a Geometric cash flow series
GCF = GeomCashFlows(i, N, A1, f)

# Determine its equivalent P, A, F and G values
print(f"P = {GCF.P:,.2f}")
print(f"A = {GCF.A:,.2f}")
print(f"F = {GCF.F:,.2f}")
print(f"G = {GCF.G:,.2f}")

# Get the parameters
print(GCF.params)

