# -*- coding: utf-8 -*-
# 3.2.2_capital_recovery_amount.py
""" 3.2.2 Capital Recovery Amount """
from EngFinancialPy import CR
import numpy_financial as npf

""" Example (3.2.2)
    Consider an investment on a machine with initial Cost = $10,000, 
    salvage vallue = $2,000 and life = 5 years.  What equivaelnt uniform
    annual benfits must the investment provides for it to be financially
    feasible if the marr is 10%
"""
I = 10_000
SV = 2_000
N = 5
marr = 0.1

# Using CR function
cr = CR(I, SV, marr, N)
print(f"Capital Recovery Amount = {cr:,.2f}")

# Using npf.pmt function directly
cr = -npf.pmt(marr, N, I, -SV)
print(f"Capital Recovery Amount = {cr:,.2f}")