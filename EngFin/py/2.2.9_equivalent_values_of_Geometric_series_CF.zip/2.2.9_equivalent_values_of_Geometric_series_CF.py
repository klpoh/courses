# -*- coding: utf-8 -*-
# 2.2.9_equivalent_values_of_Geometric_series_CF.py
"""  2.2.9 Equivalent values of Geometric series cash flows """
from EngFinancialPy import GeomCashFlows, IntFactor

""" Example (2.2.9)
Find the equivalent present value of the following cash flows
if the interest rate is 25% per year:
    EoY   0  1     2          3            4
    CF    0  1000  1000(1.2)  1000(1.2)^2  1000(1.2)^3
"""
# Parameters
i  = 0.25
f  = 0.20
A1 = 1000
N = 4

# Using GeomCashFlows class
geomCF = GeomCashFlows(i, N, A1, f)
P = geomCF.P
print(f"Equivalent PV = {P:,.2f}")


# Using interest factor formulas
P = A1*(1 - IntFactor('P','F',i,N).value    \
          * IntFactor('F','P',f,N).value)   \
       / (i - f) 
print(f"Equivalent PV = {P:,.2f}")

