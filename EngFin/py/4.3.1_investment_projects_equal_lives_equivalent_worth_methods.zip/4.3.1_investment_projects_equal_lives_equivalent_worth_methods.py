# -*- coding: utf-8 -*-
# 4.3.1_investment_projects_equal_lives_equivalent_worth_methods.py
""" 4.3.1 Investments with Equal Lives - Equivalent Worth methods """
from EngFinancialPy import Project_CF, PnAF_cf, Evaluate_Projects

# Project basic parameters 
marr = 0.1
study_period = 10

# Create the alternatives
Proj_A = Project_CF(marr=marr, name="Investment A")
Proj_A.set_cf(PnAF_cf(Nper=study_period, P=-390000, A=69000, F=0))
 
Proj_B = Project_CF(marr=marr, name="Investment B")
Proj_B.set_cf(PnAF_cf(Nper=study_period, P=-920000, A=167000, F=0))
                       
Proj_C = Project_CF(marr=marr, name="Investment C")
Proj_C.set_cf(PnAF_cf(Nper=study_period, P=-660000, A=133500, F=0))

# To be included for investment altnatives evaluation
Do_nothing = Project_CF(marr=marr, name="Do nothing")
Do_nothing.set_cf(PnAF_cf(Nper=study_period))

# List of alternatives to be evaluated
Alternatives = [Proj_A, Proj_B, Proj_C, Do_nothing]

# Evaluate the alternatives using different equivalent worth methods
for method in ["PW", "AW", "FW"]:
    best = Evaluate_Projects(Alternatives, marr=marr, method=method)
    print(f"\nChoose alternative {best.name}")
                

