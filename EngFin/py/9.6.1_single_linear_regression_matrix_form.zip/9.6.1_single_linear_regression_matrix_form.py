# -*- coding: utf-8 -*-
# 9.6.1_single_linear_regression_matrix_form.py
""" 9.6.1  Single Variable Linear Regression Example """
import numpy as np
import matplotlib.pyplot as plt

# The data
X = np.array([[1,  400],
              [1,  530],
              [1,  750],
              [1,  900],
              [1, 1130],
              [1, 1200]])
        
y = np.array([278, 414, 557, 689, 740, 851])

# Plot the data
fig, ax = plt.subplots()
ax.plot(X[:,1], y, 'ro')
ax.set_xlabel('Weight')
ax.set_ylabel('Cost')
ax.grid()
plt.show()

# Number of observations and parameters
nobs, npar = np.shape(X)

# Compute X'X matrix
XtX = np.dot(X.T, X)
print("X'X Matrix = ")
print(XtX)

# Compute X'y vector
Xty = np.dot(X.T, y)
print(f"X'y vector = {Xty}")

# Compute beta = (X'X)^{-1} X'y
beta = np.dot(np.linalg.inv(XtX),Xty)
print(f"Fitted coefficients: {beta}")

# Compute predicted y values
yhat = np.dot(X, beta)
# Compute residues
e = (y - yhat)
SSRes = np.dot(e.T, e)
# Compute Standard Error
SE = np.sqrt(SSRes/(nobs-npar))
print(f"Standard Error = {SE}")

# Compute R^2 = 1 - SSRes / SST
SST = np.dot(y.T,y) - nobs*np.mean(y)**2
R_squared = 1 - SSRes/SST
print(f"R-squared = {R_squared}")
print(f"R = {np.sqrt(R_squared)}")


# Plot the fitted model with the data
fig, ax = plt.subplots()
ax.plot(X[:,1], y, 'ro')
ax.set_xlabel('Weight')
ax.set_ylabel('Cost')
ax.grid()
fit = lambda x: np.dot(beta, np.array([1,x], dtype=object))
ax.plot(X[:,1],fit(X[:,1]), lw=2)
plt.show()





