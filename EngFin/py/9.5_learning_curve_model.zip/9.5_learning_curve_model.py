# -*- coding: utf-8 -*-
# 9.5_learning_curve_model.py
""" 9.5 Learning Curve Model """
from EngFinancialPy import LearningCurve

# The time required to assemble the first car is 100 hours. 
# The learning rate is 80%.  
assemble_cars = LearningCurve(100, 0.8)

# What is the time required to assemble the 10 car? 
print("Time to assemble the 10th car = "
      f"{assemble_cars.Unit(10)}")

# What is the total time required to assemble the first 10 cars?
print("Time to assemble the first 10th car ="
      f"{assemble_cars.Cumulative(10)}")

# What is the average time per car for the first 10 car?
print("Average time per car for the first 10 cars = "
      f"{assemble_cars.Average(10)}")

# What is the average time per car for the first 100 car?
print("Average time per car for the first 100 cars = "
      f"{assemble_cars.Average(100)}")