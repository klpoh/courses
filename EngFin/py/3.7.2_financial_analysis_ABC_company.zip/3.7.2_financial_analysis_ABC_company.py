# -*- coding: utf-8 -*-
# 3.7.2_financial_analysis_ABC_company.py
""" 3.7.2 Financial Analysis of ABC Company """
from EngFinancialPy import Project_CF, PnAF_cf

# Create the project cash flows and check basic attributes
ABC = Project_CF(marr=0.2, name="ABC Company Problem")
ABC.set_cf(PnAF_cf(Nper=5, P=-25000, A=8000, F=5000))
print(f"\n{ABC.name}")
print(f"  life = {ABC.life}")
print(f"  Cash flows = {ABC.cf}")

# Compute Project Profitability Measures
print("Project Profitability Measures:")
print(f"  NPV({ABC.marr}) = {ABC.npv():,.2f}")
print(f"  PW({ABC.marr}) = {ABC.pw():,.2f}")
print(f"  AW({ABC.marr}) = {ABC.aw():,.2f}")
print(f"  FW({ABC.marr}) = {ABC.fw():,.2f}")
print(f"  IRR = {ABC.irr():.5f}")

# Compute MIRR at financial rate = 0.15 and reinvestment rate = 0.20
print(f"  MIRR = {ABC.mirr(fin_rate=0.15, reinv_rate=0.20):8.5f}")

# Compute Project Liqidity Measures
print("Project Liquidity Measure:")
print(f"  Payback({ABC.marr}) = {ABC.payback()}")

# Is the project financially feasible?
print("Project Feasibilty:")
print(f"  Feasibility({ABC.marr}) = {ABC.is_feasible()}")
print("\n")

# Compute the Project PW at marr=10% (instead of default 20%)
print(f"NPV(0.1) = {ABC.npv(0.1):,.2f}")
# Compute the Project payback period at marr=10% (instead of 20%)
print(f"Payback(0.1) = {ABC.payback(0.1)}")


