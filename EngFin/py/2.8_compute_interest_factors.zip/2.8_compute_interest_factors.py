# -*- coding: utf-8 -*-
# 2.8_compute_interest_factors.py
""" 2.8 Compute interest factors for discrete case flows under 
    discrete and continuous compounding using IntFactor class """
from EngFinancialPy import IntFactor

""" Example 1: Compute the value of [P/G, 8%, 10] """

# Method 1: Compute a factor's value directly and print it.
print(IntFactor('P', 'G', 0.08, 10).value)

# Method 2: Create the interest factor and then use its methods.
factor = IntFactor('P', 'G', 0.08, 10)
# print out the value
print(f"{factor.value:.6f}")
# Print out the symbol notation
print(factor.symbol)
# See what are the factor's parameters
print(factor.params)


""" Example 2: Printing all the interest factor values for 12%, 10 periods
               under discrete & continuous compoudings """
# List of all the find and given parameters to compute
FG = ('FP','PF','FA','AF','PA','AP','PG','FG','AG')
rate = 0.12
Nper = 10
    
print("\nDiscrete Compounding:")
for fg in FG:
    factor = IntFactor(*fg, rate, Nper)
    print(f"  {factor.symbol} = {factor.value:12.8f}")
        
print("\nContinuous Compounding:")
for fg in FG:
    factor = IntFactor(*fg, rate, Nper, continuous=True)
    print(f"  {factor.symbol} = {factor.value:12.8f}")






