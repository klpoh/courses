# -*- coding: utf-8 -*-
""" EngFinancialPy Module ver 2025.01.01 """
import numpy as np
import numpy_financial as npf
import pandas as pd
import matplotlib.pyplot as plt
from scipy import stats
from scipy.optimize import root
import statsmodels.api as sm

#---------------------------------------------------------------------------
class CF_diagram:
    """ Cash flow diagram plotting Class
    Parameters:
      CashFlows = a complete list or array of cash flows [f0, f1,..., fN], or
                  a sparse unsorted dictionay { time: cash flow value }
      color = color to plot diagram
      currency = currency unit for labels
      time = time unit for x-axis
      figsize = size of figure as(float, float)
      
    Attributes:
      figure: Figure object 
      axes:   Axes object
    """
    
    def __init__(self, CashFlows, color='black', currency='$',
                 time_unit='Year', time_start=0, time_step=1, time_end=None,
                 title=None, figsize=None):
       
        self.CashFlows = CashFlows
        self.color = color
        self.time_unit = time_unit
        self.figsize = figsize
        self.currency = currency
        self.time_start = time_start
        self.time_end = time_end
        self.time_step = time_step
        self.title = title
        self.figure, self.axes = self.__create_plot()
        
    
    def __create_plot(self):
        """ Plot the cash flow diagram using instance's parameters.
            Returns Figure, Axes object. """
            
        if type(self.CashFlows) is list or type(self.CashFlows) is np.ndarray:
            CF = { t : v for t, v in enumerate(self.CashFlows)}
        elif type(self.CashFlows) is dict:
            CF = self.CashFlows
        else:      
            print("Cash flows must be either list, np.array or dictionary")
            return None
    
        fig, ax = plt.subplots(figsize=self.figsize)
        
        # Draw the vertical lines
        ax.vlines(CF.keys(), 0, CF.values(),lw=4, color=self.color)
        
        # Seperate the positive and negative cash flows and plot their markers
        posCF_x = [t for t,v in CF.items() if v > 0]
        posCF_v = [v for t,v in CF.items() if v > 0]
        ax.plot(posCF_x, posCF_v, '^', markersize=10, color=self.color)
        negCF_x = [t for t,v in CF.items() if v < 0]
        negCF_v = [v for t,v in CF.items() if v < 0]
        ax.plot(negCF_x, negCF_v, 'v', markersize=10, color=self.color)
        
        # Add the cash flow values at the arrow heads
        vspace = 0.10*max(np.abs(list(CF.values())))
        for t,v in CF.items():
            if v != 0:
                ax.text(t,v+np.sign(v)*vspace,self.currency+str(v), 
                        ha='center', va='center')
            
        # Time axis cross at start_time 
        ax.spines['left'].set_position(('data', self.time_start))
        ax.spines['bottom'].set_position(('data', self.time_start))
        ax.spines['top'].set_visible(False)
        ax.spines['right'].set_visible(False)
        ax.spines['left'].set_visible(False)
        ax.get_yaxis().set_visible(False)
        
        # Set the x-axis label and tick marks
        ax.set_xlabel(self.time_unit)
        if self.time_end is None:
           self.time_end = max(CF.keys())
        ax.set_xticks(np.arange(self.time_start, self.time_end+1,
                                self.time_step))
        plt.rcParams['axes.titlepad'] = 24 # pad is in points...
        ax.set_title(self.title, fontsize=18)
        return fig, ax

#---------------------------------------------------------------------------
class IntFactor:
    """ A Class for Interest Factors for discrete cash flows with 
        discrete and continuous compounding.
        Parameters:
          find = 'P', 'F' or 'A'
          given = 'P', 'F', A' or 'G'
          rate = interest rate
          nper = number of periods
          continuous = optional, set to True if continuous compounding
        Attributes:
          value = value of the interest factor
          symbol = string [X/Y, rate, nper ]
          params = dictionary of all the interest factor's parameters
          compounding = string 'Discrete' or 'Continuous'
    """
    
    def __init__(self, find, given, rate, nper, continuous=False):
        assert find in 'PAF', print(f"Invalid parameter {find}")
        assert given in 'PAFG', print(f"Invalid parameter {given}")
        self.find = find
        self.given = given
        self.rate = rate
        self.nper = nper
        self.continuous = continuous
        self.value = self.__eval_value()
        self.symbol = self.__make_symbol()
        self.params = self.__params_dict()
        self.compounding = self.__compounding_type()
            
    def __eval_value(self):
        """ Compute the interest factor value using internal parameters """
        if self.find==self.given: return 1
        func_dict = { 
          ('P','F'): lambda i,N: npf.pv(i,N,0,-1),
          ('F','P'): lambda i,N: npf.fv(i,N,0,-1), 
          ('A','F'): lambda i,N: npf.pmt(i,N,0,-1),
          ('F','A'): lambda i,N: npf.fv(i,N,-1,0),
          ('A','P'): lambda i,N: npf.pmt(i,N,-1),
          ('P','A'): lambda i,N: npf.pv(i,N,-1,0),
          ('F','G'): lambda i,N: (npf.fv(i,N,-1,0)-N)/i,
          ('P','G'): lambda i,N: npf.pv(i,N,0,-1)*(npf.fv(i,N,-1,0)-N)/i,
          ('A','G'): lambda i,N: npf.pmt(i,N,0,-1)*(npf.fv(i,N,-1,0)-N)/i }
        if self.continuous:
            eff_rate = np.exp(self.rate) - 1
        else:
            eff_rate = self.rate
        return(func_dict[(self.find,self.given)](eff_rate, self.nper))

    def __make_symbol(self):
        """ Return a string symbol for the Interest Factor """
        if not self.continuous:
            return f"[{self.find}/{self.given}, {self.rate}, {self.nper}]"
        else:
            return f"[{self.find}/{self.given}, r={self.rate}, {self.nper}]"

    def __compounding_type(self):
        """ Returns compounding type (string) as below"""
        if self.continuous: return "Continuous"
        else: return "Discrete"

    def __params_dict(self):
        """Returns a dictionary of all the interest factor's parameters"""
        return {'find' : self.find,
                'given': self.given,
                'rate' : self.rate,
                'nper' : self.nper,
                'continuous' : self.continuous }
    
#---------------------------------------------------------------------------
class GeomCashFlows:
    """ A Class for Geometric Series Cash Flows 
        Parameters:
          rate = effective interest rate
          nper = number of periods
          A1   = cash flow at end of year 1
          growth = year-on-year growth rate of annual flows
        Attributes:
          P = Present equivalent value of cash flows
          A = Equivalent uniform annual cash flows
          F = Future equivalent value of cash flows
          G = Equivalent uniform gradient cash flows (0,0,G,2G,...,(n-1)G)
          params = dictionary of cash flow parameters
    """

    def __init__(self, rate, nper, A1, growth):
        
        self.A1 = A1
        self.growth = growth
        self.rate = rate
        self.nper = nper
        self.P = self.__find_P()
        self.A = self.__find_A()
        self.F = self.__find_F()
        self.G = self.__find_G()
        self.params = self.__params_dict()
    
    def __find_P(self):
        if self.growth == self.rate:
            return self.A1*self.nper/(1+self.rate)
        else:
            return self.A1*(1-(1+self.rate)**-self.nper *\
                    (1+self.growth)**self.nper)/(self.rate-self.growth)

    def __find_A(self):
        return -npf.pmt(self.rate,self.nper,self.P, 0)
       
    def __find_F(self):
        return -npf.fv(self.rate,self.nper,0,self.P)
    
    def __find_G(self):
        return self.P * \
            self.rate**2/(1-(1+self.nper*self.rate)*(1+self.rate)**-self.nper)
        
    def __params_dict(self):
        """Return a dictionary of all the cash flow's parameters"""
        return {'rate'  : self.rate,
                'nper'  : self.nper,
                'A1'    : self.A1,
                'growth': self.growth }
    
#---------------------------------------------------------------------------
def PnAF_cf(Nper, P=0, A=0, F=0):
    """ 
    PnAF_cf(Nper, P=0, A=0, F=0)
      Constructs  [ P, A, A, ..., A , A+F ] 
      Parameters:
         Nper = number of periods
         P = Initial cash flow at EoY 0
         A = Uniform annual cash flow amounts from EoY 1 to EoY n
         F = Single final cash flow at EoY Nper 
      Returns a list of cash flows [ P, A, A, ..., A , A+F ] 
    """
    return [P] + [A]*(Nper-1) + [A+F]

#---------------------------------------------------------------------------
def PnGF_cf(Nper, P=0, A1=0, G=0, F=0):
    """ 
    PnGF_cf(Nper, P=0, A1=0, G=0, F=0):
      Construct [P, A1, A1+G, A1+2G, ..., A1+(N-1)*G + F ] cash flows 
      Parameters:
        Nper = Number of periods
        P = Initial case flow
        A1 = Cash flow at EoY 1
        G = Annual cash flows increment up to EoY N
        F = SV at EoY N
    Returns:
      List [P, A1, A1+G, A1+2G, ...,A1+(Nper-2)*G, A1+(Nper-1)*G + F ] 
    """
    CF = [ P ]
    for k in range(Nper):
        CF.append(A1 + k*G)
    CF[Nper] += F
    return CF

#---------------------------------------------------------------------------
def repeat_cf(CF1):
    """ Repeat cash flows under repeatability assumption 
    Parameter:
        CF1= Cash flow for first cycle
    Reurns:
        Cash flows with appended 2nd cycle
    """
    CF2 = CF1 + CF1[1:]
    CF2[len(CF1)-1] += CF1[0]
    return CF2

#---------------------------------------------------------------------------
class Project_CF:
    """ Project Cash Flows Class for profitability, liquality and
        feasibility analysis. 
    Parameters:
      cash_flows = Array of cash flows starting from time 0.
                   If not defined, must be set later by set_cf method.
      marr = Project MARR. If undefined, must be either set with 
                set_marr method or given when computing profitability measures.
    Attributes:
      cf = Project cash flows series
      life = Project life
      marr = Project MARR
      name = Project name
    Methods:
      set_marr(marr): Set the project Marr
      set_cf(CF): Set the project cash flows
      pw(marr): Compute PW at marr. Project MARR is used if marr is not given.
      npv(marr): Compute PW at marr. Project MARR is used if marr is not given.
      aw(marr): Compute AW at marr. Project MARR is used if marr is not given.
      fw(marr): Compute FW at marr. Project MARR is used if marr is not given. 
      irr : Compute project IRR
      mirr(fin_rate, reinv_rate): Compute MIRR at given rates
      payback(marr): Compute discounted paybakck period at marr. Project MARR 
                        is used if marr is not given.
      is_feasible(marr): Return True or False on project feasible at marr.
                           Project MARR is used if marr is not given.
    """

    def __init__(self, cash_flows=[], marr=None, name="Unnamed"):
        self.cf   = cash_flows
        self.life = len(cash_flows)-1
        self.marr = marr
        self.name = name

    def set_marr(self, rate):
        """ Set the project marr """
        self.marr = rate

    def set_cf(self, CF):
        """ Set or reset the project cash flows """
        self.cf = CF
        # Update the project life
        self.life = len(CF)-1

    def pw(self, rate=None):
        """ Compute PW(marr) of the cash flows """
        if rate is None: 
            if self.marr is None:
                print("No marr provided")
                return None
            else:
                rate = self.marr 
        return npf.npv(rate, self.cf)

    def npv(self, rate=None):
        """ Compute NPV(marr) of the cash flows """
        return self.pw(rate)

    def aw(self, rate=None):
        """ Compute AW(marr) of the cash flows """ 
        if rate is None: 
            if self.marr is None:
                print("No marr provided")
                return None
            else:
                rate = self.marr 
        return -npf.pmt(rate, self.life, self.pw(rate), 0)

    def fw(self, rate=None):
        """ Compute FW(marr) of the cash flows """
        if rate is None: 
            if self.marr is None:
                print("No marr provided")
                return None
            else:
                rate = self.marr 
        return -npf.fv(rate, self.life, 0, self.pw(rate), 0)
            
    def irr(self):
        """ Compute IRR of the cash flows """
        return npf.irr(self.cf)
    
    def mirr(self, fin_rate, reinv_rate):
        """ Compute MIRR at the finanical and reinvestment rates"""
        return npf.mirr(self.cf, fin_rate, reinv_rate)

    def payback(self, rate=None):
        """ Compute discounted payback period of the cash flows at marr """
        if rate == None: 
            if self.marr == None:
                print("No marr provided")
                return None
            else:
                rate = self.marr 
        PW_k=[npf.npv(rate, self.cf[:k+1]) 
              for k in range(len(self.cf))] 
        pback = None
        for k in range(1, len(self.cf)):
            if PW_k[k] >= 0:
                pback = k
                break
        return pback
    
    def is_feasible(self, rate=None):
        """ Determine if project is feasible at marr """
        if rate == None: 
            if self.marr == None:
                print("No marr provided")
                return None
            else:
                rate = self.marr 
        return self.npv(rate) >= self.marr


#---------------------------------------------------------------------------
class pub_Project(Project_CF):
    """ Subclass of Project_CF for B/C ratio methods 
        Costs and Benefits cash flows are separate inputs
    Attributes:
        benefits_cf : List of benefits cash flows
        costs_cf : List of costs cash flows 
    Methods:
        set_BC_cash_flows(Benfits_CF, Costs_CF)
        BC_Ratio(rate): Computes the BC ratio """
        
    def __init__(self, Benefits_CF=[], Costs_CF=[], marr=None, name="Unnamed"):
        self.benefits_cf = Benefits_CF
        self.costs_cf = Costs_CF
        self.cf   = self.__merge_CF(Benefits_CF, Costs_CF)
        self.life = len(self.cf)-1
        self.marr = marr
        self.name = name

    def __merge_CF(self, cf1, cf2):
        assert len(cf1)==len(cf2)
        return [x+y for x,y in zip(cf1, cf2)]
    
    def set_BC_cash_flows(self, Benefits_CF, Costs_CF):
        """ Set or reset the project benifits and costs cash flows """
        self.benefits_cf = Benefits_CF
        self.costs_cf = Costs_CF
        self.cf = self.__merge_CF(Benefits_CF, Costs_CF)
        # Update the project life
        self.life = len(self.cf)-1
        
    def BC_Ratio(self, rate=None):
        """ Compute BC Ratio of the cash flows at marr """
        if rate == None: 
            if self.marr == None:
                print("No marr provided")
                return None
            else:
                rate = self.marr 
        pw_benefits = npf.npv(rate, self.benefits_cf)
        pw_costs = npf.npv(rate, self.costs_cf)
        print(f"  PW of benefits = {pw_benefits:,.2f}")
        print(f"  PW of costs    = {-pw_costs:,.2f}")
        if pw_costs != 0:
            return -pw_benefits/pw_costs
        else:
            return None

def CR(I, SV, rate, N):
    """ Function to Compute and Return Captial Recovery Amount 
    Parameters:
      I = Initial investment amount
      SV = Salvage value
      rate = marr
      N = project life 
    """
    return -npf.pmt(rate, N, I, -SV)
    

#---------------------------------------------------------------------------
def Evaluate_Projects(plist, marr=None, method="PW"):
    """ Evaluate a list of projects using specificed method
    Parameters: 
        plist = list of Project_CF objects
        marr = marr to be used for this evaluation
        method = "PW" (default), "AW", "PW", "IRR", "BC_Ratio"
    Return:
        best project
    """
    # Make a copy in case we mutate the inputs
    plist = list(plist) 
    
    # Set the project marr 
    if marr == None:
        print("Marr not provided")
        return None
    
    for pj in plist:
        pj.set_marr(marr)

    if method=="PW":
        print("\nUsing PW method:")
        plist.sort(key= lambda x: x.pw(), reverse=True)
        for pj in plist:
            print(f"  {pj.name:10}: PW({pj.marr}) = {pj.pw():10,.2f}")
        return plist[0]
    
    if method=="AW":
        print("\nUsing AW method:")
        plist.sort(key= lambda x: x.aw(), reverse=True)
        for pj in plist:
            print(f"  {pj.name:10}: AW({pj.marr}) = {pj.aw():10,.2f}")
        return plist[0]
               
    if method=="FW":
        print("\nUsing FW method:")
        plist.sort(key= lambda x: x.fw(), reverse=True)
        for pj in plist:
            print(f"  {pj.name:10}: FW({pj.marr}) = {pj.fw():10,.2f}")
        return plist[0]

    if method=="IRR":
        print("\nUsing IRR method:")
        plist.sort(key=lambda x: x.cf[0], reverse=True)
        print("Sort alternatives by increasing initial costs:")
        for pj in plist:
            print(f"  {pj.name}: IRR={pj.irr()*100:.2f} %")
        
        print("\nPerforming Incremental IRR Analysis:")
        del_proj = Project_CF(marr=marr)
        base = plist.pop(0)
        while plist != []:
            nex = plist.pop(0)
            print(f"\n  base = {base.name}")
            print(f"  next = {nex.name}")
            del_proj.set_cf([x-y for x,y in zip(nex.cf, base.cf)])
            # print(del_proj.cf)
            del_irr = del_proj.irr()
            print(f"  IRR of increment = {del_irr*100:.2f}%")
            if del_irr>=marr:
                print("  Increment is feasible")
                base = nex
            else:
                print("  Increment is not feasbile")
        return base

    if method=="BC_Ratio":
        print("\nUsing BC Ratio method:")
        for pj in plist:
            assert isinstance(pj, pub_Project),\
               print("Projects must be instances of pub_Project class")
       
        plist.sort(key=lambda x: -npf.npv(marr,x.costs_cf))
        print("Sort alternatives by increasing PW of costs:")
        for pj in plist:
            print(f"  {pj.name:10}:",
                  f" PW of Costs = {-npf.npv(marr,pj.costs_cf):,.2f}")
        
        print("\nPerforming Incremental B/C Ratio Analysis:")
        base = plist.pop(0)
        while plist != []:
            nex = plist.pop(0)
            print(f"\n  base = {base.name}")
            print(f"  next = {nex.name}")
            del_B=npf.npv(marr,nex.benefits_cf)-npf.npv(marr,base.benefits_cf)
            del_C=npf.npv(marr,nex.costs_cf)-npf.npv(marr,base.costs_cf)
            del_BC = -del_B/del_C
            
            print(f"  BC ratio of increment = {del_BC:.4f}")
            if del_BC >= 1:
                print("  Increment is feasible")
                base = nex
            else:
                print("  Increment is not feasible")
        return base

    print(f"Invalid method {method} specified")
    return None

#---------------------------------------------------------------------------
class OneWayRangeSensit:
    """ Class for performing one-way range sensitivity analysis 
    OneWayRangeSensit(alternatives, range_data, name="Unnamed", 
                 output_label="$NPV"):
    Parameters:
      alternatives : dictionary of alternatives and objective functions
      range_data : dictionary of variable names and low, base, high values
      name : optional string, default = "Unnamed"
      output_label : optional string, default = "$NPV"

    Attributes:
      name = name of this analysis
      Alternatives = Dictionary of alternatives and objective functions
      Alt_names = list of alternative names
      Obj_functions = list of objective functions
      Var_data = Dictionary of variable names and low, base, high values
      Var_names = list of variable names
      output_label = label for the objective function outputs
      
   Methods:
      sensit(show_tables=True, show_tornados=True, show_spiders=True, 
             precision=4)
        Perform one-way range sensitivity for each alternative, 
        dhow sensitivty tables, and plot tornado and spider diagrams
             
    combined_tornados():
          Plot a combined tornado diagram for all alternatives.
    """
    
    def __init__(self, alternatives, range_data, name="Unnamed", 
                 output_label="$NPV"):
        """
        Parameters:
          alternatives : dictionary of alternatives and objective functions
          range_data : dictionary of variable names and low, base, high values
          name : optional string, default = "Untitled"
          output_label : optional string, default = "$NPV"
        """
        self.name = name
        self.Alternatives = alternatives
        self.Alt_names = list(alternatives.keys())
        self.Obj_functions = alternatives.values()
        self.Var_data = range_data
        self.Var_names = range_data.keys()
        self.output_label = output_label
        self.Lows = []
        self.Highs = []
        self.Bases = []
        self.sensit_done = False
    

    def sensit(self, show_tables=True, show_tornados=True,
                     show_spiders=True, precision=4):
        """ Perform one-way range sensitivity analysis on each alternative, 
            generate results table, and plot tornado diagram
        Parameters:
          show_tables = True (default) or False
          show_tornados = True (default) or False
          show_spiders = True (default) or False
          precision = number of decimal places to display, default=4
        Returns:
          None
        """
        print(f"\nOne-Way Range Sensitivity for {self.name}")    
    
        self.Lows, self.Highs, self.Swings, self.Bases = [], [], [], []
    
        for i, fn in enumerate(self.Obj_functions):
            
            results = self._range_sensit_table(fn)
            # Unpack the results
            sensit_df, base_npv, min_npv, max_npv = results
            
            if show_tables:
                print(f"\nAlternative: {self.Alt_names[i]}")
                pd.options.display.float_format=(
                    '{:,.'+str(precision)+'f}').format
                # pd.options.display.float_format = '{:,.6f}'.format
                print(sensit_df)
                txt = " {} {} =  {:,."+str(precision)+"f}"
                print(txt.format("\n  Base",  self.output_label, base_npv))
                print(txt.format(    " Min ", self.output_label, min_npv))
                print(txt.format(    " Max ", self.output_label, max_npv))
                '''
                print(f"\n  Base {self.output_label} = {base_npv:,.6f}")
                print(f"  Min  {self.output_label} = {min_npv:,.6f}")
                print(f"  Max  {self.output_label} = {max_npv:,.6f}")
                '''
            # Save the results for combined tornado plotting
            self.Lows.append(list(sensit_df['obj_low']))
            self.Swings.append(list(sensit_df['swing']))
            self.Highs.append(list(sensit_df['obj_high']))
            self.Bases.append(base_npv)
            self.sensit_done = True
            
            if show_tornados:
                #  Draw the tornado diagram
                print(f"\n Tornado diagram for {self.Alt_names[i]}:")
                self._tornado_diagram(sensit_df.index, sensit_df['obj_low'], 
                     sensit_df['obj_high'], base_npv, self.Alt_names[i])
                
            if show_spiders:
                # Draw the spider diagram
                print(f"\n Spider diagram for {self.Alt_names[i]}:")
                
                self._spider_diagram(fn, self.Alt_names[i])
            

    def _range_sensit_table(self, fun):
        """Perform one-way range sensitivity analysis
        Parameters:
          fun = objective function to use
        Returns:  
          Pandas dataframe of results
        """
        data = pd.DataFrame.from_dict(self.Var_data, orient='index',
                                  columns=['low', 'base', 'high'])
        # Compute base case obj value
        base_values = [p[1] for p in self.Var_data.values()]
        obj_base = fun(*base_values)
        lows, highs = [], []
        for y in data.index:
            v = []
            # Set the low value for variable y
            for x in data.index:
                if x==y: v.append(data['low'][x])
                else:    v.append(data['base'][x])
            # Compute objective value when variable y is at low value
            obj_low = fun(*v)
    
            v = []
            # Set the high value for variable y
            for x in data.index:
                if x == y: v.append(data['high'][x])
                else:      v.append(data['base'][x])
            # Compute objective value when variable y is at high value
            obj_high = fun(*v)
            if obj_high < obj_low:
                obj_low, obj_high = obj_high, obj_low  # arrange in order
            lows.append(obj_low)
            highs.append(obj_high)
        # Add to data frame
        data['obj_low'] = lows
        data['obj_high'] = highs
      
        # Determine the min and max objective values
        obj_min = min(list(data['obj_high']) + list(data['obj_low']))
        obj_max = max(list(data['obj_high']) + list(data['obj_low']))
        # Compute the swing for each variable and append it to data.
        data['swing']=[abs(hi-lo) for hi,lo in zip(data['obj_high'],
                                                   data['obj_low'])]
        # Sort the factors by swing in descending order for plotting
        # data.sort_values(['swing'], inplace=True, ascending=False)
        return data, obj_base, obj_min, obj_max


    def _tornado_diagram(self, labels, limits1, limits2, base_value, name):
        """Plot Tornado Diagram 
        Parameters: 
          labels = array of variable names (str)
          limits1 = array of low values for the variables (numeric)
          limits2 = array of high values for the variables (numeric)
          base_value = base value for the tornado diagram (numeric)
          name = label for the x-axis (str)
        Returns:
          None """

        nvars = len(labels)
        assert nvars==len(limits1), "Wrong data size!"
        assert nvars==len(limits2), "Wrong data size!"
        data = pd.DataFrame()
        data['var'] = labels
        data.set_index('var', inplace=True)
        data['lo'] = [min(limits1.iloc[i], limits2.iloc[i]) for i in range(nvars)]
        data['hi'] = [max(limits1.iloc[i], limits2.iloc[i]) for i in range(nvars)]
        data['swing'] = [ data['hi'][v] -data['lo'][v] for v in data.index]
        data.sort_values(['swing'], ascending=False, inplace=True)
                
        
        # fig, ax = plt.subplots(figsize=(8,4))
        fig, ax = plt.subplots(figsize=(12, nvars+2))
        ax.invert_yaxis()
        ax.xaxis.set_visible(True)
        ax.xaxis.grid(True)
        # Compute the min and max values for the tornado diagram axis
        swing_range = data['hi'].max() - data['lo'].min()
        if swing_range == 0: margin = 10
        else: margin = 0.1*swing_range
        xmin, xmax = data['lo'].min()-margin, data['hi'].max()+margin
        ax.set_xlim(xmin, xmax)
        ax.set_xlabel(self.output_label, fontsize=14)
        # Plot the tornado diagram
        for v in data.index:
            ax.barh(v, data['swing'][v], left=data['lo'][v], height=0.4, 
                    color='black', align='center')
        if base_value >= 1:
            ax.get_xaxis().set_major_formatter(
                plt.FuncFormatter(lambda x, loc: f"{int(x):,}"))
        else:
            ax.get_xaxis().set_major_formatter(
               plt.FuncFormatter(lambda x, loc: f"{x:.4f}"))
            
        ax.tick_params(axis="y", labelsize=16)
        # Plot the base value vertical line
        ax.vlines(base_value, -0.5, nvars-0.5, 'r')
        # Draw the zero NPV vertical line if necessary
        if xmin < 0 and xmax > 0:
            ax.vlines(0, -0.5, nvars-0.5, 'b', ls="--")
        ax.set_title(f"Tornado diagram for {name}")
        plt.show()


    # Added 2021 12 05
    def _spider_diagram(self, fun, alt_name):
        """Plot Spider Diagram 
        Parameters: 
          fun = objective function to plot
          alt_name = name of the alternative
        Returns:
          None """
                     
        fig, ax = plt.subplots(figsize=(12,12))
        for var, val in self.Var_data.items():
            lo = val[0]
            base = val[1]
            hi = val[2]
            xrange = np.linspace(lo, hi, 100)
            x_vals = []
            obj_vals = []
            for x in xrange:
                args = []
                for z in self.Var_data.keys():
                    if z==var: args.append(x)
                    else:      args.append(self.Var_data[z][1])
                x_vals.append((x-base)*100/base)
                obj_vals.append(fun(*args))
            ax.plot(x_vals, obj_vals, label=var)

        ax.grid()
        ax.legend()
        ax.set_xlabel("% change from variables' base value")
        ax.set_ylabel(self.output_label)
        ax.set_title(f"Spider diagram for {alt_name}")
        plt.show()

        
    def combined_tornados(self, xL=None, xH=None, xstep_size=None):
        """Plot combined tornados
          Parameters:
            xL = lower limit for plotting combined tornados
            xH = upper limit for plotting combined tornados
            xstep_size = x-axis step_size 
          Returns: None
        """
        if not self.sensit_done:
            # Do it silently
            self.sensit(show_table=False, show_tornado=False)
        
        print(f"\nCombined Tornado Diagrams for {self.name}")
        nvar = len(self.Var_names)
        nalt = len(self.Alt_names)
        xmin = min(min(self.Lows))
        xmax = max(max(self.Highs))
        xrange = xmax - xmin
        if xL == None: xmin = xmin - 0.1*xrange
        else: xmin = xL
        if xH == None: xmax = xmax + 0.1*xrange
        else: xmax = xH
        
        fig, ax = plt.subplots(figsize=(12, nvar+2))
        ax.xaxis.set_visible(True)
        ax.set_xlim(xmin, xmax)
        if xstep_size is not None:
            ax.set_xticks(np.linspace(xmin, xmax, 
                                      int((xmax-xmin)/xstep_size+1)))
        ax.set_xlabel(self.output_label, fontsize="x-large")
        ax.set_ylim(-0.25, nvar)
        ax.invert_yaxis()
        ax.xaxis.grid(True)
        colors = "rbgcmy"
        
        for a in range(nalt):
            ax.vlines(self.Bases[a], -0.25, nvar, color='black', ls='--')
            for y in range(nvar):
                ax.barh(y+0.2*a, self.Swings[a][y], 0.2, self.Lows[a][y], 
                        color=colors[a])

        ax.vlines([0], -0.25, nvar, 'black')    
        ax.set_yticks(range(nvar))
        ax.set_yticklabels(self.Var_names, fontsize='x-large')
        ax.get_xaxis().set_major_formatter(
           plt.FuncFormatter(lambda x, loc: f"{int(x):,}"))
        ax.legend(self.Alt_names, ncol=nalt, bbox_to_anchor=(0.5, 1),
               loc='lower center', fontsize='large')
        """ error unsolved 2025 01 19 
        leg = ax.get_legend()
        for a in range(nalt):
            leg.legendHandles[a].set_color(colors[a])
            leg.legendHandles[a].set_linestyle('solid')
            leg.legendHandles[a].set_linewidth(8)
        """
        plt.show()

#---------------------------------------------------------------------------
# This 2021 version is superceeded by OneWayRangeSesit 2021 12 05
class OneWaySensit:
    """ One-Way Range Sensitivity Class 
    Parameters:
        range_data = Dictionary {var_name : [lo, base, hi], ...}
        obj_func   = Objective function to plot
    Methods:
        one_way_sensit: Returns one-way range sensitivity table (Dataframe)
        get_obj_base_value: Returns the objective base value
        get_obj_min_value: Returns the objective min value
        get_obj_max_value: Returns the objective max value
    """
    def __init__(self, range_data, obj_func):
        self.range_data = range_data
        self.obj_func = obj_func
        
        self.sensit_table, self.base_obj, self.min_obj, self.max_obj =\
            self.__range_sensit(obj_func, range_data)

    def one_way_sensit(self):
        """ Returns the one-way range sensitivity table """
        return self.sensit_table

    def obj_base_value(self):
        """ Returns the objective base value """
        return self.base_obj
        
    def obj_min_value(self):
        """ Returns the objective minimum value """
        return self.min_obj
    
    def obj_max_value(self):
        """ Returns the objective maximum value """
        return self.max_obj

    def tornado(self):
        """ Return a Tornado Diagram """
        return self.__draw_tornado(self.sensit_table.index, 
                                   self.sensit_table['obj_low'],
                                   self.sensit_table['obj_high'],
                                   self.base_obj)
     
    def spider(self):
        return self.__draw_spider(self.obj_func, self.range_data)    
      
    
    def __range_sensit(self, fun, data_dt):
        """ Perform one-way range sensitivity analysis
        Parameters: 
            fun = objective function on a set of variables
            data_dt = variable low, base and high values
        Returns: 
            range sensit table, obj_base, obj_min, obj_max
        """
        data = pd.DataFrame.from_dict(data_dt, orient='index',
                                  columns=['low', 'base', 'high'])
        # Compute base case obj value
        base_values = [p[1] for p in data_dt.values()]
        obj_base = fun(*base_values)
        lows, highs = [], []
        for y in data.index:
            v = []
            # Set the low value for variable y
            for x in data.index:
                if x==y: v.append(data['low'][x])
                else:    v.append(data['base'][x])
            # Compute objective value when variable y is at low value
            obj_low = fun(*v)
    
            v = []
            # Set the high value for variable y
            for x in data.index:
                if x == y: v.append(data['high'][x])
                else:      v.append(data['base'][x])
            # Compute objective value when variable y is at high value
            obj_high = fun(*v)
            if obj_high < obj_low:
                obj_low, obj_high = obj_high, obj_low  # arrange in order
            lows.append(obj_low)
            highs.append(obj_high)
        # Add to data frame
        data['obj_low'] = lows
        data['obj_high'] = highs
      
        # Determine the min and max objective values
        obj_min = min(list(data['obj_high']) + list(data['obj_low']))
        obj_max = max(list(data['obj_high']) + list(data['obj_low']))
        # Compute the swing for each variable and append it to data.
        data['swing']=[abs(hi-lo) for hi,lo in zip(data['obj_high'],
                                                   data['obj_low'])]
        # Sort the factors by swing in descending order for plotting
        # data.sort_values(['swing'], inplace=True, ascending=False)
        return data, obj_base, obj_min, obj_max

    
    def __draw_tornado(self, labels, limits1, limits2, base_value):
        """Plot Tornado Diagram 
        Parameters: 
          labels = array of variable names (str)
          limits1 = array of low values for the variables (numeric)
          limits2 - array of high values for the variables (numeric)
          base_value = base value for the tornado diagram (numeric)
        Return:
          figure, axes for the tornado diagram """
            
        nvars = len(labels)
        assert nvars==len(limits1), "Wrong data size!"
        assert nvars==len(limits2), "Wrong data size!"
        data = pd.DataFrame()
        data['var'] = labels
        data.set_index('var', inplace=True)
        data['lo'] = [min(limits1[i], limits2[i]) for i in range(nvars)]
        data['hi'] = [max(limits1[i], limits2[i]) for i in range(nvars)]
        data['swing'] = [ data['hi'][v] -data['lo'][v] for v in data.index]
        data.sort_values(['swing'], ascending=False, inplace=True)
    
        fig, ax = plt.subplots(figsize=(8,4))
        ax.invert_yaxis()
        ax.xaxis.set_visible(True)
        ax.xaxis.grid(True)
        # Compute the min and max values for the tornado diagram axis
        swing_range = data['hi'].max() - data['lo'].min()
        if swing_range == 0: margin = 10
        else: margin = 0.1*swing_range
        xmin, xmax = data['lo'].min()-margin, data['hi'].max()+margin
        ax.set_xlim(xmin, xmax)
        # Plot the tornado diagram
        for v in data.index:
            ax.barh(v, data['swing'][v], left=data['lo'][v], height=0.4, 
                    color='black', align='center')
        ax.get_xaxis().set_major_formatter(
           plt.FuncFormatter(lambda x, loc: f"{int(x):,}"))
        ax.tick_params(axis="y", labelsize=16)
        # Plot the base value vertical line
        ax.vlines(base_value, -0.5, nvars-0.5, 'r')
        # Draw the zero NPV vertical line if necessary
        if xmin < 0 and xmax > 0:
            ax.vlines(0, -0.5, nvars-0.5, 'b', ls="--")
        return fig, ax

             
    def __draw_spider(self, fun, data):
        """Plot Spider Diagram 
        Parameters: 
          fun = objective function
          data = Dictionary {var_name : [lo, base, hi], ...}
        Return:
          figure, axes for the spider diagram """
        fig, ax = plt.subplots()
        for var, val in data.items():
            lo = val[0]
            base = val[1]
            hi = val[2]
            xrange = np.linspace(lo, hi, 100)
            x_vals = []
            obj_vals = []
            for x in xrange:
                args = []
                for z in data.keys():
                    if z==var: args.append(x)
                    else:      args.append(data[z][1])
                x_vals.append((x-base)*100/base)
                obj_vals.append(fun(*args))
            ax.plot(x_vals, obj_vals, label=var)
            
        ax.grid()
        ax.legend()
        ax.set_xlabel("% change from variables' base value")
        return fig, ax

#------------------------------------------------------------------------
class RainbowDiagram:
    """ Plot Rainbow diagrams and find the break points 
    RainbowDiagram(Functions, Names, XL, XH, XStep)
    Parameters:
      Functions :  List of functions to plot 
      Names : List of names of functions to plot
      XL : Lower x-axis limit of rainbow diagram 
      xH : Upper x-axis limit of rainbow diagram
      xStep : Step size of x-axis
    Methods:
      plot(xL, xH, xStep, xlabel, ylabel, nPoints, dpi)
        Plot Rainbow Diagram
        Parameters:
            XL : Lower x-axis limit of rainbow diagram 
            xH : Upper x-axis limit of rainbow diagram
            xStep : Step size of x-axis
            xlabel : x-axis label (default None)
            ylabel : y-axis label (default None)
            nPoints : number of points used to plot diagram (default 100)
            dpi : DPI of point (default 100)
    
      break_point()
        Compute the break-even points.
        Parameter:
            Nil

    """
    def __init__(self, Functions, Names, xL, xH, xStep):
        """ Constructor for Rainbow_Diagrams class """
        self.Fns = Functions
        self.vFns = [np.vectorize(f) for f in Functions]
        self.Names = Names
        self.xL = xL
        self.xH = xH
        self.xStep = xStep


    def plot(self, xL=None, xH=None, xStep=None, xlabel=None, 
                 ylabel=None, nPoints=100, dpi=100):
        """ Plot the rainbow diagrams 
        Parameters:
          XL : Lower x-axis limit of rainbow diagram 
          xH : Upper x-axis limit of rainbow diagram
          xStep : Step size of x-axis
          xlabel : x-axis label (default None)
          ylabel : y-axis label (default None)
          nPoints : number of points used to plot diagram (default 100)
          dpi : DPI of point (default 100)
        """
        if xL is None: xL = self.xL
        if xH is None: xH = self.xH
        if xStep is None: xStep = self.xStep

        x = np.linspace(xL, xH, nPoints)
        fig, ax = plt.subplots(dpi=dpi)
        for vf, label in zip(self.vFns, self.Names):
            ax.plot(x, vf(x), '-', lw=2, label=label )
        ax.set_xlim(xL, xH)
        ax.set_xticks(np.arange(xL, xH+xStep, xStep))
        ax.set_xlabel(xlabel)
        ax.set_ylabel(ylabel)
        ax.legend()
        ax.grid()
        plt.show()

    def break_points(self):
        """ Find all the break even points
        Parameters:  None
        Returns:     List of beak points 
        """
        x0 = (self.xH-self.xL)/2
        solutions = []
        for i, f1 in enumerate(self.vFns):
            for j, f2 in enumerate(self.vFns):
                if j > i:
                    Fn = lambda x: f2(x) - f1(x)
                    sol = root(Fn, x0, options={'xtol':1e-16})
                    solutions.append(sol.x[0])        
        return solutions
    

#------------------------------------------------------------------------
class Monte_Carlo_Simulation:
    """ Perform Monte Carlo Simulation and Probabilsitic Risk Analysis
    Parameters:
      fixed_vars = dictionary of fixed variables name and value
      random_vars = dictionary of random variable name and stats objects
      ouput_functions = dictionary of output name and functions
    Methods:
      base_case: returns dictionary of output base case values
      run: run the simulation model
      show_inputs_values: show statistics and distributions of input values
      show_outputs_values: show statistics and distributions of outputs
      Prob_Analysis_DCF: perform probabilistic risk analysis on DCF outputs
      Prob_Analysis_rate: perform probabilistic risk analysis of rate outputs
    """
    
    def __init__(self, fixed_vars, random_vars, output_functions):
        self.fixed_vars = fixed_vars
        self.random_vars = random_vars
        self.output_functions = output_functions
        self.inputs_df = None
        self.outputs_df = None
    
    def base_case(self):
        """ Compute the base case output values """
        base_values= list(self.fixed_vars.values()) + [x.stats(moments='m') 
                                    for x in self.random_vars.values() ]
        return {v: f(*base_values) for v, f in self.output_functions.items()}       
     
        
    def run(self, num_trials=100_000):
        """ Perform Monte Carlo Simulation """
        inputs = []
        outputs = []
        for _ in range(num_trials):
            # Generate random values for input variables
            trial_values = [var.rvs() for var in self.random_vars.values()]
            # Compute output values:
            output_values=[f(*self.fixed_vars.values(),*trial_values) 
                           for f in self.output_functions.values()]
            inputs.append(trial_values)
            outputs.append(output_values)
        
        # Simulation completed. 
        # Store the results in dataframes and save them as attributes
        self.inputs_df = pd.DataFrame.from_records(inputs,
                                    columns=self.random_vars.keys())
        self.outputs_df = pd.DataFrame.from_records(outputs,
                                    columns=self.output_functions.keys())
        
        return "Simulation Completed"
      
    def show_inputs_values(self):
        """ Display statistics and histogram of input variables"""
        for var in self.inputs_df:
            print(f"\nInput Variable {var}:")
            print(self.inputs_df[var].describe().round(2))
            print("\nHistogram:")
            self.inputs_df[var].plot.hist(bins=30)
            plt.xlabel(var)
            plt.grid()
            plt.show()

    def show_outputs_values(self):
        """ Display statistics and histogram of output variables """
        for var in self.outputs_df:
            print(f"\nOutput Variable {var}:")
            values = self.outputs_df[var]
            # Remove nan and outliers
            values = values[~np.isnan(values)]
            Z = np.abs(stats.zscore(values))
            values = values[(Z < 4)]
            
            # Display results
            print(values.describe().round(2))
            print("\nHistogram:")
            ax0 = values.plot.hist(bins=30)
            ax0.set_xlabel(var)
            ax0.grid()
            plt.show()
            
            # Plot the emphirical CDF
            ecdf = sm.distributions.ECDF(values)
            fig1,ax1 = plt.subplots()
            ax1.plot(ecdf.x, ecdf.y) 
            ax1.set_xlabel(var)
            ax1.set_ylabel('Cumulative Probability')
            ax1.set_yticks(np.linspace(0,1,11))
            ax1.grid()
            plt.show()
            
            # Plot the emphirical excess distribution
            fig2,ax2 = plt.subplots()
            ax2.plot(ecdf.x,1-ecdf.y) 
            ax2.set_xlabel(var)
            ax2.set_ylabel('Excess Probability')
            ax2.set_yticks(np.linspace(0,1,11))
            ax2.grid()
            plt.show()


    def Prob_Analysis_DCF(self, var_name, downsides=[0], upsides=[]):
        """ Perform probailistic risk analysis for DCF output values """
        
        print(f"\nProbabilistic Analysis on {var_name}")
        DCF = self.outputs_df[var_name]
        # Remove nan and outliers 
        DCF = DCF[~np.isnan(DCF)]
        Z = np.abs(stats.zscore(DCF))
        DCF = DCF[(Z < 3.5)]
        
        print(f"  EV = {np.mean(DCF):,.2f}")
        print(f"  SD = {np.std(DCF):,.2f}")
        print("Downside Risks:")
        
        ecdf = sm.distributions.ECDF(DCF)
        for down in downsides:
            print(f"  Pr({var_name} <= {down:7,.0f}) = {ecdf(down)*100:.2f}%")
        
        print("Upside Potentials:")
        for up in upsides:
            print(f"  Pr({var_name} >= {up:7,.0f}) = {(1-ecdf(up))*100:.2f}%")
        
        print("Value-at-Risk:")
        for alpha in [0.01, 0.05, 0.1]:
            filtered = [x for x,y in zip(ecdf.x, ecdf.y) if y <= alpha]
            VaR = -max(filtered)
            print(f"  VaR({100*(1-alpha):.0f}%) = {VaR:10,.2f}")


    def Prob_Analysis_rate(self, var_name, marr, downsides=[], upsides=[]):
        """  Perform probabilistic risk analysis on rate of return outputs """
        
        print(f"\nProbabilistic Analysis on {var_name}:")
        Rates = self.outputs_df[var_name]
        # Remove nan and outliers 
        Rates = Rates[~np.isnan(Rates)]
        Z = np.abs(stats.zscore(Rates))
        Rates = Rates[(Z < 3.5)]
        
        print(f"  EV = {np.mean(Rates)*100:,.2f}%")
        print(f"  SD = {np.std(Rates)*100:,.2f}%")
        print("Downside Risks:")
        ecdf = sm.distributions.ECDF(Rates)
        for down in [marr] + downsides:
            print(f"  Pr({var_name} <= {down*100:4,.1f}%) = {ecdf(down)*100:.2f}%")
                
        print("Upside Potentials:")
        for up in upsides:
            print(f"  Pr({var_name} >= {up*100:4,.1f}%) = {(1-ecdf(up))*100:.2f}%")

# Added 2022 04 02: Overlay simulation outputs
def Overlay_sim_outputs(Values, xlabel=None, dpi=100 ):
    """ Overlay simulation outputs 
    Parameters:
       Values = List of list of simulation output values
       xlabel = label for the x-axis
    """
    
    # Remove nan and outliers from the simulation output values
    for v in Values:
        v = v[~np.isnan(v)]
        z = np.abs(stats.zscore(v))
        v = v[(z < 4)]
    # Generate list of emphirical CDF values
    ECDFs = [ sm.distributions.ECDF(v) for v in Values ]
       
    # Overlay the emphirical CDFs
    fig1,ax1 = plt.subplots(dpi=dpi)
    for ecdf in ECDFs:
        ax1.plot(ecdf.x, ecdf.y) 
    ax1.set_xlabel(xlabel)
    ax1.set_ylabel('Cumulative Probability')
    ax1.set_yticks(np.linspace(0,1,11))
    ax1.grid()
    plt.show()

    # Overlay the emphirical EPFs
    fig2,ax2 = plt.subplots(dpi=dpi)
    for ecdf in ECDFs:
        ax2.plot(ecdf.x, 1-ecdf.y) 
    ax2.set_xlabel(xlabel)
    ax2.set_ylabel('Excess Probability')
    ax2.set_yticks(np.linspace(0,1,11))
    ax2.grid()
    plt.show()


#------------------------------------------------------------------------
class ATCF_Analysis():
    """ After=Tax Cash Flow Analysis Class 
    Parameters:  
        btcf = Unsorted list of before tax cash flows, as tuples as follows:
             (EoY,'C', Value) for capital cash flows
             (EoY,'D', Value) for depreciations
             (EoY,'T', Value) for taxable or tax-deductible cash flows
             (EoY,'S', MV_n, BV_n) for asset disposal cash flow
             
        btcf can take multiple capital cash flows and salvage values
        There should be at least one entry of any type for each year 
        from 0 to N. Use zero values if needed for any year with 
        no cash flows of any type.
     Methods:
        atcf : a list of year-by-year after-tax cash flows
        atcf_table(silence=False): Returns ATCF table (DataFrame)
                                   Don't print table if silence=True
        after_tax_NPV(marr): Compute after-tax NPV at marr
        after_tax_PW(marr):  Compute after-tax PW at marr
        after_tax_AW(marr):  Compute after-tax AW at marr    
        after_tax_FW(marr):  Compute after-tax FW at marr
        after_tax_IRR(marr): Compute after-tax IRR
    """
 
    def __init__(self, btcf, tax_rate=0.17):
        self.btch = btcf
        self.tax_rate = tax_rate    
        self.__atcf_analysis(btcf, tax_rate)
        
    def __atcf_analysis(self, btcf, tax_rate):
        """ Perform ATCF Analysis """
        # Sort cash flow data by EoY
        btcf.sort(key=lambda x: x[0], reverse=False)
        # Create atcf dataframe from input data except depreciaitons 
        atcf_df = pd.DataFrame( [x for x in btcf if x[1] !='D'], 
                            columns = ['EoY', 'Type', 'BTCF','BV'])
    
        # Add 'Depreciation' column in dataframe with all zero values
        atcf_df['Depreciation'] = [0]*len(atcf_df)
        
        # Insert the depreciation values in the correct year.
        for d in btcf:
            if d[1] == 'D':
                # find the row to insert
                for i in atcf_df.index:
                    if atcf_df.iloc[i]['Type']=="T" and atcf_df.iloc[i]['EoY']==d[0]:
                        atcf_df.loc[i,'Depreciation'] = d[2]
                        break
        # Blank out the zeros from C and S types cash flows for nicer printing
        for i in atcf_df.index:
            if atcf_df['Type'][i] in {'C', 'S'}:
                atcf_df.loc[i,'Depreciation'] = ""
    
        # Sort the data frame by EoY and Cash flow type
        atcf_df = atcf_df.sort_values(by=['EoY','Type'],ascending=[True,False])
    
        # Create 3 additonal columns with zero/nil values
        atcf_df['Taxable Income'] = [""]*len(atcf_df)
        atcf_df['IT Cash Flow']   = [""]*len(atcf_df)
        atcf_df['ATCF']           = [0]*len(atcf_df)
    
        # Compute all additional columns
        for i in atcf_df.index:
            if (atcf_df.loc[i,'Type'] == 'C'):
                atcf_df.loc[i,'ATCF'] = atcf_df.loc[i,'BTCF']
                
            if (atcf_df.loc[i,'Type'] == 'T'):
                atcf_df.loc[i,'Taxable Income'] = \
                    atcf_df.loc[i,'BTCF']- atcf_df.loc[i,"Depreciation"]
                                              
                atcf_df.loc[i,'IT Cash Flow'] = \
                            -tax_rate*atcf_df.loc[i,'Taxable Income']
                            
                atcf_df.loc[i,'ATCF'] = \
                    atcf_df.loc[i,'BTCF'] + atcf_df.loc[i,'IT Cash Flow']
                                            
            if (atcf_df.loc[i,'Type'] == 'S'):
                atcf_df.loc[i,'Taxable Income'] = \
                    atcf_df.loc[i,'BTCF'] - atcf_df.loc[i,'BV']
                atcf_df.loc[i,'IT Cash Flow'] = \
                    -tax_rate*atcf_df.loc[i,'Taxable Income']
                atcf_df.loc[i,'ATCF'] = \
                    atcf_df.loc[i,'BTCF'] + atcf_df.loc[i,'IT Cash Flow']
        
        # Drop the 'BV' column
        atcf_df = atcf_df.drop(['BV'], axis=1)
        
        # Extract out the ATCF as tuples (Eoy, ATCF) for futher analysis     
        atcf_cf = [(y, cf) for y, cf in zip(atcf_df['EoY'], atcf_df['ATCF'])]
        
        # Merge cash flows that occur in the same years 
        d = {}
        for year, values in atcf_cf:
            if year not in d:
                d[year] = values
            else:
                d[year] = d[year]+values
    
        # Make sure that the list of ATCF is in increasing EoY
        self.atcf = [ d[k] for k in sorted(d)]
        self.atcf_tab = atcf_df.drop(['Type'], axis=1)

    def atcf_table(self, silence=False):
        if not silence:
            pd.options.display.float_format = '{:,.2f}'.format
            print("   After-Tax Cash Flow Analysis Table")
            print(self.atcf_tab.loc[:,'EoY':'ATCF'])
        return self.atcf_tab

    def atcf(self):
        return self.atcf

    def after_tax_NPV(self, marr):
        """ Compute afer-tax NPV """
        return npf.npv(marr, self.atcf)

    def after_tax_PW(self, marr):
        """ Compute afer-tax PW """
        return self.after_tax_NPV(marr)

    def after_tax_FW(self, marr):
        return -npf.fv(marr,len(self.atcf)-1,0,self.after_tax_PW(marr))
    
    def after_tax_AW(self, marr):
        """ Compute afer-tax AW """
        return -npf.pmt(marr,len(self.atcf)-1,self.after_tax_PW(marr),0)
        
    def after_tax_IRR(self):
        """ Compute afer-tax IRR """
        return npf.irr(self.atcf)

#---------------------------------------------------------------------------
class Asset():
    """ Asset class for capital asset economic replacement analysis
    Parameters:
      MV0 = current market value or initial cost
      MV = list of market values at EoY k for k = 1 to N
      E = list of annual expense in year k for k = 1 to N
      marr = marr
    Methods:
      useful_life:  Useful (remaining) life of asset
      EPC: Compute Equivalent Present Cost for year k, k = 1 to N 
      TC:  Compute the total marginal costs for year k, k = 1 to N
      EUAC_conventional(self): Compute the EUAC for year k, k = 1 to N 
                               using Conventional method 
      EUAC:  Compute and the EUAC for year k, k = 1 to N using TC_k method
      econ_life_euac: Compute ( Economic Service Life, Min EUAC )
      TC_montotonic: True if the TC values are monotonically non-decreasing
    """  
    def __init__(self, MV0, MV, E, marr, age=None, name="unnamed asset"):
        
        self.MV0 = MV0
        self.MV = MV
        self.E = E
        self.marr = marr
        self.name = name
        self.age = age
        assert len(MV)==len(E), "MV and E must be same dimension"
        self.life = len(MV)

    def useful_life(self):
        """ The useful remaining life of the asset """
        return self.life
    
    def EPC(self):
        """ Compute Equivalent Present Cost for year k, k = 1 to N """
        # List of CF for EoY 0 to k, for k = 0 to N 
        CF=[[self.MV0]+self.E[0:k]+[self.E[k]-self.MV[k]] 
            for k in range(self.life) ]
        # List of EPC_k for k = 1 to N
        return [ npf.npv(self.marr,CF[k]) for k in range(self.life) ]

    def EUAC_conventional(self):
        """ Compute the EUAC for yr k, k= 1 to N using Conventional method """
        EPC = self.EPC()
        return [-npf.pmt(self.marr, k+1, EPC[k]) for k in range(self.life) ]

    def TC(self):
        """ Compute the total marginal costs for year k, k = 1 to N """
        TCk = [ self.MV0 - self.MV[0] + self.marr*self.MV0 + self.E[0]]
        for k in range(2, self.life+1):
            TCk.append(self.MV[k-2] - self.MV[k-1] 
                       + self.marr*self.MV[k-2] + self.E[k-1])
        return TCk

    def EUAC(self):
        """ Compute and the EUAC for year k, k = 1 to N using TC_k method """
        tc = self.TC()
        EPC = [npf.npv(self.marr,[0]+tc[0:k+1]) for k in range(self.life)]
        return [-npf.pmt(self.marr,k+1,EPC[k]) for k in range(self.life) ]
 
    def econ_life_euac(self):
        """ Compute ( Economic Service Life, Min EUAC ) """
        euac = self.EUAC()
        min_euac = min(euac)
        return euac.index(min_euac)+1, min_euac
        
    def TC_montotonic(self):
        """ Return True if the TC values are monotonically non-decreasing """
        tc = self.TC()
        return all(tc[k]<=tc[k+1] for k in range(self.life-1))

    def plot_TC(self, challenger_euac=None):
        """ Plot the asset's TC values """
        fig, ax = plt.subplots()
        ax.plot(range(1,self.life+1), self.TC(), 'bo', ls='--' , 
                label=self.name+" TC value")
        ax.set_xticks(range(1, self.life+1))
        ax.set_xlabel("k")
        if challenger_euac != None:
            ax.plot(range(1,self.life+1), [challenger_euac]*self.life,
            color='red', ls='-', label='Challenger EUAC*')
        ax.legend()
        ax.grid()
        plt.show()


def pprint_list(label=None, list_of_numbers=[]):
    """ Pretty format print a List of numbers """
    if label is not None:
        print(f"{label} = ", end='')
    print("".join(f'{x:,.2f}   ' for x in list_of_numbers))


#---------------------------------------------------------------------------
class LearningCurve:
    """ Learning Curve Model 
    LearningCurve(K, s)
    Parameters:
      K = time/resource for first unit.
      s = learning curve parameter (0 < s < 1)
    Attributes:
      K = time/resource for first unit.
      s = learning curve parameter 
    Methods:
      Unit(u): The time/resource required for unit u
      Cumulative(u): The cumulative time/resources for first u units
      Average(u): The average time/resource per unit for first u units 
    """
    
    def __init__(self, K, s):
        self.K = K    # time or resoruce for first unit
        self.s = s    # learning curve parameter
        self.n = np.log(s)/np.log(2)
        
    def Unit(self, u):
        """ Returns the time/resource required for unit u """
        return self.K*u**self.n
    
    def Cumulative(self, x):
        """ Returns the cumulative time/resources for up to unit x """
        return sum([self.Unit(u+1) for u in range(x)])
    
    def Average(self, x):
        """ Return the average per unit for the first x units """
        return self.Cumulative(x)/x
    
#---------------------------------------------------------------------------
