# -*- coding: utf-8 -*-
# 4.4.2_cost_projects_unequal_lives_repeatability.py
""" 4.4.2 Cost Projects with Unequal Lives - Repeatability """
from EngFinancialPy import Project_CF, Evaluate_Projects

# Pump selection problem - Repeatability assumption
# Basic project parameters
marr = 0.2
study_period = 45

# Create the Alternatives
SP240 = Project_CF(marr=marr, name="SP240")
cap_cost = -33200
e_cost = -2165
m_costY1= -1100
m_inc = -500
sv5 = 0
SP240.set_cf([cap_cost,
              e_cost + m_costY1,
              e_cost + m_costY1 + m_inc,
              e_cost + m_costY1 + m_inc*2,
              e_cost + m_costY1 + m_inc*3,
              e_cost + m_costY1 + m_inc*4 + sv5 ])
 
HEPS9 = Project_CF(marr=marr, name="HEPS9")
cap_cost = -47600
e_cost = -1720
m_costY4= -500
m_inc = -100
sv9 = 5000
HEPS9.set_cf([cap_cost, 
              e_cost, e_cost, e_cost,
              e_cost + m_costY4,
              e_cost + m_costY4 + m_inc*1,
              e_cost + m_costY4 + m_inc*2,
              e_cost + m_costY4 + m_inc*3,
              e_cost + m_costY4 + m_inc*4,
              e_cost + m_costY4 + m_inc*5 + sv9 ])
                         
# List of alternatives to be evaluated
Alternatives = [SP240, HEPS9]

# Evaluate the alternatives using AW method under repeatability assumption
best = Evaluate_Projects(Alternatives, marr=marr, method="AW")
print(f"\nChoose pump {best.name} using AW method under repeatability",
      f"assumption with a study period of {study_period} years")



