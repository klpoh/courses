# -*- coding: utf-8 -*-
# 3.7.2_financial_analysis_XYZ_company.py
""" 3.7.2 fFnancial Analysis of XYZ Company """
from EngFinancialPy import Project_CF, PnAF_cf

# Create the project cash flows and check basic attributes
XYZ = Project_CF(marr=0.1, name="XYZ Company Investment Problem")
XYZ.set_cf(PnAF_cf(Nper=5, P=-12000, A=2310, F=1000))
print(f"\n{XYZ.name}")
print(f"  life = {XYZ.life}")
print(f"  Cash flows = {XYZ.cf}")

# Compute Project Profitability Measures
print("Project Profitability Measures:")
print(f"  NPV({XYZ.marr}) = {XYZ.npv():,.2f}")
print(f"  PW({XYZ.marr}) = {XYZ.pw():,.2f}")
print(f"  AW({XYZ.marr}) = {XYZ.aw():,.2f}")
print(f"  FW({XYZ.marr}) = {XYZ.fw():,.2f}")
print(f"  IRR = {XYZ.irr():.5f}")

# Compute MIRR at financial rate = 0.15 and reinvestment rate = 0.20
print(f"  MIRR = {XYZ.mirr(fin_rate=0.15, reinv_rate=0.20):.5f}")

# Compute Project Liqidity Measures
print("Project Liquidity Measure:")
print(f"  Payback({XYZ.marr}) = {XYZ.payback()}")

# Is the project financially feasible?
print("Project Feasibilty:")
print(f"  Feasibility({XYZ.marr}) = {XYZ.is_feasible()}")










