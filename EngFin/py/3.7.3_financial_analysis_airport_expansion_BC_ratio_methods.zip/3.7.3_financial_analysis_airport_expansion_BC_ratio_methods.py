# -*- coding: utf-8 -*-
# 3.7.3_financial_analysis_airport_expansion_BC_ratio_methods.ipynb
""" 3.7.3 Financial Analysis of Airport Expansion Problem using BC ratios """
from EngFinancialPy import pub_Project, PnAF_cf

# Project data
capital_costs = -1_200_000
a_benefits =       490_000
a_disbenefits =   -100_000
a_om_costs =      -197_500
study_period =  20

# Create a public project cash flows with benefits and costs cash flows
Airport = pub_Project(marr=0.1, name="Airport expansion problem")

# Set up benefits and costs cash flows for conventional BC Ratio
B_CF = PnAF_cf(Nper=study_period, A=a_benefits+a_disbenefits)
C_CF = PnAF_cf(Nper=study_period, P=capital_costs, A=a_om_costs)
Airport.set_BC_cash_flows(Benefits_CF=B_CF, Costs_CF=C_CF)

# Compute Conventional B/C ratio
print(f"\n{Airport.name}")
print(f"  life = {Airport.life}")
print(f"  Conventional B/C Ratio = {Airport.BC_Ratio():.4f}")


# Set up benefits and costs cash flows for Modified BC Ratio
B_CF = PnAF_cf(Nper=study_period, A=a_benefits+a_disbenefits+a_om_costs)
C_CF = PnAF_cf(Nper=study_period, P=capital_costs)
Airport.set_BC_cash_flows(Benefits_CF=B_CF, Costs_CF=C_CF)

# Compute Modified B/C ratio
print(f"\n{Airport.name}")
print(f"  life = {Airport.life}")
print(f"  Modified B/C Ratio = {Airport.BC_Ratio():.4f}")

# Compute Project DCF Profitability Measures
print("\nProject Profitability Measures:")
print(f"  PW({Airport.marr}) = {Airport.pw():,.2f}")
print(f"  AW({Airport.marr}) = {Airport.aw():,.2f}")
print(f"  FW({Airport.marr}) = {Airport.fw():,.2f}")
print(f"  IRR = {Airport.irr():.5f}")

# Compute MIRR at financial rate = 0.1 and reinvestment rate = 0.1
print(f"  MIRR = {Airport.mirr(fin_rate=0.1, reinv_rate=0.1):.5f}")

# Compute Project Liqidity Measures
print("Project Liquidity Measure:")
print(f"  Payback({Airport.marr}) = {Airport.payback()}")

# Is the project financial feasible?
print("Project Feasibilty:")
print(f"  Feasibility({Airport.marr}) = {Airport.is_feasible()}")



