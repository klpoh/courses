# -*- coding: utf-8 -*-
# 8.4.4_replacement_analysis_infinite_horizon_def_TC_non_decreasing.py
""" 8.4.4 Optimal Replacement under Infinite Planning Horizon when
    Defender TC values are monotoically non-decreasing """
import numpy_financial as npf
import matplotlib.pyplot as plt
from EngFinancialPy import Asset, pprint_list

""" Econonomic replacement of old Folklift truck """                 
# Defender forklift truck 
MV0 = 5000
MV = [4000, 3000, 2000, 1000]  
E  = [5500, 6600, 7800, 8800 ]
marr = 0.1

def_forklift = Asset(MV0, MV, E, marr, age=2, 
                     name="Defender forklift truck")
    
# Best challenger EUAC under repeatability assumption.
MV0_new = 20000
MV_new = [15000, 11250, 8500, 6500,  4750 ]  
E_new  = [ 2000,  3000, 4620, 8000, 12000 ]

new_forklift = Asset(MV0_new, MV_new, E_new, marr, age=0, 
                      name="New forklift truck")

# Best challenger EUAC under repeatability assumption
challenger_econ_life, challenger_euac = new_forklift.econ_life_euac()
print(challenger_euac)
  
# Get defender's TC values
TC_def = def_forklift.TC()
pprint_list("TC", TC_def)

# Plot the defender's TC values
def_forklift.plot_TC(challenger_euac)
if def_forklift.TC_montotonic():
    print("The Defender's TC values are montonically non-decreasing")
else:
    print("The Defender's TC values are not montonically non-decreasing")
 
# Determine the optimal replacement time.
life = def_forklift.useful_life()
keep_years = [ t for t in range(0,life) if TC_def[t]<=challenger_euac ]
kstar = len(keep_years)
print(f"Replace the defender with repeatable challenger at EoY {kstar}")

# Determine the optimal EPC and EUAC
EPC_star = npf.npv(marr, [0]+TC_def[:kstar]) \
               + challenger_euac/(marr*(1+marr)**kstar)
print(f"Optimal EPC under opportunity cost approach = {EPC_star:,.2f}")
EUAC_star_CF = (EPC_star - MV0)*marr
print(f"Optimal EUAC under cash flow approach = {EUAC_star_CF:,.2f}")


""" Verify Solutions by minimizing Year-by-Year EPC(k)"""
# Compute the EPC if defender is replaced by repeatable challenger 
# after k years, for k = 0 to N.
print("\n\nVerify Solution by Minimizing Year-by-Year EPC")
EPC = [npf.npv(marr, [0]+TC_def[:k]) + challenger_euac/(marr*(1+marr)**k)
        for k in range(0, life+1) ]
pprint_list("EPC", EPC)
   
# Plot the replacement plans' EPC values    
fig, ax = plt.subplots()
ax.plot(range(life+1), EPC, 'ro', ls='--' , label='EPC ')
ax.set_xticks(range(life+1))
ax.legend()
plt.show()

# Determine the optimal replacement time.
epc_star = min(EPC)
kstar = EPC.index(epc_star)

print(f"Replace the defender with repeatable challenger at EoY {kstar}")
print(f"Optimal EPC under opportunity cost approach = {epc_star:,.2f}")
euac_star_CF = (epc_star - MV0)*marr
print(f"Optimal EUAC under cash flow approach = {euac_star_CF:,.2f}")

