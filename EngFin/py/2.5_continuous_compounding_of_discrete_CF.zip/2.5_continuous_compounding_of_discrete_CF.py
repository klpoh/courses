# -*- coding: utf-8 -*-
# 2.5_continuous_compounding_of_discrete_CF.py
"""  2.5 Continuous compounding of discrete cash flows """
from EngFinancialPy import IntFactor
import numpy as np
import numpy_financial as npf

""" Example 1 (2.5)
    Consider a loan of $1,000.  What equivalent uniform end-of-year 
    payments must be made for 10 years if the nominal interest rate 
    is 10% per year compound continuously?
"""
P = 1000
r1 = 0.1  # per year
N1 = 10   # years

# Using IntFactor class
A1 = P * IntFactor('A','P',  r1, N1, continuous=True).value
print(f"Uniform EoY payment amount = {A1:,.2f}")

# Using npf.pmt function directly
A1 = - npf.pmt(np.exp(r1)-1, N1, P, 0)
print(f"Uniform EoY payment amount = {A1:,.2f}")
             


""" Example 2 (2.5)
    In the previous example, what is the repayment amount 
    if it is to be made at the end of every six months instead?   
"""

r2= r1/2   # per six months
N2 = 2*N1  # six-month periods

# Using IntFactor class
A2 = P * IntFactor('A','P',  r2, N2, continuous=True).value
print(f"Uniform semi-annual payment amount = {A2:,.2f}")

# Using npf.pmt function directly
A2 = - npf.pmt(np.exp(r2)-1, N2, P, 0)
print(f"Uniform semi-annual payment amount = {A2:,.2f}")



             