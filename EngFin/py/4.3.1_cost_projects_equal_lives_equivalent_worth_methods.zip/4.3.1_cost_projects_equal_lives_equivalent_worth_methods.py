# -*- coding: utf-8 -*-
# 4.3.1_cost_projects_equal_lives_equivalent_worth_methods.py
""" 4.3.1 Cost Projects with Equal Lives - Equivalent Worth methods """
from EngFinancialPy import Project_CF, PnAF_cf, Evaluate_Projects

# Project basic parameters 
marr = 0.1
life = 5

# Create the alternatives
Proj_A = Project_CF(marr=marr, name="Cost Project A")
Proj_A.set_cf(PnAF_cf(Nper=life, P=-24000, A=-31200, F=0))
 
Proj_B = Project_CF(marr=marr, name="Cost Project B")
Proj_B.set_cf(PnAF_cf(Nper=life, P=-30400, A=-29128, F=0))
                       
Proj_C = Project_CF(marr=marr, name="Cost Project C")
Proj_C.set_cf(PnAF_cf(Nper=life, P=-49600, A=-25192, F=0))

Proj_D = Project_CF(marr=marr, name="Cost Project D")
Proj_D.set_cf(PnAF_cf(Nper=life, P=-52000, A=-22880, F=0))

# List of alternatives to be evaluated 
Alternatives = [Proj_A, Proj_B, Proj_C, Proj_D]

# Evaluate the alternatives using different equivalent worth methods
for method in ["PW", "AW", "FW"]:
    best = Evaluate_Projects(Alternatives, marr=marr, method=method)
    print(f"\nChoose alternative {best.name}")

