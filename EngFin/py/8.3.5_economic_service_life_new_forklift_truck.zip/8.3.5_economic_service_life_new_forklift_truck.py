# -*- coding: utf-8 -*-
# 8.3.5_economic_service_life_new_forklift_truck.py
""" 8.3.5: Economic service life of new forklift truck  """
from EngFinancialPy import Asset, pprint_list

# New Forklift Truck data
InitCost = 20000
MV = [15000, 11250, 8500, 6500,  4750 ]  
E  = [ 2000,  3000, 4620, 8000, 12000 ]
marr = 0.1

# Create a new asset with age = 0
new_forklift = Asset(InitCost,MV,E,marr,age=0,name="New forklift truck")

# Compute all relavant outputs
print(new_forklift.name)
pprint_list("EPC", new_forklift.EPC())
pprint_list("TC", new_forklift.TC())
pprint_list("EUAC", new_forklift.EUAC())
econ_life, euac_star = new_forklift.econ_life_euac()
print(f"Economic Service Life = {econ_life} yrs at EUAC*= {euac_star:,.2f}")





