# -*- coding: utf-8 -*-
# 2.4.3_find_interest_rate_equation_solver.py
""" 2.4.3 Finding interest rate using an equation solver """
from scipy.optimize import root

# Parameters and function to solve
P = 70_000
A = 1948.20
N = 48
# The function whose root we want to find
func = lambda r : (A/P)*((1-(1+r)**-N)/r)-1

# Find the root of the function using default solver hybr
guess = 0.1
solution = root(func, x0=guess, options={'xtol': 1E-10})
if solution.success:
    print(f"Interest Rate = {solution.x[0]:.8f}")
else:
    print(solution.message)
