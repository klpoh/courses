# -*- coding: utf-8 -*-
# 5.2_one_way_range_sensitivty_analsyis.py
""" 5.2 One way range sensitivty analysis """
from EngFinancialPy import OneWayRangeSensit
import numpy_financial as npf
    
# Define the objective functions for the alternatives
# Arguments must all be in the same order
def NPV(I, A, SV, N, rate):
    return I - npf.pv(rate, N, A, SV)
def DoNothing(I, A, SV, N, rate):
    return 0    

# Put the alternative names and objective functions in a dictionary
Alternatives = {"Project NPV" : NPV,
                "Do nothing" : DoNothing }

# Put the variable names and the low, base, high values in a dictionary
#          var name:     low,   base,   high values
Var_data = {'I'   : [-13225, -11500, -10350],
            'A'   : [  1800,   3000,   3750],
            'SV'  : [   900,   1000,   1100],
            'N'   : [     5,      6,      7],
            'Marr': [  0.08,    0.1,   0.12]  }

# Label for the objective function outputs
output_label = "NPV($)"

# Name of this analysis
name = "One-Way Range Sensitivty Analysis Example (5.2)"


# Create a problem instance
Project = OneWayRangeSensit(Alternatives, Var_data, name, output_label)

# Generate individual tables and tornados first
Project.sensit(show_tables=True, show_tornados=True, show_spiders=True, 
               precision=2)

# Plot combined tornados for all alternatives
Project.combined_tornados(-5000, 7000, 500)


