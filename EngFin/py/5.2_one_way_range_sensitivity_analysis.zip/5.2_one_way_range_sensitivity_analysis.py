# -*- coding: utf-8 -*-
# 5.2_one_way_range_sensitivty_analsyis.py
""" 5.2 One-Way Range Sensitivty Analysis (2025 01 26}"""
from EngFinancialPy import OneWayRangeSensit
import numpy_financial as npf

# Uncertain variable names and their [low, base, high] values
v_data = { 'I'  : [ 10350, 11500, 13225 ],
           'A'  : [  1800,  3000,  3750 ],
           'SV' : [   900,  1000,  1100 ],
           'N'  : [     5,     6,     7 ] }

# Fixed parameters name and value
f_data = {'marr' : 0.1 }

# Objective functions, one for each alternative. 
# Arguments must be in the same order as above
def npv_invest(I, A, SV, N, marr):
    return -I - npf.pv(marr, N, A, SV)
def npv_no_invest(I, A, SV, N, marr):
    return 0

# The alternative names and their objective functions 
obj_fns = { 'Invest' : npv_invest,
            'Do not invest' : npv_no_invest }

# Label for the objective function outputs
obj_label = 'NPV($)'

# Perform one-way range sensitivity analysis
Pj = OneWayRangeSensit(v_data, f_data, obj_fns, obj_label)

# Show show the base case scenario base values
Pj.base_values()

# Show sensitivity range tables
Pj.sensit_table()

# Generate individual tornado diagram
Pj.tornados()

# Plot combined tornados
Pj.combined_tornados(xlim=(-4000,6000), annotate=False)

# Plot spider diagrams
Pj.spiders()
 
