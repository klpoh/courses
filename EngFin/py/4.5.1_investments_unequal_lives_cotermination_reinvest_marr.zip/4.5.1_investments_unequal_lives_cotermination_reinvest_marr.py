# -*- coding: utf-8 -*-
# 4.5.1_investments_unequal_lives_cotermination_reinvest_marr.py
""" 4.5.1 Investment projects with unequal lives under cotermination and 
          reinvestment at marr assumptions """
from EngFinancialPy import Project_CF, PnAF_cf, Evaluate_Projects

# Project basic parameters
marr = 0.1
# study_period = 6

# Create the alternatives
Proj_A = Project_CF(marr=marr, name="Investment A")
Proj_A.set_cf(PnAF_cf(Nper=4, P=-3500, A=1900-645, F=0))
 
Proj_B = Project_CF(marr=marr, name="Investment B")
Proj_B.set_cf(PnAF_cf(Nper=6, P=-5000, A=2500-1020, F=0))
                     
# List of alternatives to be evaluated
Alternatives = [Proj_A, Proj_B]

# Evaluate the alternatives using PW method under cotermination at
# year 6 with reinvestment at marr assumption
best = Evaluate_Projects(Alternatives, marr=marr, method="PW")
print(f"\nChoose alternative {best.name} under co-termination at EoY 6",
        "with reinvestment at marr")








