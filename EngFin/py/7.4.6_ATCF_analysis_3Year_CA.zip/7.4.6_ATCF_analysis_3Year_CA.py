# -*- coding: utf-8 -*-
# 7.4.6_ATCF_analysis_3Year_CA.py
""" 7.4.6 After-tax cash flow analysis under 3-Year Capital Allowance """
from EngFinancialPy import ATCF_Analysis

# Project parameters
InitCost = 100_000
a_profit = 25_000
MV6 = 10_000
BV6 = 0
marr = 0.1
tax_rate = 0.17
        
print("\nUnder 3-Year Capital Allowance")
# Create a list of BTCF 
BTCF3 = [ (0,'C', -InitCost),
          (1,'D',  InitCost/3),
          (2,'D',  InitCost/3),
          (3,'D',  InitCost/3),
          (6,'S',  MV6, BV6),
          (1,'T',  a_profit),
          (2,'T',  a_profit),
          (3,'T',  a_profit),
          (4,'T',  a_profit),
          (5,'T',  a_profit),
          (6,'T',  a_profit) ]

# Create an ATCF_Analysis instance
ThreeY = ATCF_Analysis(BTCF3, tax_rate=tax_rate)

# Show the ATCF Table 
ThreeY.atcf_table()
# Compute after-tax profitability measures
print(f"After-tax PW  = {ThreeY.after_tax_PW(marr):9,.2f}")
print(f"After-tax AW  = {ThreeY.after_tax_AW(marr):9,.2f}")
print(f"After-tax FW  = {ThreeY.after_tax_FW(marr):9,.2f}")
print(f"After-tax IRR = {ThreeY.after_tax_IRR()*100:9.2f}%")
    


