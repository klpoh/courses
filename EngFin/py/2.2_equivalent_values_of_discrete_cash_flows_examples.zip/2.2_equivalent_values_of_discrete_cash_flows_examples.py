# -*- coding: utf-8 -*-
# 2.2_equivalent_values_of_discrete_cash_flows_examples.py
""" 2.2 Equivalent Values of Discrete Cash Flows """
from EngFinancialPy import IntFactor
import numpy_financial as npf

""" Example 1
    Suppose you invest $8,000 in a saving account that earns 10% 
    compound interest per year.  What is the amount in the account 
    at the end of 4 years? 
"""
# Using IntFactor class
F = 8000 * IntFactor('F','P', 0.1, 4).value
print(f"Amount at the end of 4 years = ${F:,.2f}")

# Using npf.fv function directly
F = - npf.fv(0.1, 4, 0, 8000)
print(f"Amount at the end of 4 years = ${F:,.2f}")


""" Example 2
    An investment is to be worth $10,000 in six years.  
    If the return on investment 8% per year compounded yearly, 
    how much should be invested today?
"""
# Using IntFactor class
P = 10000 * IntFactor('P', 'F', 0.08, 6).value
print(f"Amount to be invested now = ${P:,.2f}")

# Using npf.pv function directly
P = -npf.pv(0.08, 6, 0, 10000)
print(f"Amount to be invested now = ${P:,.2f}")


""" Example 3
    15 equal deposits of $1,000 each will be made into a bank account 
    paying 5% compound interest per year, the first deposit being one 
    year from now.  What is the balance exactly 15 years from now?
"""
# Using IntFactor class
F = 1000 * IntFactor('F', 'A', 0.05, 15).value
print(f"Balance at EoY 15 = ${F:,.2f}")

# Using npf.fv function directly
F = -npf.fv(0.05, 15, 1000, 0)
print(f"Balance at EoY 15 = ${F:,.2f}")


""" Example 4
    What is the equivalent present value of a series of end-of-year 
    equal incomes valued at $20,000 each for 5 years if the interest 
    rate is 15% per year?
"""
# Using IntFactor class
P = 20_000 * IntFactor('P', 'A', 0.15, 5).value
print(f"Equivalent present vlaue = ${P:,.2f}")

# Using npf.pv function directly
P = -npf.pv(0.15, 5, 20_000, 0)
print(f"Equivalent present vlaue = ${P:,.2f}")


""" Example 5
    If you need a lump sum of $1 million at your retirement 45 years 
    from now, how much must you save per year if the interest rate 
    is 7% per year?
"""
# Using IntFactor class
A = 1_000_000 * IntFactor('A', 'F', 0.07, 45).value
print(f"Saving per year = ${A:,.2f}")

# Using npf.pmt function directly
A = - npf.pmt(0.07, 45, 0, 1_000_000)
print(f"Saving per year = ${A:,.2f}")

""" Example 6
    Consider a loan of $8,000 to be paid back with 4 equal EoY 
    installments? What is the yearly repayment amount if the 
    interest rate is 10%?
"""
# Using IntFactor class
A = 8_000 * IntFactor('A', 'P', 0.1, 4).value
print(f"EoY payment amount = ${A:,.2f}")

# Using npf.pmt function directly
A = - npf.pmt(0.1, 4, 8_000, 0)
print(f"EoY payment amount = ${A:,.2f}")

""" Example 7
    You intend to rent a room for 12 months during your overseas 
    exchange program. The landlord asks for a monthly rent of $1,000, 
    payable at the beginning of each month. 
"""
    
# (a) If you wish to pay the rents at the end of each month instead, 
#     what amount should you pay if the time value of money to the 
#     landlord is 2% per month?

B = 1_000

# Using IntFactor class
A = B * IntFactor('F','P', 0.02, 1).value
print(f"End-of-month rent = ${A:,.2f}")

# Using npf.fv function directly
A = - npf.fv(0.02, 1, 0, B)
print(f"End-of-month rent = ${A:,.2f}")


# (b) If you wish to pay all the rents with one lump sum upon moving in 
#     instead, what amount should you pay if the time value of money to 
#     the landlord is 2% per month?

# Using IntFactor class
P = B * (1 + IntFactor('P','A', 0.02, 11).value)
print(f"One lump sum payment now = ${P:,.2f}")

# Using npf.pv function directly
P = - npf.pv(0.02, 12, B, 0, when=1)
print(f"One lump sum payment now = ${P:,.2f}")


# (c) If you wish to pay all the rents with one lump on moving out 
#     at the end of 12 months, what amount should you pay if the time 
#     value of money to the landlord is 2% per month?

# Using IntFactor class
F = B * IntFactor('F','A',0.02,12).value*IntFactor('F','P',0.02,1).value
print(f"One lump sum payment at EoY 12 = ${F:,.2f}")

# Using npf.fv function directly
F = - npf.fv(0.02, 12, B, 0, when=1)
print(f"One lump sum payment at EoY 12 = ${F:,.2f}")


""" Example 8
    Given the following cash flows 
      Year:      0    1    2     3     4     5     6     7     8
      Amount:    0  100   106   112   118   124   130   136   142
"""

# (a)  Find the equivalent present value at 10%
# Using IntFactor class
P = 100 * IntFactor('P','A', 0.1, 8).value +  \
      6 * IntFactor('P','G', 0.1, 8).value
print(f"Equivalent present vlaue = ${P:,.2f}")

# Using npf.npv function directly
P = npf.npv(0.1, [0, 100, 106, 112, 118, 124, 130, 136, 142])
print(f"Equivalent present value = ${P:,.2f}")


# (b) Find the equivalent annual value at 10%

# Using IntFactor class
A = 100 + 6 * IntFactor('A','G', 0.1, 8).value
print(f"Equivalent annual value = ${A:,.2f}")

# Using npf.npv and npf.pmt functions directly
A = - npf.pmt(0.1, 8, 
      npf.npv(0.1, [0, 100, 106, 112, 118, 124, 130, 136, 142]), 0)
print(f"Equivalent annual value = ${A:,.2f}")


# (c) Find the equivalent future value at 10%

# Using IntFactor class
F = 100 * IntFactor('F','A', 0.1, 8).value +  \
      6 * IntFactor('F','G', 0.1, 8).value
print(f"Equivalent future value = ${F:,.2f}")

# Using npf.npv and npf.fv functions directly
F = - npf.fv(0.1, 8, 0, 
      npf.npv(0.1, [0, 100, 106, 112, 118, 124, 130, 136, 142]))
print(f"Equivalent future value = ${F:,.2f}")







