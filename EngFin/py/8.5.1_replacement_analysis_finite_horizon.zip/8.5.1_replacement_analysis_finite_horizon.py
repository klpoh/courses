# -*- coding: utf-8 -*-
# 8.5.1_replacement_analysis_finite_horizon.py
""" 8.5.1 Opitmal Replacement Planning under finite study period """
import numpy_financial as npf
from EngFinancialPy import Asset, pprint_list

marr = 0.1

# Defender data
MV0_d = 5000
MV_d = [4000, 3000, 2000, 1000 ]  
E_d = [5500, 6600, 7800, 8800 ]
defender = Asset(MV0_d, MV_d, E_d, marr, name="Defender")

# Challenger data
MV0_c = 20000
MV_c = [15000, 11250, 8500, 6500,  4750 ]  
E_c = [ 2000,  3000, 4620, 8000, 12000 ]
challenger = Asset(MV0_c, MV_c, E_c, marr, age=0, name="Challenger")

# Check defender's useful life TC values
life_d = defender.useful_life()
print(f"Defender remaining life = {life_d} years")
TC_d = defender.TC()
pprint_list("Defender TC", TC_d)

# Check challenger's useful life and TC values
life_c = challenger.useful_life()
print(f"Challenger useful life = {life_c} years")
TC_c = challenger.TC()
pprint_list("Challenger TC", TC_c)
# econ_life_c, euac_star = challenger.econ_life_euac()
# print(f"Challenger econ life = {econ_life_c} yrs at EUAC*={euac_star:,.2f}") 

# Perform Replacement Analysis under finite planning horizon
print("\nReplacement Analysis under finitie planning horizon")
N = 6  # study period
print("Study period = 6 years, assume challenger is repeatable")
# Generate feasible replacement plans
plans = [(k1,k2,k3) for k1 in range(life_d+1) for k2 in range(life_c+1)
         for k3 in range(life_c+1) if (k1+k2+k3==N) and (k2>0 or k3==0)]
print(f"Number of feasible plans = {len(plans)}")


# Compute the Equivalent Present Cost of each plan
EPC_dt = {}
TC_CF_dt = {}
for k1,k2,k3 in plans:
    TC_CF = TC_d[0:k1] + TC_c[0:k2] + TC_c[0:k3]
    EPC = npf.npv(marr, [0]+TC_CF)
    EPC_dt[(k1,k2,k3)] = EPC
    TC_CF_dt[(k1,k2,k3)] = TC_CF

print("Plan, TC Cash Flows, EPC Table:")
for i, p in enumerate(plans):
    print(f"{i+1:3d}. {p}:",
          "".join(f"{x:7,.0f}" for x in TC_CF_dt[p]),
          f" ={EPC_dt[p]:10,.2f}")

# Find optimal replacement plan
best_plan, min_EPC = min(EPC_dt.items(), key=lambda x: x[1])
print(f"\nOptimal plan = {best_plan}")
print(f"Min EPC (opportunity cost) = {min_EPC:,.2f}")

# Compute EUAC over study period under cash flow approach
EUAC_cf = -npf.pmt(marr, N, min_EPC-MV0_d, 0)
print(f"Optimal EUAC (cash flow) = {EUAC_cf:,.2f}")


