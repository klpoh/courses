# -*- coding: utf-8 -*-
# 8.3.5_economic_service_life_new_asset.py
""" 8.3.5: Economic service life of new Machine A """
from EngFinancialPy import Asset, pprint_list

# New Machine A data
InitCost = 13000
MV = [9000, 8000, 6000, 2000, 0 ]  
E =  [2500, 2700, 3000, 3500, 4500]
marr = 0.1

# Create a new Asset with age = 0
new_asset = Asset(InitCost, MV, E, marr, age=0, name="Machine A")

# Compute all relavant outputs
print(new_asset.name)
pprint_list("EPC", new_asset.EPC())

# Using Conventional EUAC formula
print("Using Conventional EUAC formula:")
pprint_list("EUAC", new_asset.EUAC_conventional())

# Get TC values
pprint_list("TC", new_asset.TC())

# Using TC to compute EUAC
pprint_list("EUAC", new_asset.EUAC())

# Find economic service life and min EUAC
econ_life, euac_star = new_asset.econ_life_euac()
print(f"Economic Service Life = {econ_life} yrs at EUAC*={euac_star:,.2f}")




