# -*- coding: utf-8 -*-
# 5.4_decision_reversal_critical_factors_analysis.py
""" 5.4 Decision Reversal and Critical Factors Analysis """
import numpy as np
import numpy_financial as npf
from EngFinancialPy import IntFactor
import matplotlib.pyplot as plt
from scipy.optimize import root

# Common data
marr = 0.12
Life = 10

# Alternative A
I_A = 170_000
R_A = 35_000
E_A = 3_000 
SV_A = 20_000

# Alternative B
I_B = 120_000
R_B = 40_000
EBy1 = 2_000
EBinc = 2_500
SV_B = 0

# The objective functions
def PW_A(N, I, R, E, SV):
    """ Compute the PW of Investment A """
    return -I - npf.pv(marr, N, R-E, SV )
def PW_B(N, I, R, SV):
    """ Compute the PW of Investment B"""
    E_B = EBy1 + EBinc*IntFactor('A','G', marr, N).value
    return -I - npf.pv(marr, N, R - E_B, SV )

""" Base Case Analysis """
PW_A_base= PW_A(Life, I_A, R_A, E_A, SV_A)     
PW_B_base= PW_B(Life, I_B, R_B, SV_B)
print("Base Case Solutions:")
print(f"  PW_A({marr}) = {PW_A_base:,.2f}")
print(f"  PW_B({marr}) = {PW_B_base:,.2f}")


""" Sensitivity Analysis on Project Life """
print("\nSensitivity Analysis on Project Life")

def PW_A_life(n):
    return PW_A(n, I_A, R_A, E_A, SV_A)
def PW_B_life(n):
    return PW_B(n, I_B, R_B, SV_B)

# Plot rainbow diagram 
n = np.linspace(1, 25, 25)
f1, ax1 = plt.subplots()
ax1.plot(n, PW_A_life(n), label="Investment A")
ax1.plot(n, PW_B_life(n), label="Investment B")
ax1.vlines(Life, 0, 1.2*max(PW_A_life(Life),PW_B_life(Life)), ls='--')
ax1.legend()
ax1.set_title("Rainbow Diagram for PW vs Project Life")
ax1.set_xlabel("Project Life")
ax1.set_ylabel(f"PW({marr})")
ax1.grid()
plt.show()

# Find break points
guess = 5
# Solve PW_B(n) = 0
bp1 = root(PW_B_life, guess, options={'xtol': 1E-10}).x
print(f"\nBreak point 1 = {bp1[0]:.2f}")
# Solve PW_B(n) = PW_A(n)
bp2 = root(lambda n: PW_A_life(n) - PW_B_life(n), guess, 
           options={'xtol': 1E-10}).x
print(f"Break point 2 = {bp2[0]:.2f}")
print(f"Change in value required for decision reversal = {bp2[0]-Life:,.2f}")
print(f"%-change = {100*(bp2[0]-Life)/Life:.2f}%" )
      

""" Sensitivity analysis on Initial cost of Investment A """
print("\nSensitivity Analysis on Initial Cost of Investment A")
def PW_A_I(I):
    return PW_A(Life, I, R_A, E_A, SV_A)    

# Plot rainbow diagram 
x = np.linspace(100_000, 200_000, 101)
f2, ax2 = plt.subplots()
ax2.plot(x, PW_A_I(x), label='Investment A')
ax2.plot(x, [PW_B_base]*len(x), label='Investment B')
ax2.vlines(I_A, 0, 1.2*max(PW_A_I(I_A), PW_B_base),ls='--')
ax2.legend()
ax2.set_title("Rainbow Diagram for PW vs Initial cost of A")
ax2.set_xlabel("Initial cost of A")
ax2.set_ylabel(f"PW({marr})")
ax2.grid()
plt.show()

# Find break point
guess = 140_000
# solve PW_A(x)=PW_B_base
bp = root(lambda x: PW_A_I(x)-PW_B_base, guess, options={'xtol': 1E-10}).x
print(f"\nReveral point = {bp[0]:,.2f}")
print(f"Change in value required for decision reversal = {bp[0]-I_A:,.2f}")
print(f"%-change = {100*(bp[0]-I_A)/I_A:.2f}%")
       

""" Sensitivity analysis on Annual Income of Investment A """
print("\nSensitivity Analysis on Annual Income of Investment A")
def PW_A_R(R):
    return PW_A(Life, I_A, R, E_A, SV_A)      

# Plot rainbow diagram
x = np.linspace(0, 80_000, 101)
f3, ax3 = plt.subplots()
ax3.plot(x, PW_A_R(x), label='Investment A')
ax3.plot(x, [PW_B_base]*len(x), label='Investment B')
ax3.vlines(R_A, 0, 1.2*max(PW_A_R(R_A), PW_B_base),ls='--')
ax3.legend()
ax3.set_title("Rainbow Diagram for PW vs Annual Income of A")
ax3.set_xlabel("Annual income of A")
ax3.set_ylabel(f"PW({marr})")
ax3.grid()
plt.show()

# Find break point
guess = 40_000
# Solve PW_A(x) = PW_B_base
bp = root(lambda x: PW_A_R(x)-PW_B_base, guess, options={'xtol': 1E-10}).x
print(f"\nReveral point = {bp[0]:,.2f}")
print(f"Change in value required for decision reversal = {bp[0]-R_A:,.2f}")
print(f"%-change = {100*(bp[0]-R_A)/R_A:.2f}%")


""" Sensitivity analysis on Annual Cost of Investment A """
print("\nSensitivity Analysis on Annual Cost of Investment A")
def PW_A_E(x):
    return PW_A(Life, I_A, R_A, x, SV_A)  

# Plot rainbow diagram
x = np.linspace(-3000, 6000, 101)
f4, ax4 = plt.subplots()
ax4.plot(x, PW_A_E(x), label='Investment A')
ax4.plot(x, [PW_B_base]*len(x), label='Investment B')
ax4.vlines(E_A, 0, 1.2*max(PW_A_E(E_A), PW_B_base), ls='--')
ax4.legend()
ax4.set_title("Rainbow Diagram for PW vs Annual Cost of A")
ax4.set_xlabel("Annual cost of A")
ax4.set_ylabel(f"PW({marr})")
ax4.grid()
plt.show()

# Find break point
guess = 2_000
bp = root(lambda x: PW_A_E(x)-PW_B_base, guess, options={'xtol': 1E-10}).x
print(f"\nReveral point = {bp[0]:,.2f}")
print(f"Change in value required for decision reversal = {bp[0]-E_A:,.2f}")
print(f"%-change = {100*(bp[0]-E_A)/E_A:.2f}%")


""" Sensitivity analysis on Salvage Value of Investment A """
print("\nSensitivity Analysis on Salvage Value of Investment A")
def PW_A_SV(x):
    return PW_A(Life, I_A, R_A, E_A, x)  

# Plot rainbow diagram
x = np.linspace(0, 160_000, 101)
f5, ax5 = plt.subplots()
ax5.plot(x, PW_A_SV(x), label='Investment A')
ax5.plot(x, [PW_B_base]*len(x), label='Investment B')
ax5.vlines(SV_A, 0, 1.2*max(PW_A_SV(SV_A), PW_B_base), ls='--')
ax5.legend()
ax5.set_title("Rainbow Diagram for PW vs Salvage Value of A")
ax5.set_xlabel("Salvage Value of A")
ax5.set_ylabel(f"PW({marr})")
ax5.grid()
plt.show()

# Find break point
guess = 100_000
bp = root(lambda x: PW_A_SV(x)-PW_B_base, guess, options={'xtol': 1E-10}).x
print(f"\nReveral point = {bp[0]:,.2f}")
print(f"Change in value required for decision reversal = {bp[0]-SV_A:,.2f}")
print(f"%-change = {100*(bp[0]-SV_A)/SV_A:.2f}%")







