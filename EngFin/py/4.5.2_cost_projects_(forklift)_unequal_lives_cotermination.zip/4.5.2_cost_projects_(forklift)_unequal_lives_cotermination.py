# -*- coding: utf-8 -*-
# 4.5.2_cost_projects_(forklift)_unequal_lives_cotermination.py
""" 4.5.2 Cost projects (forklift) with unequal lives under 
    cotermination assumption """
from EngFinancialPy import Project_CF, Evaluate_Projects

# Forklift Truck Selection Problem undeer cotermination at EoY 9
# Project basic parameters
marr = 0.15
study_period = 8

# Create the alternatives
StackHigh = Project_CF(marr=marr, name="Stackhigh")
capital_cost = -184000
annual_cost = -30000
sv5 = 17000
lifeSH = 5
lease3Y = -104000
StackHigh.set_cf([capital_cost] +
                 [annual_cost]*(lifeSH-1) +
                 [annual_cost + sv5] +
                 [lease3Y]*3)
              
S2000 = Project_CF(marr=marr, name="S2000")
capital_cost = -242000
annual_cost = -26700
sv7 = 21000
lifeS2k = 7
lease1Y = -134000
S2000.set_cf([capital_cost] +
              [annual_cost]*(lifeS2k-1) +
              [annual_cost + sv7] + 
              [lease1Y])
                                         
# List of alternatives to be evaluated
Alternatives = [StackHigh, S2000]

# Evaluate the alternatives using PW method under cotermination assumption
best = Evaluate_Projects(Alternatives, marr=marr, method="PW")
print(f"\nChoose folklift {best.name} under cotermination at",
      f"EoY {study_period}")

# Evaluate the alternatives using IRR method under cotermination assumption
best = Evaluate_Projects(Alternatives, marr=marr, method="IRR")
print(f"\nChoose folklift {best.name} under cotermination at",
      f"EoY {study_period}")
