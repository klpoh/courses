# -*- coding: utf-8 -*-
# 3.3.1_find_irr_using_root_function.py
""" 3.3.1 Find IRR using root function """
from scipy.optimize import root

# Parameters
P = -12000
A = 5310-3000
F = 2000
N = 5

# The function whose root we wish to fin:
func = lambda r: P + (1-1/(1+r)**N)*A/r + F/(1+r)**N 

# Find the root of the function using default solver hybr
guess = 0.1
sol = root(func, x0=guess, options={'xtol': 1E-10})
print("\nUsing scipy.optimize.root function:")
if sol.success:
    print(f"  IRR = {sol.x[0]:.8f}")
else:
    print(sol.message)

# We can also find IRR by using npf.rate function
import numpy_financial as npf
print("\nUsing npf.rate function:")
print(f"  IRR = {npf.rate(N, A, P,F):.8f}")

