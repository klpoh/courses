# -*- coding: utf-8 -*-
# 6.5.3_monte_carlo_simulation.py
""" 6.5.3 Montel Carlo Simulation """
from EngFinancialPy import Monte_Carlo_Simulation
import numpy_financial as npf
from scipy import stats

# Fixed input variables' name and value
fixed_vars = {'marr': 0.08, 'I': -150000 }

# Random input variables' name and random variable objects
# See https://docs.scipy.org/doc/scipy/reference/stats.html for details
random_vars = {'R' : stats.norm( 70000, 4000),
               'E' : stats.norm(-43000, 2000),
               'SV': stats.uniform(1000, 3000-1000),
               'Life' : stats.randint(8, 12+1) }

# Define functions to compute output variable's values
# Arrange the arguments in the same order as above
def PW(marr, I, R, E, SV, Life):
    return I - npf.pv(marr, Life, R+E, SV)

def IRR(marr, I, R, E, SV, Life):
    return npf.rate(Life, R+E, I, SV)

# The output variable's name and functions for the simulation
output_functions = {'PW': PW, 'IRR': IRR }

# Create a simulation model instance with above data
sim_model = Monte_Carlo_Simulation(fixed_vars,random_vars,output_functions)

# Perform base case analysis when all variables are at their mean values
for name, value in sim_model.base_case().items():
    print(f"Base case value of {name} = {value:.4f}")

# Perform Monte Carlo Simulation.
status = sim_model.run(num_trials=100000)
print(status)

# Show input variables statistics and distribution
sim_model.show_inputs_values()

# show output variables statistics and distribution
sim_model.show_outputs_values()

# Perform probabilistic risk analysis on output variable PW
sim_model.Prob_Analysis_DCF('PW', 
                downsides=[-10000, -5000, 0],
                upsides=[20000, 40000, 60000, 80000, 100000])

# Perform probabilistic risk analysis on output variable IRR
marr = fixed_vars['marr']
sim_model.Prob_Analysis_rate('IRR', marr,
                  downsides =[marr-0.02, marr-0.04], 
                  upsides=[0.10, 0.15, 0.20])
    
