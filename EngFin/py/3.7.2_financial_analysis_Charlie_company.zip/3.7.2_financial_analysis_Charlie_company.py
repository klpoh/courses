# -*- coding: utf-8 -*-
# 3.7.2_financial_analysis_Charlie_company.py
""" 3.7.2 Financial Analysis of Charlie company """
from EngFinancialPy import Project_CF

# Create the project cash flows and check basic attributes
charlie = Project_CF(marr=0.2, name="Charlie Company Problem")
charlie.set_cf([-10000, -5000, 5000, 5000, 5000, 5000, 5000])
print(f"\n{charlie.name}")
print(f"  life = {charlie.life}")
print(f"  Cash flows = {charlie.cf}")

# Compute Project Profitability Measures
print("Project Profitability Measures:")
print(f"  NPV({charlie.marr}) = {charlie.npv():,.2f}")
print(f"  PW({charlie.marr}) = {charlie.pw():,.2f}")
print(f"  AW({charlie.marr}) = {charlie.aw():,.2f}")
print(f"  FW({charlie.marr}) = {charlie.fw():,.2f}")
print(f"  IRR = {charlie.irr():.5f}")

# Compute MIRR at financial rate=0.15, reinvestment rate=0.20
print(f"  MIRR = {charlie.mirr(fin_rate=0.15, reinv_rate=0.20):.5f}")

# Compute Project Liqidity Measures
print("Project Liquidity Measure:")
print(f"Payback({charlie.marr}) = {charlie.payback()}")

# Is the project financially feasible?
print("Project Feasibilty:")
print(f"  Feasibility({charlie.marr}) = {charlie.is_feasible()}")

