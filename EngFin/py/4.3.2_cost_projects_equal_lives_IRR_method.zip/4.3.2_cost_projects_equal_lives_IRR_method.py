# -*- coding: utf-8 -*-
# 4.3.2_cost_projects_equal_lives_IRR_method.py
""" 4.3.2 Investments projects with Equal Lives - IRR Methods """
from EngFinancialPy import Project_CF, PnAF_cf, Evaluate_Projects

# Project basic parameters 
marr = 0.2
study_period = 5

# Create the alternatives
Proj_D1 = Project_CF(marr=marr, name="Cost Project D1")
Proj_D1.set_cf(PnAF_cf(Nper=study_period, P=-100000, A=-29000, F=10000))
 
Proj_D2 = Project_CF(marr=marr, name="Cost Project D2")
Proj_D2.set_cf(PnAF_cf(Nper=study_period, P=-140600, A=-16900, F=14000))
                       
Proj_D3 = Project_CF(marr=marr, name="Cost Project D3")
Proj_D3.set_cf(PnAF_cf(Nper=study_period, P=-148200, A=-14800, F=25600))

Proj_D4 = Project_CF(marr=marr, name="Cost Project D4")
Proj_D4.set_cf(PnAF_cf(Nper=study_period, P=-122000, A=-22100, F=14000))

# List of alternatives to be evaluated   
Alternatives = [Proj_D1, Proj_D2, Proj_D3, Proj_D4]

# Evaluate the alternatives using IRR method
best = Evaluate_Projects(Alternatives, marr=marr, method="IRR")
print(f"\nChoose alternative {best.name}")

# Compare the results with PW method 
best = Evaluate_Projects(Alternatives, marr=marr, method="PW")
print(f"\nChoose alternative {best.name}")
