# -*- coding: utf-8 -*-
# 7.4.6_ATCF_analysis_1Year_CA.py
""" 7.4.6 After-tax cash flow analysis under 1-Year Capital Allowance """
from EngFinancialPy import ATCF_Analysis

# Project parameters
InitCost = 100_000
a_profit = 25_000
MV6 = 10_000
BV6 = 0
marr = 0.1
tax_rate = 0.17
    
print("\nUnder 1-Year Capital Allowance")

# Create a list of BTCF 
BTCF1 = [ (0,'C', -InitCost),
          (1,'D',  InitCost),
          (6,'S',  MV6, BV6),
          (1,'T',  a_profit),
          (2,'T',  a_profit),
          (3,'T',  a_profit),
          (4,'T',  a_profit),
          (5,'T',  a_profit),
          (6,'T',  a_profit) ]

# Create an ATCF_Analysis instance
OneY = ATCF_Analysis(BTCF1, tax_rate=tax_rate)

# Show the ATCF Table 
OneY.atcf_table()
# Compute after-tax profitability measures
print(f"After-tax PW  = {OneY.after_tax_PW(marr):9,.2f}")
print(f"After-tax AW  = {OneY.after_tax_AW(marr):9,.2f}")
print(f"After-tax FW  = {OneY.after_tax_FW(marr):9,.2f}")
print(f"After-tax IRR = {OneY.after_tax_IRR()*100:9.2f}%")

# You can also directly print the ATCF Table
print("\n")
ATCF_Analysis(BTCF1, tax_rate=tax_rate).atcf_table()

# You can also compute the after-tax PW directly and check its feasibility
print("\n")
if ATCF_Analysis(BTCF1, tax_rate=tax_rate).after_tax_PW(marr) >= 0:
    print("Project is feasible")
else:
    print("Project is not feasible")


