# -*- coding: utf-8 -*-
# 4.4.1_invesstment_projects_unequal_lives_repeatability.py
""" 4.4.1 Investment Projects with Unequal Lives - Repeatability """
from EngFinancialPy import Project_CF, PnAF_cf, Evaluate_Projects

# Basic project parameters
marr = 0.1
study_period = 12

# Create the alternatives
Proj_A = Project_CF(marr=marr, name="Investment A")
Proj_A.set_cf(PnAF_cf(Nper=4, P=-3500, A=1900-645, F=0))
 
Proj_B = Project_CF(marr=marr, name="Investment B")
Proj_B.set_cf(PnAF_cf(Nper=6, P=-5000, A=2500-1020, F=0))

# List of alternatives to be evaluated
Alternatives = [Proj_A, Proj_B]

# Evaluate the alternatives using AW method under repeability assumption
best = Evaluate_Projects(Alternatives, marr=marr, method="AW")
print(f"\nChoose alternative {best.name} under repeatability assumption",
      f"with study period {study_period} years")

def Pump_selection_problem_repeatability():
    """ 4.4 Pump selection problem under repeatability assumption """
    
    print("\n4.4 Selection of cost projects under repeatability assumption")
    marr = 0.2
    study_period = 45
    
    # Create the Alternatives
    SP240 = Project_CF(marr=marr, name="SP240")
    cap_cost = -33200
    e_cost = -2165
    m_costY1= -1100
    m_inc = -500
    sv5 = 0
    SP240.set_cf([cap_cost,
                  e_cost + m_costY1,
                  e_cost + m_costY1 + m_inc,
                  e_cost + m_costY1 + m_inc*2,
                  e_cost + m_costY1 + m_inc*3,
                  e_cost + m_costY1 + m_inc*4 + sv5 ])
     
    HEPS9 = Project_CF(marr=marr, name="HEPS9")
    cap_cost = -47600
    e_cost = -1720
    m_costY4= -500
    m_inc = -100
    sv9 = 5000
    HEPS9.set_cf([cap_cost, 
                  e_cost, e_cost, e_cost,
                  e_cost + m_costY4,
                  e_cost + m_costY4 + m_inc*1,
                  e_cost + m_costY4 + m_inc*2,
                  e_cost + m_costY4 + m_inc*3,
                  e_cost + m_costY4 + m_inc*4,
                  e_cost + m_costY4 + m_inc*5 + sv9 ])
                             
    # List of alternatives to be evaluated
    Alternatives = [SP240, HEPS9]
    
    # Evaluate the alternatives using AW method under repeatability assumption
    best = Evaluate_Projects(Alternatives, marr=marr, method="AW")
    print(f"\nChoose pump {best.name} using AW method under repeatability",
          f"assumption with a study period of {study_period} years")







