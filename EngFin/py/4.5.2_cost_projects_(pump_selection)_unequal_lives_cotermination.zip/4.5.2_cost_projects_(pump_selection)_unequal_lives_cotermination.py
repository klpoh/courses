# -*- coding: utf-8 -*-
# 4.5.2_cost_projects_(pump_selection)_unequal_lives_cotermination.py
""" 4.5.2 Cost projects (pump selection) with unequal lives under 
    cotermination assumption """
from EngFinancialPy import Project_CF, Evaluate_Projects

# Pump Selection Problem undeer cotermination at EoY 5
# Project basic parameters
marr = 0.2
study_period = 5

# Create the alternatives
SP240 = Project_CF(marr=marr, name="SP240")
cap_cost = -33200
e_cost = -2165
m_costY1= -1100
m_inc = -500
sv5 = 0
SP240.set_cf([cap_cost,
              e_cost + m_costY1,
              e_cost + m_costY1 + m_inc,
              e_cost + m_costY1 + m_inc*2,
              e_cost + m_costY1 + m_inc*3,
              e_cost + m_costY1 + m_inc*4 + sv5 ])
 
HEPS9 = Project_CF(marr=marr, name="HEPS9")
cap_cost = -47600
e_cost = -1720
m_costY4= -500
m_inc = -100
sv5 = 15000
HEPS9.set_cf([cap_cost, 
              e_cost, e_cost, e_cost,
              e_cost + m_costY4,
              e_cost + m_costY4 + m_inc*1 + sv5])
                         
# List of alternatives to be evaluated
Alternatives = [SP240, HEPS9]

# Evaluate the alternatives using PW method under cotermination assumption
best = Evaluate_Projects(Alternatives, marr=marr, method="PW")
print(f"\nChoose pump {best.name} under cotermination assumption",
      f"at EoY {study_period}")

# Evaluate the alternatives using AW method under cotermination assumption
best = Evaluate_Projects(Alternatives, marr=marr, method="AW")
print(f"\nChoose pump {best.name} under cotermination assumption",
      f"at EoY {study_period}")



