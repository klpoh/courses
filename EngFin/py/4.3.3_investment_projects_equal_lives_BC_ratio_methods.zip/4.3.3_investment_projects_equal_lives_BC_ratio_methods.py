# -*- coding: utf-8 -*-
# 4.3.3_investment_projects_equal_lives_BC_ratio_methods.py
""" Investment Projects with Equal Lives B/C ratio methods """
from EngFinancialPy import pub_Project, PnAF_cf, Evaluate_Projects

# Project basic parameters
marr = 0.1
study_period = 50

# Create the alternatives
Proj_A = pub_Project(marr=marr, name="Project A")
Proj_A.set_BC_cash_flows(
    Benefits_CF=PnAF_cf(Nper=study_period, A=2150000),
    Costs_CF=PnAF_cf(Nper=study_period,P=-8500000, A=-750000, F=1250000))
    
Proj_B = pub_Project(marr=marr, name="Project B")
Proj_B.set_BC_cash_flows(
    Benefits_CF=PnAF_cf(Nper=study_period, A=2265000),
    Costs_CF=PnAF_cf(Nper=study_period,P=-10000000, A=-725000, F=1750000))
    
Proj_C = pub_Project(marr=marr, name="Project C")
Proj_C.set_BC_cash_flows(
    Benefits_CF=PnAF_cf(Nper=study_period, A=2500000),
    Costs_CF=PnAF_cf(Nper=study_period,P=-12000000, A=-700000, F=2000000))
    
Do_nothing = pub_Project(marr=marr, name="Do nothing")
Do_nothing.set_BC_cash_flows(
    Benefits_CF=PnAF_cf(Nper=study_period),
    Costs_CF=PnAF_cf(Nper=study_period))
    
# List of alternatives to be evaluated   
Alternatives = [Proj_A, Proj_B, Proj_C, Do_nothing]

# Evaluate the alternatives using BC Ratio method
best = Evaluate_Projects(Alternatives, marr=marr, method="BC_Ratio")
print(f"\nChoose alternative {best.name}")

# Compare the results with PW method 
best = Evaluate_Projects(Alternatives, marr=marr, method="PW")
print(f"\nChoose alternative {best.name}")
