# -*- coding: utf-8 -*-
# 4.3.2_investment_projects_equal_lives_IRR_method.py
""" 4.3.2 Investments projects with Equal Lives - IRR Method """
from EngFinancialPy import Project_CF, PnAF_cf, Evaluate_Projects

# Project basic parameters 
marr = 0.1
study_period = 10

# Create the Alternatives
Proj_A = Project_CF(marr=marr, name="Investment A")
Proj_A.set_cf(PnAF_cf(Nper=study_period, P=-900, A=150, F=0))
 
Proj_B = Project_CF(marr=marr, name="Investment B")
Proj_B.set_cf(PnAF_cf(Nper=study_period, P=-1500, A=276, F=0))
                       
Proj_C = Project_CF(marr=marr, name="Investment C")
Proj_C.set_cf(PnAF_cf(Nper=study_period, P=-2500, A=400, F=0))

Proj_D = Project_CF(marr=marr, name="Investment D")
Proj_D.set_cf(PnAF_cf(Nper=study_period, P=-4000, A=925, F=0))

Proj_E = Project_CF(marr=marr, name="Investment E")
Proj_E.set_cf(PnAF_cf(Nper=study_period, P=-5000, A=1125, F=0))

Proj_F = Project_CF(marr=marr, name="Investment F")
Proj_F.set_cf(PnAF_cf(Nper=study_period, P=-7000, A=1425, F=0))

# To be included for investment alternatives
Do_nothing = Project_CF(marr=marr, name="Do nothing")
Do_nothing.set_cf(PnAF_cf(Nper=study_period))

# List alternatives to be evaluated 
Alternatives=[Proj_A, Proj_B, Proj_C, Proj_D, Proj_E, Proj_F, Do_nothing]

# Evaluate the alternatives using IRR method
best = Evaluate_Projects(Alternatives, marr=marr, method="IRR")
print(f"\nBest Alternative is {best.name}")
 
# Compare the results with PW method 
best = Evaluate_Projects(Alternatives, marr=marr, method="PW")
print(f"\nChoose alternative {best.name}")


