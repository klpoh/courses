# -*- coding: utf-8 -*-
# 2.8_draw_cash_flows_diagrams.py
""" 2.8 Draw Cash Flow Diagrams using CF_diagram class """
import numpy as np
import matplotlib.pyplot as plt
from EngFinancialPy import CF_diagram

def main():
    # Choose the example you want to run, or create your own.
    Example_1()
    Example_2()
    Example_3()
    pass

def Example_1():
    """ Example 1: Using unsorted dictionary of cash flows as input """
    # Cash flows is a dictionary { Time : Cash flow values }
    # Time can be in any order, zero cash flow years may be omitted. 
    CF1_dict = { 0:  -500,
                 2:  -100,
                 3:   300,
                 4:  -400,
                 5:   800,
                 8:  1000,
                 10: -500,
                 12:  600 }
    
    # Create a cash flow diagram object using default parameters
    CF_diagram(CF1_dict)
    plt.show()
    
    # Don't like the above diagram? We can customize it as you like.
    D2=CF_diagram(CF1_dict, color='red', currency="US$", time_unit='Year', 
                  time_start=-2, time_step=2, time_end=15,
                  title = "Investment ABC cash flows", figsize=(10,4))
    
    # We can make some minor changes to the instance axes attribute
    D2.axes.set_title('New bigger title in blue', fontsize=20, color='blue')
    plt.show()


def Example_2():
    """ Example 2: Use List of cash flows in chrological order """
    
    # Cash flows is a List enumerating year-by-year cash flows
    CF3_list = [-1000, 300, 300, 0, 0, 400, -500, -600]
    
    # Create a cash flow diagram
    D3 = CF_diagram(CF3_list, color='blue', figsize=(10,4),
                    title="Investment cash flows")
    
    # Change the fontsize of the xlabel and padding from the axis.
    D3.axes.set_xlabel("Year", fontsize=14, color='red', labelpad=10)
    plt.show()


def Example_3():
    """ Example 3: Using np.array of cash flows """
    
    # Cash flows is a year-by-year np.array of cash flow
    CF4 = np.array([-1000, 300, 300, 0, 0, 400, -500, -600])
    
    # Create a cash flow diagram
    D4 = CF_diagram(CF4, color='green', currency='CNY', 
                    time_start=-1, time_end=12, figsize=(10, 4),
                    title="Another investment cash flows")
    
    # Turn on the y-axis at time_start
    D4.axes.get_yaxis().set_visible(True)
    D4.axes.spines['left'].set_visible(True)
    plt.show()


if __name__=='__main__':
    main()
