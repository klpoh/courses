# -*- coding: utf-8 -*-
# 8.2.2_Exxoff_Case_Study_fit_probability_distributions.py
from scipy.stats import norm
import matplotlib.pyplot as plt
import numpy as np

""" Exxoff Problem: Fit probability distributions """
# Cost of Production
print("\nCost of Production:")
x1, q1 = 0.88, 0.5
x2, q2 = 1.11, 0.9
mu = x1
z2 = norm.ppf(q2)
sigma = (x2 - mu)/z2
print(f"mu = {mu}, sigma = {sigma:.5f}")

# Plot the results
xmin = norm.ppf(0.001, loc=mu, scale=sigma)
xmax = norm.ppf(0.990, loc=mu, scale=sigma)
x = np.linspace(xmin, xmax, 100)
y = norm.cdf(x, mu, sigma)
fig, ax = plt.subplots()
ax.plot(x, y, lw=2)
ax.plot([x1, x2],[q1,q2],'ro', ms=7)
ax.set_yticks(np.linspace(0, 1, 11))
ax.set_ylabel("Cumulative Probability")
ax.set_xlabel("X")
ax.grid()
plt.show()

# Potency Index
print("\nPotency Index:")
x1, q1 = 0.95, 0.5
x2, q2 = 1.28, 0.9
mu = x1
z2 = norm.ppf(q2)
sigma = (x2 - mu)/z2
print(f"mu = {mu}, sigma = {sigma:.5f}")

# Plot the results
xmin = norm.ppf(0.001, loc=mu, scale=sigma)
xmax = norm.ppf(0.990, loc=mu, scale=sigma)
x = np.linspace(xmin, xmax, 100)
y = norm.cdf(x, mu, sigma)
fig, ax = plt.subplots()
ax.plot(x, y, lw=2)
ax.plot([x1, x2],[q1,q2],'ro', ms=7)
ax.set_yticks(np.linspace(0, 1, 11))
ax.set_ylabel("Cumulative Probability")
ax.set_xlabel("X")
ax.grid()
plt.show()
