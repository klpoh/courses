# -*- coding: utf-8 -*-
# 7.4.3 Fitting a continuous distribution to data (2026 08 28)
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from scipy import stats

# Read the data from Excel
df = pd.read_excel('7.4.3_example_data.xlsx', "dataset_1", header=None)
data = df.dropna().values.flatten()

# Visualize the date with a density histogram
fig1, ax1 = plt.subplots()
ax1.hist(data, bins="auto", alpha=0.5, label='Data', density=True)
plt.xlabel("Value")
plt.ylabel("Density")
plt.legend()
plt.show()

# Try fitting a lognormal distribution 
dist_name = "lognorm"
dist = getattr(stats, dist_name)
# Fit distribution
params = dist.fit(data) 
ks_stat, ks_p = stats.kstest(data, dist_name, args=params)
print("\nFitted lognormal distribution with parameters:")
print(f"  shape = sigma of the underlying normal dist = {params[0]:.4f}")
print(f"  loc   = shift = {params[1]:.4f}")
print(f"  scale = exp(mu) = {params[2]:.4f}")
print("\nGoodness of fit:")
print(f"  KS statistic = {ks_stat}")
print(f"  KS p-value   = {ks_p}")

# Compare the fitted PDF with the data
fig2, ax2 = plt.subplots()
ax2.hist(data, bins="auto", alpha=0.5, label='Data', density=True)
x = np.linspace(dist.ppf(0.001, *params), dist.ppf(0.999,*params), 500)
pdf_fitted = dist.pdf(x, *params)
ax2.plot(x, pdf_fitted, lw=2, label=dist_name)
ax2.legend()
ax2.grid('dotted')
plt.show()

# Compare the fitted CDF to data empirical CDF.
xs = np.sort(data)
ys = np.arange(1, len(xs)+1) / len(xs)
fig3, ax3 = plt.subplots()
ax3.step(xs, ys, where="post", linewidth=2, label="Empirical CDF")
ax3.plot(xs, dist.cdf(xs, *params), ls="-", label=dist_name)
ax3.legend()
ax3.grid()
plt.show()
