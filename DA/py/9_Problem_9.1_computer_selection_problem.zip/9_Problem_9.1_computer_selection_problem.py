# -*- coding: utf-8 -*-
# 9_Problem_9.1_computer_selection_problem.py
from DecisionAnalysisPy import AHP3Lmodel
import numpy as np

""" Solve Problem 9.1 using AHP3Lmodel """

# Data for Computer Selection Problem
goal = "Best Computer"
main_criteria = ["Cost", "User-friendiness", "Software availability"]

# Upper triangle of criteria pairwise comparison matrix
main_cr_matrix = np.array([1/4, 1/5, 1/2 ])

alt_names = ["Computer 1", "Computer 2", "Computer 3"]
# Upper triangles of alternatives pairwise comp matrix wrt each criterion
alt_matrixs  = [ np.array([3,    5,   2 ]),
                 np.array([1/3, 1/2,  5 ]),
                 np.array([1/3, 1/7, 1/5]) ]

# Create an instance of a 3-Level AHHP model
P91 = AHP3Lmodel(goal, main_criteria, main_cr_matrix,
                 alt_names, alt_matrixs)

P91.model()

# Solve the model
results_dict = P91.solve(method='Power')
# "Power", "Algebra", "RGM", "ColsNorm", "GenEigen"
print(results_dict)

# Perform sensitivity analysis
P91.sensit()

