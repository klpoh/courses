# -*- coding: utf-8 -*-
# 10.3_Center_Relocation_Problem_complete_cost_effectiveness_analysis.py
from DecisionAnalysisPy import AHP4Lmodel, Cost_Effective_Analysis
import numpy as np

""" Drug Counseling Center Relocation Problem: 
    (a) Effectivess evaluation with AHP model using AHP4Lmodel Class
    (b) Cost-effectiveness and efficient frontier analysis using
            Cost_Effective_Analysis Class"""


# Site Effectiveness Evaluation with AHP 
goal = "Best Site for Relocation"
alternatives = ["Site 1", "Site 2", "Site 3", "Site 4", "Site 5", "Site 6"]

main_cr = ["Good conditions for staff",
           "Easy access for clients",
           "Suitability of space for center's functions",
           "Administrative convenience" ]

main_cr_mat = np.array([2, 2, 3, 
                           1, 2, 
                              1 ])

# Containers for data
sub_cr = []
sub_cr_mats = []
alt_cr_mats = []

# Main Criterion 1: "Good Conditions for staff"
# List of subcriteria for Criterion 1
sub_cr.append(["Office size",
               "Convenience of staff commuting",
               "Office attractiveness",
               "Office privacy",
               "Availability of parking" ])

# Pairwise comparison of subcriteria for Criterion 1
sub_cr_mats.append(np.array([2, 3, 3, 3,
                                2, 2, 2,
                                   1, 1,
                                      1 ]))

# Pairwise comparison of alternatives w.r.t. each subcriterion
alt_cr_mats.append([np.array([2, 9, 2,  9,  2,
                                 5, 1,  5,  1,
                                    1/5, 1, 1/4,
                                        5,  1,
                                           1/4 ]),
                    np.array([2, 1/2, 5, 9,  2,
                                 1/3, 3, 6,	 1,
                                  9, 9,  3,
                                     2, 1/3,
                                        1/6 ]),
                    np.array([1/3, 1/2, 3, 1/3, 1/3,
                                    1,  8,  1,   1,
                                        7,  1,   1,
                                           1/9, 1/8,
                                                 1 ]),
                    np.array([3, 2, 9,  3,   2,
                                 1, 3,  1,  1/2,
                                    4,  1,   1,
                                       1/3, 1/5,
                                             1 ]),
                
                    np.array([1/6, 1/3, 1, 1/9, 1/5,
                                    2,  6,	1/2,  1,
                                        3,  1/3, 1/2,
                                            1/9, 1/5,
                                                  2  ])])

# Main Criterion 2: "Easy access for clients"
# List of subcriteria for Criterion 2
sub_cr.append(["Closeness to client's homes",
               "Access to public transportation" ])

# Pairwise comparison of subcriteria for Criterion 2
sub_cr_mats.append(np.array([ 1 ]))

# Pairwise comparison of alternatives w.r.t. each subcriterion
alt_cr_mats.append([ np.array([1, 3, 1/2, 1/3,  1,
                                  3, 1/2, 1/3,  1,
                                     1/5, 1/9, 1/3,
                                          1/2,  2,
                                                3 ]),
                     np.array([1, 1, 1, 7,  1,
                                  1, 1, 7,  1,
                                     2, 9,  1,
                                        5,  1,
                                           1/7 ]) ])
                    
# Main Criterion 3: "Suitability of space for for center's functions"
# List of subcriteria for Criterion 3
sub_cr.append(["Number and suitability of counseling rooms",
               "Number and suitability of conference rooms",
               "Suitability of reception and waiting area" ])

# Pairwise comparison of subcriteria for Criterion 3
sub_cr_mats.append(np.array([ 2, 2, 2 ]))

# Pairwise comparison of alternatives w.r.t. each subcriterion
alt_cr_mats.append([np.array([1/8, 2, 1/5, 1/9, 1/5,
                                   9,  2,   1,   2,
                                      1/9, 1/9, 1/9,
                                           1/2,  1,
                                                 2 ]),
                    np.array([1, 6, 6, 1/2,  2,
                                 5,	5, 1/2,	 2,
                                    1, 1/9, 1/3,
                                       1/9,	1/3,
                                             3 ]),
                    np.array([1, 1, 5,  2,   2,
                                 1,	4, 1/2,  1,
                                    5, 1/2,	 2,
                                       1/9, 1/3,
                                             3  ])] )
  
# Main Criterion 4: "Administrative Convenience"
# List of subcriteria for Criterion 4
sub_cr.append(["Adequacy of space for admin work",
               "Flexibility of the space layout" ])

# Pairwise comparison of subcriteria for Criterion 4
sub_cr_mats.append(np.array([ 2 ]))

# Pairwise comparison of alternatives w.r.t. each subcriterion
alt_cr_mats.append([np.array([1/7, 1/5, 1/9, 1/5, 1/6,
                                    1,   1,   1,   1,
                                        1/2,  1,   1,
                                              2,   2,
                                                   1 ]),
                    np.array([1/4, 1/5,	1/9, 1,	1/4,
                                    1,   2,  4,  1,
                                        1/2, 5,  1,
                                             9,  1,
                                                1/4 ]) ])



# Create an instance of a 4-Level AHP model
DrugCenter = AHP4Lmodel(goal, main_cr, main_cr_mat, sub_cr, sub_cr_mats, 
                        alternatives, alt_cr_mats)
# Show the AHP model
DrugCenter.model()

# Compute global weights
site_global_wt = DrugCenter.solve(method="Algebra")

# Perform sensitivity analysis
DrugCenter.sensit(0.4)


# Perform Cost-effectivess and Efficient Frontier Analysis

Attributes = ['EUAC ($K)', 'Effectiveness']

EUAC = {'Site 1': 48.0, 
        'Site 2': 53.3,
        'Site 3': 54.6,
        'Site 4': 60.6, 
        'Site 5': 67.8,
        'Site 6': 47.5 }

EUAC_Eff = { site : (EUAC[site], site_global_wt[site]) for site in alternatives }

""" This is what EUAC_Eff dictionary is suppose to be
EUAC_Eff = {'Site 1': (48.0, 0.17880),
            'Site 2': (53.3, 0.19024),
            'Site 3': (54.6, 0.13756),
            'Site 4': (60.6, 0.15042),
            'Site 5': (67.8, 0.17679),
            'Site 6': (47.5, 0.16619) }
"""

# Create a Cost-Effective Analysis Problem
reloc = Cost_Effective_Analysis(Attributes, EUAC_Eff)

# Get the efficient set 
eff_set = reloc.get_efficient_set()
print("\nEfficient Sites:")
for site, values in eff_set.items():
    print(f"  {site}: {values}")

# Plot the efficient frontier
reloc.plot_efficient_frontier((40, 80), (0, 0.25), dpi=100)

