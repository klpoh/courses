# -*- coding: utf-8 -*-
# 6.3.1_Plot_Kim_utility_function_using_ExpUtilityFunction_Class.py
from DecisionAnalysisPy import ExpUtilityFunction
import numpy as np

""" Fit Kim's utility function to boundary conditions and plot it
    using ExpUtilityFunction Class """
    
# Create and plot Kim's utility function directly using L, H and RT
RT = 50/np.log(2)
f1 = ExpUtilityFunction(L=0, H=100, RT=RT)

# Plot it and display key parameters
f1.plot()
print(f"  Utility function is {f1.fun_str()}")
print(f"  Parameters = {f1.params()}")
print("Check some utility values:")
print(f"  u(0) = {f1.u(0)}")
print(f"  u(50) = {f1.u(50)}")
print(f"  u(100) = {f1.u(100)}")

# Another way is to create an instance of the function first 
# and then set the parameters
f2 = ExpUtilityFunction()
f2.set_bounds(0, 100)
f2.set_RT(RT)
f2.plot()
print(f"  Utility function is {f2.fun_str()}")
print(f"  Parameters = {f2.params()}")
print("Check some utility values:")
print(f"  u(0) = {f2.u(0)}")
print(f"  u(50) = {f2.u(50)}")
print(f"  u(100) = {f2.u(100)}")
