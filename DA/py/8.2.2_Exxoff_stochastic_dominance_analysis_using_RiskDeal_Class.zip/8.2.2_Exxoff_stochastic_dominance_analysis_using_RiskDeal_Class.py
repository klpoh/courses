# -*- coding: utf-8 -*-
# 8.2.2_Exxoff_stochastic_dominance_analysis_using_RiskDeal_Class.py
from DecisionAnalysisPy import RiskDeal
from DecisionAnalysisPy import plot_risk_profiles, is1SD, is2SD

""" Exxoff Problem: Stochastic Dominance Analysis """

# create the risky deals
Invest = RiskDeal (
    x=[-4.3464, 16.4602, 21.7300, 46.3809, 53.9320, 66.2542, 86.1339 ],
    p=[0.25000,  0.4444,  0.0278,  0.0278,  0.1111,  0.1111,  0.0278 ],
    name='Invest in R&D')

No_invest = RiskDeal(x=[0], p=[ 1 ], name='Do not invest')

# Parameters for risk profiles plotting and SD analsyis
plot_range = (-10, 90, 10)
npoints = 1000 

# Plot the invidvual risk profiles 
for deal in [Invest, No_invest]:
    print(f"\nRisk Profiles for {deal.name}:")
    deal.plot_CDF(plot_range, npoints, dpi=100)
    deal.plot_EPF(plot_range, npoints, dpi=100)

# Plot the 2 risk profiles together for comparison
print("\nRisk Profiles for Exxoff Problem")
plot_risk_profiles([Invest, No_invest], plot_range, num=npoints, 
                       CDF=True, EPF=True, dpi=100)


# Check for 1SD using is1SD function
compare_range = plot_range[:-1]
print("\nChecking for 1st Order Stochastic Dominances:")
for A, B in [(No_invest, Invest)]:
    if is1SD(A, B, compare_range, npoints): 
        print(f"  {A.name} 1SD {B.name}")
    else:            
        print(f"  {A.name} Does Not 1SD {B.name}")


# Check for 2SD using is2SD function
for A, B in [(No_invest, Invest)]:
    print(f"\nChecking if {A.name} 2SD {B.name}:")
    if is2SD(A, B, plot_range, npoints, show_plot=True, dpi=100): 
        print(f"\n{A.name} 2SD {B.name}")
    else:            
        print(f"\n{A.name} Does Not 2SD {B.name}")
