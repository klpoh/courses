# -*- coding: utf-8 -*-
# 8.4.2_LIM_stochastic_dominance_analysis.py
from DecisionAnalysisPy import RiskDeal 
from DecisionAnalysisPy import plot_risk_profiles, is1SD, is2SD

""" LIM Problem: Stochastic Dominance Analysis """

# Crate the risky deals
Train = RiskDeal( 
    x=[ 120.264,   150.786,  171.025, 187.633, 214.429, 
        230.102,   266.828,  288.499, 358.999 ],
    p=[ 0.095070, 0.137191, 0.191698, 0.042003, 0.276629,
        0.059869, 0.084695, 0.086394, 0.026451 ],
    name = 'Train User')

IPX = RiskDeal(
    x = [  115.809,  253.293,  315.189 ],
    p = [ 0.346637, 0.500215, 0.153149 ],
    name = 'Use IPX')

# Parameters for plotting and stochastic dominance analysis
plot_range = (100, 380, 20)
npoints = 1000

# Plot the invidvual risk profiles 
for deal in [Train, IPX]:
    print(f"\nRisk Profiles for {deal.name}:")
    deal.plot_CDF(plot_range, npoints, dpi=100)
    deal.plot_EPF(plot_range, npoints, dpi=100)

# Plot the 2 risk profiles together for comparison
print("\nRisk Profiles for LIM Problem")
plot_risk_profiles([Train, IPX], plot_range, num=npoints, 
                       CDF=True, EPF=True, dpi=100)

# We only need to check if "Train User" dominates "IPX".
# Check for 1SD using is1SD function
compare_range = plot_range[:-1]
print("\nChecking for 1st Order Stochastic Dominances:")
for A, B in [(Train, IPX)]:
    if is1SD(A, B, compare_range, npoints): 
        print(f"  {A.name} 1SD {B.name}")
    else:            
        print(f"  {A.name} Does Not 1SD {B.name}")


# Check for 2SD using is2SD function
for A, B in [(Train, IPX)]:
    print(f"\nChecking if {A.name} 2SD {B.name}:")
    if is2SD(A, B, plot_range, npoints, show_plot=True, dpi=100): 
        print(f"\n{A.name} 2SD {B.name}")
    else:            
        print(f"\n{A.name} Does Not 2SD {B.name}")

