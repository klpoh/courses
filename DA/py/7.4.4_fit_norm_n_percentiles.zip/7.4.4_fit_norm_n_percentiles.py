# -*- coding: utf-8 -*-
# 7.4.4 Fit normal distribution to n percentile values
import numpy as np
from scipy.stats import norm
import matplotlib.pyplot as plt

x = np.array([40,   50,  70,  80,   90 ])
p = np.array([0.05, 0.1, 0.5, 0.75, 0.9])

# Inverse standard normal CDF values
z = norm.ppf(p)
# Matrix: [1, z]
Z = np.column_stack((np.ones(len(z)), z))

# Estimate parameters
mu, sigma = np.linalg.inv(Z.T @ Z) @ Z.T @ x
print(f"mu    = {mu:.2f}")
print(f"sigma = {sigma:.2f}")

# Predicted values
x_hat = mu + sigma * z
# Residual Sum of Squares (RSS)
RSS = np.sum((x - x_hat)**2)
# Total Sum of Squares (TSS)
TSS = np.sum((x - np.mean(x))**2)
# R-squared
R_sq = 1 - RSS / TSS
print(f"R^2   = {R_sq:2f}")

# Plot the CDF of the fitted normal distribution
xmin = norm.ppf(0.01, loc=mu, scale=sigma)
xmax = norm.ppf(0.99, loc=mu, scale=sigma)
xp = np.linspace(xmin, xmax, 500)
yp = norm.cdf(xp, mu, sigma)

fig, ax = plt.subplots()
ax.plot(xp, yp, lw=2, color='blue',
        label=fr"$N({mu:.0f}, {sigma:.2f}^2)$")
ax.plot(x, p,'ro', ms=7)
ax.set_xlim(xmin,xmax)
ax.set_ylim(0,1)
ax.set_ylabel("F(x)")
ax.legend()
ax.grid()
plt.show()
