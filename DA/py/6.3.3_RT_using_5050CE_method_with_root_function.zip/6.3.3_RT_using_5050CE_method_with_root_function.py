# -*- coding: utf-8 -*-
# 6.3.3_RT_using_50-550-CE_with_root_function.py
import numpy as np
from scipy.optimize import root
""" Find Risk Tolerance using 50-50 CE method with root function"""

# The equation to solve:
# (1-np.exp(-(CE05-L)/rt))/(1-np.exp(-(H-L)/rt)) = 0.5
# Hence find the root of function:
def fun(rt, L, H, CE05):
    return (1-np.exp(-(CE05-L)/rt))/(1-np.exp(-(H-L)/rt)) - 0.5

# Case 1 (Risk Averse)
L, H, CE05 = 0, 100, 34
guess = 50
sol1 = root(fun, x0=guess, args=(L, H, CE05), method='hybr', 
                  options={'xtol':1E-12})

print(f"50-50-CE = {CE05}")
print(f"  Solver message: {sol1.message}")
print(f"  Risk Tolerance = {sol1.x[0]}")


# Case 2 (Risk Seeking)
L, H, CE05 = 0, 100, 65
guess = -50
sol2 = root(fun, x0=guess, args=(L, H, CE05), method='hybr', 
                   options={'xtol':1E-12})

print(f"50-50-CE = {CE05}")
print(f"  Solver message: {sol2.message}")
print(f"  Risk Tolerance = {sol2.x[0]}")

