# -*- coding: utf-8 -*-
# 6.2.5_Buying_Price_eq_Selling_Price_under_Delta_Property_RiskDeal_Class.py
import numpy as np
from DecisionAnalysisPy import RiskDeal

""" Demostrate Buying Price = Selling Price under Delta Property """

# Define the exponential wealth utility function and its inverse
uw = lambda w : 1 - 2**(-w/50)
uw_inv = lambda y : -50*np.log(1-y)/np.log(2)

# Fix the initial wealth
w0 = 500

# Create the base risky deal
base_deal = RiskDeal(p=[0.5,0.5], x=[10, 0], states=['up','down'])

# Compute selling and buying price of base deal at w0=500
s0 = base_deal.PISP(w0, uw, uw_inv)
print(f"Selling price of base deal = {s0:.6f}")
b0 = base_deal.PIBP(w0, uw) 
print(f"Buying price of base deal  = {b0:.6f}")
print("Notice that PISP = PIBP?")

# Compute PISP, PIBP under different delta shifts
for delta in [-20, 20, 50, 100]:
    print(f"\nDelta = {delta}:")
    shifted_deal = RiskDeal(x=[10+delta, delta], p=[0.5, 0.5], 
                              states=['up','down'])
    s1 = shifted_deal.PISP(w0, uw, uw_inv)
    # s1 = Deal.PISP(w0, wuf) # use solver instead
    print(f"  Selling price of shifted deal  = {s1:.6f}")
    print(f"    Shift in selling price = {s1-s0:.6f}")
    b1 = shifted_deal.PIBP(w0, uw) 
    print(f"  Buying price   = {b1:.6f}")
    print(f"    Shift in buying price = {b1-b0:.6f}")

print("\nNotice that Selling Price = Buying Price under all delta shifts")
print("  and they are also all shifted by delta")

