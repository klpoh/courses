# -*- coding: utf-8 -*-
# 9_Problem_9.2_John_and_Bill_problem.py
from DecisionAnalysisPy import AHPmatrix
from DecisionAnalysisPy import AHPratings_model

""" Solutions to Problem 9.2 (John and Bill problem)
    using AHPratings_model Class """

# Goal = 'Value to Company'  # Not used

# Define the Main Criteria:
Criteria = {'Names': ['Dependability','Qualification','Experience','Quality'],
            'A'    : AHPmatrix([2, 3, 4, 
                                   2, 3,
                                      2 ], upper_triangle=True)
           }

# Define the Criteria ratings and scores
Ratings = { 'Dependability': 
               {'Ratings': ['Outstanding','Average','Unsatisfactory'],
                'A' :      AHPmatrix([3, 7, 
                                         3 ], upper_triangle=True)
               },
               
            'Qualification':
               {'Ratings': ['Postgraduate','Graduate','Non-graduate'],
                'A' :      AHPmatrix([3, 5, 
                                         3 ], upper_triangle=True)
               },
               
            'Experience':
               {'Ratings': ['Exceptional','Average','Little'],
                'A' :      AHPmatrix([5, 9, 
                                         3 ], upper_triangle=True)
               }, 
               
            'Quality':
               {'Ratings': ['Outstanding','Average','Below average'],
                'A' :      AHPmatrix([5, 9, 
                                         3 ], upper_triangle=True)
               }
             }

# Create the AHP Ratings Method model
model = AHPratings_model(Criteria, Ratings, echo=False, method='GenEigen')
# Show the model created
model.show_model()
    
    
Candidates = {'John': 
                 {'Dependability': 'Average',
                  'Qualification': 'Graduate',  
                  'Experience'   : 'Average',
                  'Quality'      : 'Outstanding'
                 },

              'Bill':
                 {'Dependability': 'Outstanding',
                  'Qualification': 'Non-graduate',  
                  'Experience'   : 'Exceptional',
                  'Quality'      : 'Average'
                 }
              }
    
# Evaluate employees
scores = model.evaluate(Candidates)
print(f"{max(scores, key=scores.get)} should get higher pay increase")

model.sensit(Candidates)
    
 