# -*- coding: utf-8 -*-
# 9_Problem_9.3_investment_decision_rank_reversal_problem.py
from DecisionAnalysisPy import AHP3Lmodel
import numpy as np

""" Problem 9.3: Solve Investment decision rank reversal problem
    using AHP3model Class """
    
# Set up the common Goal and Criteria
goal = "Best Investment"
main_criteria = ["Expected Return", "Degree of Risk" ]

# Upper triangle of criteria pairwise comparison matrix
main_cr_matrix = np.array([ 1 ])


""" (a) When there are 2 alternatives """
alt_2A = ["Investment 1", "Investment 2" ]
# Upper triangles of alternatives pairwise comp matrix wrt each criterion
alt_mats_2A  = [ np.array([1/2]),
                 np.array([ 3 ]) ]

# Create a 3-Level AHHP model with 2 alternatives
P93_2A = AHP3Lmodel(goal, main_criteria, main_cr_matrix, 
                    alt_2A, alt_mats_2A)
P93_2A.model()

# Solve it
result_2A = P93_2A.solve(method='Algebra')  
# P93_2A.sensitivity_analysis()


""" (b)  When there are 3 alternatives """
alt_3A = ["Investment 1", "Investment 2", "Investment 3" ]
# Upper triangles of alternatives pairwise comp matrix wrt each criterion
alt_mats_3A  = [ np.array([1/2,  4,   8]),
                 np.array([ 3,  1/2, 1/6 ]) ]

# Create a 3-Level AHHP model with 3 alternatives
P93_3A = AHP3Lmodel(goal, main_criteria, main_cr_matrix, 
                    alt_3A, alt_mats_3A)
P93_3A.model()

# Solve it
result_3A = P93_3A.solve(method='Algebra') 

""" Compare the two results """
print("\nCompare the results:")
print("\n  When are are 2 Alternatives:")
for k, v in sorted(result_2A.items(), key=lambda x: x[1], reverse=True):
    print(f"    {k} : {v:.6f}")
   
print("\n  When are are 3 Alternatives:")
for k, v in sorted(result_3A.items(), key=lambda x: x[1], reverse=True):
    print(f"    {k} : {v:.6f}")
