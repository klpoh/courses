# -*- coding: utf-8 -*-
# 8.2.2_Exxoff_fit_and_discretize_dist_using_norm_2p_Class.py
from DecisionAnalysisPy import norm_2p

""" Exxoff Problem: Fit and discretize probability distributions
    of sensitivt variables """
def main():
    cost_of_production()
    potency_index()


def cost_of_production():
    # Data for Cost of Production
    x1, q1 = 0.88, 0.5
    x2, q2 = 1.11, 0.9

    cost = norm_2p(x1, q1, x2, q2)
    mu, sigma = cost.mu, cost.sigma
    cost.display_cdf()
    
    print("Fitted Normal distribution for cost of production:")
    print(f"  mean={mu}, std={sigma:.6f}")
    
    # Discretize the distribution using 3 branches
    nbr = 3
    dx, dp = cost.discretize(nbr)
    print(f"\n{nbr}-branch discrete approximation:")
    for n in range(nbr):
        print(f"  x{n+1}={dx[n]:.4f}, p{n+1}= {dp[n]:.6f}")

def potency_index():
    # Data for potency index
    x1, q1 = 0.95, 0.5
    x2, q2 = 1.28, 0.9

    potency = norm_2p(x1, q1, x2, q2)
    mu, sigma = potency.mu, potency.sigma
    potency.display_cdf()
    
    print("Fitted Normal distribution:")
    print(f"  mean={mu}, std={sigma:.6f}")
    
    # Discretize the distribution using 3 branches
    nbr = 3
    dx, dp = potency.discretize(nbr)
    print(f"\n{nbr}-branch discrete approximation:")
    for n in range(nbr):
        print(f"  x{n+1}={dx[n]:.4f}, p{n+1}= {dp[n]:.6f}")


if __name__ == '__main__':
    main()
