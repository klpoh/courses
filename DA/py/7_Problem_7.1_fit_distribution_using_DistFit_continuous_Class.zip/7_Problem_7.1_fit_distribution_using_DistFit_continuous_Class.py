# -*- coding: utf-8 -*-
# 7_Problem_7.1_fit_distribution_using_DistFit_continuous_Class.py
from DecisionAnalysisPy import DistFit_continuous

""" Solutions to Problem 7.1 using DistFit_continuous Class """

data = [5.3299, 4.2537, 3.1502, 3.7032, 
        1.6070, 6.3923, 3.1181, 6.5941, 
        3.5281, 4.7433, 0.1077, 1.5977,
        5.4920, 1.7220, 4.1547, 2.2799 ]

# Fit just the normal distribution
Dists = ['norm']

# Use DistFit_continuous to fit the data
p71 = DistFit_continuous(data)

# Visualise and describe the data 
bins = 6
p71.data_hist(bins=bins)
p71.data_describe()

# Do the fitting
p71.fit(Dists)

# Show the PDF and CDF of fitted distribution
p71.plot_pdf(1, dpi=100)
p71.plot_cdf(1, dpi=100)

# See the paramters
p71.parameters(1)
