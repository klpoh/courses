# -*- coding: utf-8 -*-
# 8.4.2_LIM_Sensitivity_analysis_OneWayRangeSensit_Class.py
from DecisionAnalysisPy import OneWayRangeSensit
import numpy_financial as npf

""" LIM Case Study: One-Way Range Sensitivity Analysis """

Title = "LIM Case Study"

# Objective functions, one for each alternative. 
# Arguments must be in the same order
def NPV_1(nsold, c_alpha, alpha, c_beta, beta, trg_c):
    return nsold*(30-(-npf.pv(0.03, 5, alpha*c_alpha + beta*c_beta)))*1000
def NPV_2(nsold, c_alpha, alpha, c_beta, beta, trg_c):
    return nsold*(30-(-npf.pv(0.03, 5, alpha*c_alpha)) -10 - trg_c)*1000
def NPV_3(nsold, c_alpha, alpha, c_beta, beta, trg_c):
    return (nsold*30 - max(750, 23*nsold))*1000
def NPV_4(nsold, c_alpha, alpha, c_beta, beta, trg_c):
    return -25.0*1000

# Put the alternative names and objective functions in a dictionary
Alternatives = { "Present Arrangement" : NPV_1,
                 "Train user"          : NPV_2,
                 "Contract IPX"        : NPV_3,
                 "Withdraw from market": NPV_4 }

# Put the variable names and the low, base, high values in a dictionary
Var_data = { 'Number sold'       : [  25,   30,   50],
             'Alpha repair cost' : [   9,   10,   11],
             'Alpha failure rate': [0.13, 0.15, 0.17],
             'Beta repair cost'  : [ 7.8,  8.0,  8.1],
             'Beta failure rate' : [0.68, 0.70, 0.72],
             'Training cost'     : [   4,    8,   10]}    
   
# Label for the objective function outputs
output_label = "NPV($)"

# Create a problem instance
LIM = OneWayRangeSensit(Alternatives, Var_data, Title, output_label)
# Do individual tables and tornados first
LIM.sensit(show_tables=True, show_tornados=True, precision=2)
# Generate combined tornados
LIM.combined_tornados(-200000, 400000, 50000)
