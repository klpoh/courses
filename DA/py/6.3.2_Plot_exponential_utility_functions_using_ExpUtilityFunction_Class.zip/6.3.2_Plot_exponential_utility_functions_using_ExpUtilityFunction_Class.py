# -*- coding: utf-8 -*-
# 6.3.2_Plot_exponential_utility_functions_using_ExpUtilityFunction_Class.py
from DecisionAnalysisPy import ExpUtilityFunction

""" Plot Exponential Utility Functions using ExpUtilityFunction Class """

# Example 1
RT1 = 20000 
f1 = ExpUtilityFunction(L=0, H=100000, RT=RT1)
f1.plot()
print(f"  Utility function is {f1.fun_str()}")
print(f"  Parameters = {f1.params()}")

# ExaMPLE 2
RT2 = -20000 
f2 = ExpUtilityFunction(L=0, H=100000, RT=RT2)
f2.plot()
print(f"  Utility function is {f2.fun_str()}")
print(f"  Parameters = {f2.params()}")
