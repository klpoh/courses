# -*- coding: utf-8 -*-
# 6.2.5_Kim_PISP_PIBP_for_CoinTossingGame_using_RiskDeal_Class.py
import numpy as np
from DecisionAnalysisPy import RiskDeal

""" Kim's buying and selling prices for the $100 coin tossing game.
    This example shows that Kim's PISP = PIBP for all w0 """
    
# Create the risky deal
coin_game = RiskDeal(p=[0.5, 0.5], x=[0, 100], states=['lose','win'],
                         name='Coin_Tossing_Game_100')

# Define the utility function and its inverse
RT = 50/np.log(2)
uw  = lambda w: (4/3)*(1 - np.exp(-w/RT))
uw_inv = lambda y: -RT*np.log(1-3*y/4)

# Compute buying price, selling price, and riks preimum at different w0
for w0 in [10, 100, 1000]:
    print(f"\nInitial wealth = {w0}")
            
    s1 = coin_game.PISP(w0, uw, uw_inv)
    print(f"  Selling price  = {s1:.6f}")
    
    b1 = coin_game.PIBP(w0, uw) 
    print(f"  Buying price   = {b1:.6f}")
    
    pi = ev = coin_game.EV - s1
    print(f"  Risk Premium   = {pi:.6f}")

print("Notice that PISP = PIBP, and they are independent of w0?")
