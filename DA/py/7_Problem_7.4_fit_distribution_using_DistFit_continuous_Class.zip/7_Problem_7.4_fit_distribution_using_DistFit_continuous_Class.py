# -*- coding: utf-8 -*-
# 7_Problem_7.4_fit_distribution_using_DistFit_continuous_Class.py
from DecisionAnalysisPy import DistFit_continuous
from scipy import stats
import numpy as np
import matplotlib.pyplot as plt

""" Solutions to Problem 7.4 using DistFit_continuous Class"""

data = [ 9.79,  9.23,  9.11, 9.62, 8.73, 
        11.93, 10.39,  8.68, 9.76, 9.59, 
        11.49,  9.86, 11.41, 9.60, 7.24 ]

# List of distributions to fit
Dists = [ 'beta', 'gamma', 'norm', 'lognorm', 'triang', 
          'uniform', 'laplace']

# Use DistFit_continuous to fit the data
p74 = DistFit_continuous(data)

# Visualise and describe the data
bins = 5
p74.data_hist(bins=bins)
p74.data_describe()

# Do the fitting 
p74.fit(Dists)

# Show PDFs and CDFs
p74.plot_pdf(5, bins=bins, dpi=100)
p74.plot_cdf(5, dpi=100)

# See the fitted paramters
p74.parameters(5)

# Best fit is laplace(9.6200, 0.8300)
params_fit = p74.results['params']['laplace']
print("CDF of fitted distribution:")
fig, ax = plt.subplots(dpi=100)
x = np.linspace(stats.laplace.ppf(0.001, *params_fit),
                stats.laplace.ppf(0.999, *params_fit), 100)
ax.plot(x, stats.laplace.cdf(x, *params_fit),
       'r-', lw=2, alpha=0.6, label='Laplace')
ax.plot(9.5, stats.laplace.cdf(9.5, *params_fit), 'bo')
ax.set_xticks(np.linspace(4, 15, 12))
ax.set_yticks(np.linspace(0,1,11))
ax.legend()
ax.grid()
plt.show()

print("\nProbabilty that an animal weights <= 9.5 grams =", 
          stats.laplace.cdf(9.5, *params_fit))
