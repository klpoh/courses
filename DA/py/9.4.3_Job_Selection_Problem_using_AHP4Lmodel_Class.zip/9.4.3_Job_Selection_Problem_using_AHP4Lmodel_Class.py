# -*- coding: utf-8 -*-
# 9.4.3_Job_Selection_Problem_using_AHP4Lmodel_Class.py
from DecisionAnalysisPy import AHP4Lmodel
import numpy as np

""" Solve Job Selection Problem and perform sensitivity analsyis
    using AHP4Lmodel Class. This example shows how to input a 3-Level 
    AHP model using AHP4Lmodel Class instead of AHP3Lmodel Class """

Goal = "Job Satisfaction"
alternatives = ["Company A", "Company B", "Company C"]

main_criteria = ["Research",   "Growth",   "Benefits", 
                 "Colleagues", "Location", "Reputation"]

main_criteria_matrix = np.array([1, 1, 4,  1,  1/2,
                                    2, 4,  1,  1/2,
                                       5,  3,  1/2,
                                          1/3, 1/3,
                                                1  ])

# Containers for model data
sub_criteria = []
sub_criteria_matrices = []
alt_matrices = []

# Main Criterion 1: "Research"
# List of subcriteria for Criterion 1
sub_criteria.append(None)
# Pairwise comparison of subcriteria for Criterion 1
sub_criteria_matrices.append(None)
# Pairwise comparison of alternatives w.r.t. each subcriterion
alt_matrices.append([np.array([1/4, 1/2, 3 ])])
                    
# Main Criterion 2: "Growth"
# List of subcriteria for Criterion 2
sub_criteria.append(None)
# Pairwise comparison of subcriteria for Criterion 2
sub_criteria_matrices.append(None)
# Pairwise comparison of alternatives w.r.t. each subcriterion
alt_matrices.append([ np.array([1/4, 1/5, 1/2 ])])
                    
# Main Criterion 3: "Benefits"
# List of subcriteria for Criterion 3
sub_criteria.append(None)
# Pairwise comparison of subcriteria for Criterion 3
sub_criteria_matrices.append(None)
# Pairwise comparison of alternatives w.r.t. each subcriterion
alt_matrices.append([np.array([3, 1/3, 1/7 ])])
  
# Main Criterion 4: "Colleagues"
# List of subcriteria for Criterion 4
sub_criteria.append(None)
# Pairwise comparison of subcriteria for Criterion 4
sub_criteria_matrices.append(None)
# Pairwise comparison of alternatives w.r.t. each subcriterion
alt_matrices.append([np.array([1/3, 5, 7 ])])

# Main Criterion 5: "Location"
# List of subcriteria for Criterion 5
sub_criteria.append(None)
# Pairwise comparison of subcriteria for Criterion 5
sub_criteria_matrices.append(None)
# Pairwise comparison of alternatives w.r.t. each subcriterion
alt_matrices.append([np.array([1, 7, 7 ])])

# Main Criterion 6: "Reputation"
# List of subcriteria for Criterion 6
sub_criteria.append(None)
# Pairwise comparison of subcriteria for Criterion 5
sub_criteria_matrices.append(None)
# Pairwise comparison of alternatives w.r.t. each subcriterion
alt_matrices.append([np.array([7, 9, 2 ])])

# End of model definition and data

# Create a 4-Level AHP model
JobSelect = AHP4Lmodel(Goal, main_criteria, main_criteria_matrix, 
                        sub_criteria, sub_criteria_matrices, 
                        alternatives, alt_matrices)

# Get model structure and data
JobSelect.model()

# Solve the model
result = JobSelect.solve(method="Algebra")

# print alternative global weights
print(result)

# Perform sensitivity analysis
JobSelect.sensit(ymax=1, ystep=0.1)
