# -*- coding: utf-8 -*-
# 8.2.2_Exxoff_Sensitivity_analysis_OneWayRangeSensit_Class.py
from DecisionAnalysisPy import OneWayRangeSensit
import numpy_financial as npf

""" Exxoff Problem: Sensitivty Analysis using OneWayRangeSensit Class"""
    
Title = "Exxoff Case Study"

# Define the objective function for the alternatives
# Arguments must all be in the same order
def NPV_CL(c, p, f, L):
    return -npf.pv(0.1, 5, 0, -7+max(0,-npf.pv(0.1, L, 50*f*(1-p*c))))
def NPV_1(c, p, f, L):
    return -npf.pv(0.1, 5, 0, -7-npf.pv(0.1, L, 50*f*(1-p*c)))
def NPV_2(c, p, f, L):
    return -npf.pv(0.1, 5, 0, -7)
def NPV_3(c, p, f, L):
    return 0

# Put the alternative names and objective functions in a dictionary
Alternatives = {"Invest in R&D (Closed-loop)"    : NPV_CL,
                "Invest in R&D and Market"       : NPV_1,
                "Invest in R&D and Don't market" : NPV_2,
                "Don't invest in R&D"            : NPV_3 }

# Put the variable names and the low, base, high values in a dictionary
Var_data = { 'c' : [0.65, 0.88, 1.11],
             'p' : [0.62, 0.95, 1.28],
             'f' : [0.42, 0.48, 0.54],
             'L' : [ 14,   20,   26 ] }    

# Label for the objective function outputs
output_label = "NPV($m)"

# Create a problem instance
Exxoff = OneWayRangeSensit(Alternatives, Var_data, Title, output_label)
# Do individual tables and tornados first
Exxoff.sensit(show_tables=True, show_tornados=True, precision=6)
# Generate combined tornados
Exxoff.combined_tornados(-25, 60, 5)

initial_alt = {"Invest in R&D (Closed-loop)"    : NPV_CL,
               "Don't invest in R&D"            : NPV_3 }

initial_Exxoff = OneWayRangeSensit(initial_alt, Var_data, Title, output_label)
initial_Exxoff.sensit(show_tables=False, show_tornados=False, precision=6)
initial_Exxoff.combined_tornados(-25, 60, 5)
