# -*- coding: utf-8 -*-
# 9.6.5_Employee_Evaluation_with_AHP_ratings_method_using_AHPratings_model_Class.py
""" Perform Employees Evaluation with AHP Ratings method and 
    sensitivity analysis using using AHPratings_model Class """
from DecisionAnalysisPy import AHPmatrix
from DecisionAnalysisPy import AHPratings_model

# Goal = 'Value to Company'  # Not used

# Define the Main Criteria:
Criteria = {'Names': ['Quality', 'Education', 'Experience', 'Dependability'],
             'A'   : AHPmatrix([5, 7,  3, 
                                   3, 1/3,
                                      1/5 ], upper_triangle=True) 
           }

# Define the Criteria ratings and scores
Ratings = { 'Quality' : 
               {'Ratings': ['Excellent', 'Good', 'Meet Requirements', 
                            'Need Improvements', 'Unsatisfactory'],
                'A' :       AHPmatrix([1, 5, 7, 9,
                                          3, 5, 7,
                                             3, 5,
                                                2 ], upper_triangle=True) 
               },
               
            'Education':
                {'Ratings': ['Postgraduate', 'Bachelor', 'Diploma',
                             'Below Dip'],
                 'A':       AHPmatrix([3, 5, 9,
                                          3, 7,
                                             3 ], upper_triangle=True)
                 },
                
            'Experience':
                {'Ratings': ['> 10 years', '5-10 years', '3-5 years',
                             '1-3 years', '< 1 year'],
                 'A' :      AHPmatrix([1, 3, 5, 7,
                                           2, 3, 5,
                                              2, 3,
                                                 3 ], upper_triangle=True),
                 },
                
            'Dependability':
                {'Ratings': ['Exceptional', 'Good', 'Satisfactory', 'Poor'],
                 'A' :      AHPmatrix([3, 5, 9,
                                          3, 5,
                                             3 ], upper_triangle=True) 
                 }
            }


# Create the AHP Rating Method model
model = AHPratings_model(Criteria, Ratings, echo=True, method='Algebra')
# Show the model created
model.show_model()
    
    
# Employees and their ratings for each criterion
Employees = {'John Lim':
                 {'Quality'      : 'Good',
                  'Education'    : 'Postgraduate',
                  'Experience'   : '3-5 years',
                  'Dependability': 'Satisfactory'
                  },
             'Tan Ah Huay':
                 {'Quality'      : 'Meet Requirements',
                  'Education'    : 'Diploma',
                  'Experience'   : '> 10 years',
                  'Dependability': 'Good'
                  },
             'Chow Ah Beng':
                 {'Quality'      : 'Need Improvements',
                  'Education'    : 'Below Dip',
                  'Experience'   : '1-3 years',
                  'Dependability': 'Poor'
                  },
             'Mary Lau':
                 {'Quality'      : 'Good',
                  'Education'    : 'Bachelor',
                  'Experience'   : '< 1 year',
                  'Dependability': 'Exceptional'
                 },
             'Harry Lee':
                 {'Quality'      : 'Excellent',
                  'Education'    : 'Diploma',
                  'Experience'   : '5-10 years',
                  'Dependability': 'Good'
                  }
            }

# Evaluate employees
model.evaluate(Employees)

# Perform sensitivity analysis
model.sensit(Employees, dpi=100)
