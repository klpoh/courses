# -*- coding: utf-8 -*-
# 7.4.4_Fit_normal_dist_with_2_known_percentile_values_using_norm_2p_Class.py
from DecisionAnalysisPy import norm_2p
""" Fit normal distribution with 2 known percentile values using 
        norm_2p Class """
""" The fitted distribution is then discretized """

def main():
    Example_744_Case_1()
    Example_744_Case_2()


def Example_744_Case_1():
    """ Case 1: When the mean is known """
    x1, q1 = 200, 0.5
    x2, q2 = 100, 0.2
    
    # Create a normal distribution with two known percentil values
    N1 = norm_2p(x1, q1, x2, q2)
    mu, sigma = N1.mu, N1.sigma
    N1.display_cdf()
    
    print("Given:")
    print(f"  {q1*100}th percentile = {x1}")
    print(f"  {q2*100}th percentile = {x2}")
    print("Fitted Normal distribution:")
    print(f"  mean={mu}, std={sigma:.6f}")
    
    # Discretize the fitted distribution
    for nbr in range(1, 6):
        dx, dp = N1.discretize(nbr)
        print(f"\n{nbr}-branch discrete approximation:")
        for n in range(nbr):
            print(f"  x{n+1}={dx[n]:.2f}, p{n+1}= {dp[n]:.6f}")
    

def Example_744_Case_2():
    """ Case 2: When the mean is unknown """
    x1, q1 = 100,    0.2
    x2, q2 = 352.27, 0.9
    
    # Create a normal distribution with two known percentil values
    N2 = norm_2p(x1, q1, x2, q2)
    mu, sigma = N2.mu, N2.sigma
    N2.display_cdf()
    
    print("Given:")
    print(f"  {q1*100}th percentile = {x1}")
    print(f"  {q2*100}th percentile = {x2}")
    print("Fitted Normal distribution:")
    print(f"  mean={mu}, std={sigma:.6f}")
    
    # Discretize the fitted distribution
    for nbr in range(1, 6):
        dx, dp = N2.discretize(nbr)
        print(f"\n{nbr}-branch discrete approximation:")
        for n in range(nbr):
            print(f"  x{n+1}={dx[n]:.2f}, p{n+1}= {dp[n]:.6f}")


if __name__ == "__main__":
    main()
