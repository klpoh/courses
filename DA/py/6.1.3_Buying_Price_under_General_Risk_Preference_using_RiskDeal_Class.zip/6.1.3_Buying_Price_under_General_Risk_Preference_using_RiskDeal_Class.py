# -*- coding: utf-8 -*-
# 6.1.3_Buying_Price_under_General_Risk_Preference_using_RiskDeal_Class.py
import numpy as np
from DecisionAnalysisPy import RiskDeal

""" Compute Personal Indifferent Buying Price under General Risk Preference
    using RiskDeal Class """

# Create the risky deal
D61 = RiskDeal(p=[0.7, 0.3], x=[10, -5], states=['Win','Lose'],
               name='Example_6.1')

# Define the wealth utility function. Inverse not needed.
def uw(w):
    if w >= 0:
        return np.sqrt(w)
    else:
        return -np.sqrt(-w)

# Compute the personal indifferent buying price at different w0
for w0 in [10, 100, 1000, 10000]:
    print(f"\nInitial wealth = {w0}")
           
    # Compute PIBP with default solver
    b1 = D61.PIBP(w0, uw) 
    print(f"Buying price   = {b1:.6f}")
    
    # Compute PIBP with lm solver
    b2 = D61.PIBP(w0, uw, method='lm')
    print(f"Buying price   = {b2:.6f}")
