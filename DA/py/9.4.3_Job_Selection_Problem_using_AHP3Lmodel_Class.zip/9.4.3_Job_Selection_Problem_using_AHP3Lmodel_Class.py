# -*- coding: utf-8 -*-
# 9.4.3_Job_Selection_Problem_using_AHP3Lmodel_Class.py
from DecisionAnalysisPy import AHP3Lmodel
import numpy as np

""" Solve Job Selection Problem and perform Sensitivity Analysis 
    using AHP3Lmodel Class """

# Define your AHP model and data here
Goal = "Job Satisfaction"
main_criteria = ["Research",   "Growth",   "Benefits", 
                 "Colleagues", "Location", "Reputation"]
# Upper triangle of criteria pairwise comparison matrix
main_criteria_matrix = np.array([1, 1, 4,  1,  1/2,
                                    2, 4,  1,  1/2,
                                       5,  3,  1/2,
                                          1/3, 1/3,
                                                1  ])

alternatives = ["Company A", "Company B", "Company C"]

# Upper triangles of alternatives pairwise comp matrix wrt each criterion
alt_matrices  = [ np.array([1/4, 1/2,  3 ]),  # wrt Research
                  np.array([1/4, 1/5, 1/2]),  # wrt Growth
                  np.array([ 3,  1/3, 1/7]),  # wrt Benefits
                  np.array([1/3,  5,   7 ]),  # wrt Colleagues
                  np.array([ 1,   7,   7 ]),  # wrt Location
                  np.array([ 7,   9,   2 ]),  # wrt Reputation
                ]

# End of model definition and data
 
# Create a 3-Level AHP model
JobSelect = AHP3Lmodel(Goal, main_criteria, main_criteria_matrix,
                       alternatives, alt_matrices)

# Get model structure and data
JobSelect.model()

# Solve the model
results = JobSelect.solve(method='Algebra')
# "Power", "Algebra", "RGM", "ColsNorm", "GenEigen"

# Print just the alterative global weights 
print(results)

# Perform Sensitivity Analysis
JobSelect.sensit()
