# -*- coding: utf-8 -*-
# Employee Rating example (no excel) (2026 04 19)
from DApy.mcdm import AHPRating
import numpy as np
import pandas as pd

criteria = ['Quality','Education','Experience','Dependability']

criteria_pcm = np.array([
    [1,   5,   7,  3], 
    [1/5, 1,   3, 1/3],
    [1/7, 1/3, 1,  1/5], 
    [1/3,  3,  5,   1]])


rating_scales = {
    'Quality':   ['Excellent', 'Good', 'Meet Requirements', 'Need Improvements', 'Unsatisfactory'],
    'Education': ['Postgraduate', 'Bachelor', 'Diploma','Below Dip'],
    'Experience':['>10 years', '5-10 years', '3-5 years', '1-3 years', '<1 year'],
    'Dependability': ['Exceptional', 'Good', 'Satisfactory', 'Poor'] 
    }
  
# Set up Rating System
rating_pcms = {
    'Quality': np.array([
        [ 1,   1,   5,   7,  9],
        [ 1,   1,   3,   5,  7],
        [1/5, 1/3,  1,   3,  5],
        [1/7, 1/5, 1/3,  1,  2],
        [1/9, 1/7, 1/5, 1/2, 1]
        ]),
    'Education': np.array([
        [ 1,   3,   5,  9],
        [1/3,  1,   3,  7],
        [1/5, 1/3,  1,  3],
        [1/9, 1/7, 1/3, 1]
        ]),
    'Experience': np.array([
        [ 1,   1,   3,   5,  7],
        [ 1,   1,   2,   3,  5],
        [1/3, 1/2,  1,   2,  3],
        [1/5, 1/3, 1/2,  1,  3],
        [1/7, 1/5, 1/3, 1/3, 1]
        ]),
    'Dependability': np.array([
        [ 1,   3,   5,  9],
        [1/3,  1,   3,  5],
        [1/5, 1/3,  1,  3],
        [1/9, 1/5, 1/3, 1]
        ]) 
    }

emp_eval = AHPRating(criteria, criteria_pcm, rating_scales, rating_pcms)

# See rating system details
emp_eval.rating_system_details()

# Build your own candidate rating as follows. 
employee_ratings = [
    {'Name': 'John Lim',
     'Ratings': {'Quality'      : 'Good',
                 'Education'    : 'Postgraduate',
                 'Experience'   : '3-5 years',
                 'Dependability': 'Satisfactory'
                }},
    {'Name': 'Tan Ah Huay',
     'Ratings': {'Quality'      : 'Meet Requirements',
                  'Education'    : 'Diploma',
                  'Experience'   : '>10 years',
                  'Dependability': 'Good'
                  }},
    {'Name': 'Chow Ah Beng',
     'Ratings':  {'Quality'      : 'Need Improvements',
                  'Education'    : 'Below Dip',
                  'Experience'   : '1-3 years',
                  'Dependability': 'Poor'
                  }},
    {'Name': 'Mary Lau',
     'Ratings':  {'Quality'      : 'Good',
                  'Education'    : 'Bachelor',
                  'Experience'   : '<1 year',
                  'Dependability': 'Exceptional'
                 }},
    {'Name': 'Harry Lee',
     'Ratings':  {'Quality'      : 'Excellent',
                  'Education'    : 'Diploma',
                  'Experience'   : '5-10 years',
                  'Dependability': 'Good'
                  }}
    ]

# Evaluate the candidates
eval_results = emp_eval.evaluate(employee_ratings)

if eval_results is not None:
    # Make sure we see everything in one whole table.
    pd.set_option('display.max_columns', 100,
                   'display.max_colwidth', 100,
                   'display.width', 500)
    print(eval_results)
    
    # Run sensitivity_analysis on all candidates
    emp_eval.sensit()
    # Run sensitivity on a specific list of candidates
    emp_eval.sensit(['John Lim','Chow Ah Beng'])
