# -*- coding: utf-8 -*-
# IE5203 2022 MT Question 5 (2026 04 19)
import networkx as nx
from DApy.bn import DSepAnalysis

# Define the nodes and their parents
Parents = {'A': [], 
           'B': [], 
           'C': [], 
           'D': [], 
           'E': ['A'], 
           'F': ['B','C'],
           'G': ['C'],
           'H': ['D','G'],
           'I': ['E'],
           'J': ['F'],
           'K': [],
           'L': ['H'],
           'M': ['I'],
           'N': ['I','J'],
           'O': ['J','K'],
           'P': ['K','L'],
           'Q': ['L'],
           'R': ['M'],
           'S': ['N'],
           'T': ['O'],
           'U': ['P'],
           'W': ['Q'] }

# List of directed arcs
Edges = [(p, child) for child, par in Parents.items() for p in par]

# Create the graph
G = nx.DiGraph()
G.add_edges_from(Edges)

# Positions to draw the nodes 
sin60 = 3**(1/2)/2 
pos = {'R': (0, 0),
       'S': (1, 0),
       'T': (2, 0),
       'U': (3, 0),
       'W': (4, 0),
       'M': (0, sin60),
       'N': (1, sin60),
       'O': (2, sin60),
       'P': (3, sin60),
       'Q': (4, sin60),
       'I': (0.5, 2*sin60),
       'J': (1.5, 2*sin60),
       'K': (2.5, 2*sin60),
       'L': (3.5, 2*sin60),
       'E': (0.5, 3*sin60),
       'F': (1.5, 3*sin60),
       'G': (2.5, 3*sin60),
       'H': (3.5, 3*sin60),
       'A': (0, 4*sin60),
       'B': (1, 4*sin60),
       'C': (2, 4*sin60),
       'D': (3.5, 4*sin60) }

dag = DSepAnalysis(G)

# Question 5(a)
X = {'A'}
Y = {'W'}
Z = {'J'}

dag.plot(X, Y, Z, pos=pos, figsize=(8,4),
         title="MidTerm 2022 Q5(a)")

# Use networkx built-in d-separation analyser
print("\nUsing networkx built-in d-separation analyser")
print(f"  {X}⊥{Y}|{Z} is {dag.is_d_separated(X, Y, Z)}")

# Path-by-path blocking analysis
dag.path_blocking_analysis(X, Y, Z)

# Question 5(b)
X = {'A'}
Y = {'W'}
Z = {'N'}

dag.plot(X, Y, Z, pos=pos, figsize=(8,4),
         title="MidTerm 2022 Q5(b)")

# Use networkx built-in d-separation analyser
print("\nUsing networkx built-in d-separation analyser")
print(f"  {X}⊥{Y}|{Z} is {dag.is_d_separated(X, Y, Z)}")

# Path-by-path blocking analysis
dag.path_blocking_analysis(X, Y, Z)


    