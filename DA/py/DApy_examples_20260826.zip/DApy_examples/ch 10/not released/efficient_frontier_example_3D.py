# -*- coding: utf-8 -*-
## Add the parent directory '..' to the search path
import sys, os
sys.path.append(os.path.abspath('..'))

from DApy.mcdm import ParetoAnalysis
import matplotlib.pyplot as plt
# Example on Parento Analysis for 3 attributes case (2026 04 18)

data3D = {
 'P1':  (13.7454, 29.5071, 37.3199),
 'P2':  (15.9866, 21.5602, 31.5599),
 'P3':  (10.5808, 28.6618, 36.0112),
 'P4':  (17.0807, 20.2058, 39.6991),
 'P5':  (18.3244, 22.1234, 31.8182),
 'P6':  (11.8340, 23.0424, 35.2476),
 'P7':  (14.3195, 22.9123, 36.1185),
 'P8':  (11.3949, 22.9214, 33.6636),
 'P9':  (14.5607, 27.8518, 31.9967),
 'P10': (15.1423, 25.9241, 30.4645),
 'P11': (16.0754, 21.7052, 30.6505),
 'P12': (19.4889, 29.6563, 38.0839),
 'P13': (13.0461, 20.9767, 36.8423),
 'P14': (14.4015, 21.2204, 34.9518),
 'P15': (10.3439, 29.0932, 32.5878),
 'P16': (16.6252, 23.1171, 35.2007),
 'P17': (15.4671, 21.8485, 39.6958),
 'P18': (17.7513, 29.3949, 38.9483),
 'P19': (15.9790, 29.2187, 30.8849),
 'P20': (11.9598, 20.4523, 33.2533),
 'P21': (13.8868, 22.7135, 38.2874),
 'P22': (13.5675, 22.8093, 35.4269),
 'P23': (11.4092, 28.0219, 30.7455),
 'P24': (19.8689, 27.7224, 31.9872),
 'P25': (10.0552, 28.1546, 37.0686),
 'P26': (17.2901, 27.7127, 30.7404),
 'P27': (13.5847, 21.1587, 38.6310),
 'P28': (16.2329, 23.3089, 30.6356),
 'P29': (13.1098, 23.2518, 37.2961),
 'P30': (16.3756, 28.8721, 34.7221)
}

# Test all combinations of min/max.
maxmin = ['max','min']
directions_list = [(d1, d2, d3) 
    for d1 in maxmin for d2 in maxmin for d3 in maxmin]
for dirs in directions_list:
    print(f"Directions: {dirs}")
    pa3d = ParetoAnalysis(data3D, dirs, labels=['x','y','z'])
    eff = pa3d.efficient_points()
    for k, v in eff.items():
        print(f"{k:3}: {', '.join([f'{x:6.3f}' for x in v])}")
    ax = pa3d.plot_frontier()
    # Customise the axes anyway you like
    ax.set_title(f"Efficient frontier {dirs}")
    plt.show()
    # Check if a new point is efficient
    print(pa3d.is_efficient((20,30,40)))
    
