# -*- coding: utf-8 -*-
# AHP model for Drug Counseling Center Relocation (2026 04 19)
from DApy.mcdm import AHPNode, AHPModel
import numpy as np

alternatives = ['Site 1','Site 2','Site 3','Site 4','Site 5','Site 6']
  
goal_pcm = np.array([
    [ 1,   2,  2, 3],
    [1/2,  1,  1, 2],
    [1/2,  1,  1, 1],
    [1/3, 1/2, 1, 1]   
])

goal = AHPNode("Goal", pcm=goal_pcm)

C1 = AHPNode('Good conditions for staff')
C2 = AHPNode('Easy access for clients')
C3 = AHPNode('Suitability of space')
C4 = AHPNode('Administrative convenience')

goal.children = [C1,C2,C3,C4]

# Subcriteria for C1 'Good conditions for staff'
C11 = AHPNode('Office size')
C12 = AHPNode('Staff commuting')
C13 = AHPNode('Office attractiveness')
C14 = AHPNode('Office privacy')
C15 = AHPNode('Staff parking')
C1.children = [C11,C12,C13,C14,C15]
C1.pcm = np.array([
    [ 1,   2,  3, 3, 3],
    [1/2,  1,  2, 2, 2],
    [1/3, 1/2, 1, 1, 1],
    [1/3, 1/2, 1, 1, 1],
    [1/3, 1/2, 1, 1, 1]
 ])

# Subcriteria for C2 'Easy access for clients'
C21 = AHPNode("Close to client's home")
C22 = AHPNode('Access to public transport')

C2.children = [C21,C22]
C2.pcm = np.array([
    [1, 1],
    [1, 1]
 ])

# Subcriteria for C3 'Suitability of space'
C31 = AHPNode('Counceling rooms')
C32 = AHPNode('Conference rooms')
C33 = AHPNode('Reception area')
C3.children = [C31,C32,C33]
C3.pcm = np.array([
  [ 1,   2,  2],
  [1/2,  1,	 2],
  [1/2, 1/2, 1]
])

# Subcriteria for C4 'Administrative convenience'
C41 = AHPNode('Adequacy of space')
C42 = AHPNode('Flexibilty of space')

C4.children = [C41,C42]
C4.pcm = np.array([
    [ 1,  2],
    [1/2, 1]
 ])

# Alternative PCMs
C11.alt_pcm = np.array([
    [ 1,   2,  9,  2,  9,  2 ],
    [1/2,  1,  5,  1,  5,  1 ],
    [1/9, 1/5, 1, 1/5, 1, 1/4],
    [1/2,  1,  5,  1,  5,  1 ],
    [1/9, 1/5, 1, 1/5, 1, 1/4],  
    [1/2,  1,  4,  1,  4,  1 ]
])

C12.alt_pcm = np.array([
    [1,	   2,  1/2,  5,  9,  2 ],
    [1/2,  1,  1/3,  3,  6,  1 ],
    [2,	   3,	1,	 9,  9,  3 ],
    [1/5, 1/3, 1/9,  1,  2, 1/3],
    [1/9, 1/6, 1/9, 1/2, 1, 1/6],
    [1/2,  1,  1/3,  3,  6,  1 ]
])

C13.alt_pcm = np.array([
    [ 1,  1/3, 1/2, 3, 1/3, 1/3],  
    [ 3,   1,   1,  8,  1,   1 ],
    [ 2,   1,   1,  1,  1,   1 ],
    [1/3, 1/8,  1,  1, 1/9, 1/8],  
    [ 3,   1,   1,  9,  1,   1 ],
    [ 3,   1,   1,  8,  1,   1 ]
])
    
C14.alt_pcm = np.array([
    [ 1,   3,	2,	9,	3,   2 ],
    [1/3,  1,   1,	3,	1,  1/2],  
    [1/2,  1,	1,	4,	1,	 1 ],
    [1/9, 1/3, 1/4, 1, 1/3, 1/2],
    [1/3,  1,	1,	3,	1,	 1 ],
    [1/2,  2,	1,	2,	1,	 1 ]
])

C15.alt_pcm = np.array([
    [1, 1/6, 1/3, 1, 1/9, 1/5],
    [6,	 1,	  2,  6, 1/2,  1 ],
    [3,	1/2,  1,  3, 1/3, 1/2],
    [1,	1/6, 1/3, 1, 1/9, 1/5],
    [9,	 2,   3,  9,  1,   2 ],
    [5,	 1,	  2,  5, 1/2,  1 ]
])

C21.alt_pcm = np.array([
    [ 1,   1,	3, 1/2, 1/3,  1 ],
    [ 1,   1,	3, 1/2, 1/3,  1 ],
    [1/3, 1/3,  1, 1/5, 1/9, 1/3], 
    [ 2,   2,	5,	1,	1/2,  2 ],
    [ 3,   3,	9,	2,   1,	  3 ],
    [ 1,   1,	3, 1/2, 1/3,  1 ]
])
    
C22.alt_pcm = np.array([
    [ 1,   1,   1,   1,	 7,	 1 ],
    [ 1,   1,   1,   1,	 7,  1 ],
    [ 1,   1,   1,	 2,	 9,  1 ],
    [ 1,   1,  1/2,  1,  5,	 1 ],
    [1/7, 1/7, 1/9, 1/5, 1, 1/7],
    [ 1,   1,	1,	 1,	 7,	 1 ]
])

C31.alt_pcm = np.array([
    [ 1,  1/8, 2, 1/5, 1/9, 1/5],
    [ 8,   1,  9,  2,	1,	 2 ],
    [1/2, 1/9, 1, 1/9, 1/9, 1/9],
    [ 5,  1/2, 9,  1,  1/2,  1 ],
    [ 9,   1,  9,  2,	1,	 2 ],
    [ 5,  1/2, 9,  1,  1/2,  1 ],
])
    
C32.alt_pcm = np.array([
    [ 1,	1,	6,	6, 1/2,  2 ],
    [ 1,	1,	5,	5, 1/2,  2 ],
    [1/6, 1/5,  1,	1, 1/9, 1/3],
    [1/6, 1/5, 	1,	1, 1/9, 1/3], 
    [ 2,   2,	9,	9,	1,	 3 ],
    [1/2, 1/2,  3,	3, 1/3,  1 ],
])
    
C33.alt_pcm = np.array([
    [ 1,   1,	1,	5,	2,	 2 ],
    [ 1,   1,	1,	4, 1/2,	 1 ],
    [ 1,   1,	1,	5, 1/2,  2 ],
    [1/5, 1/4, 1/5,	1, 1/9, 1/3],
    [1/2,  2,	2,	9,	1,	 3 ],
    [1/2,  1,  1/2,	3, 1/3,  1 ]
])

C41.alt_pcm = np.array([
    [ 1, 1/7, 1/5, 1/9, 1/5, 1/6],
    [ 7,  1,   1,	1,   1,	  1 ],
    [ 5,  1,   1,  1/2,  1,   1 ],
    [ 9,  1,   2,   1,   2,   2 ],
    [ 5,  1,   1,  1/2,  1,   1 ],
    [ 6,  1,   1,  1/2,  1,	  1 ],
])       

C42.alt_pcm = np.array([
    [ 1, 1/4, 1/5, 1/9, 1, 1/4],
    [ 4,  1,   1,   2,  4,  1 ],
    [ 5,  1,   1,  1/2, 5,  1 ],
    [ 9, 1/2,  2,   1,	9,  1 ],
    [ 1, 1/4, 1/5, 1/9, 1, 1/4],
    [ 4,  1,   1,   1,  4,  1 ]
]) 

# Build and solve the model
model = AHPModel(goal, alternatives)
model.solve()
model.plot_global_weights()
model.plot_text_tree()
model.sensit()
model.display_model()
model.plot_hierarchy(title='Counselling Center Relocation Problem',figsize=(16,8))
    
