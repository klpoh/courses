# -*- coding: utf-8 -*-

# Perform Cost-effectivess and Efficient Frontier Analysis (2026 04 19)
from DApy.mcdm import ParetoAnalysis
import matplotlib.pyplot as plt

# Cost and effectiveness scores have been computed.

labels = ['EUAC ($K)', 'Effectiveness']

cost_eff_data = {
    'Site 1': (48.0, 0.17880),
    'Site 2': (53.3, 0.19024),
    'Site 3': (54.6, 0.13756),
    'Site 4': (60.6, 0.15042),
    'Site 5': (67.8, 0.17679),
    'Site 6': (47.5, 0.16619) 
    }

pa = ParetoAnalysis(cost_eff_data, ['min','max'], 
                    labels=['EUAC($)','Effectivess'])

eff_sites = pa.efficient_points()

ax = pa.plot_frontier()
# Customise the axes any way you like
ax.set_title("Efficient frontier for Counselling Center Relocation")
ax.set_xlim(40,80)
ax.set_ylim(0.1,0.2)
ax.grid()
plt.show()

# Sort eff solutions by increasing cost
sorted_sites = dict(sorted(eff_sites.items(), key=lambda item: item[1][0]))
for k, v in sorted_sites.items():
    print(f"{k:3}: {', '.join([f'{x:6.3f}' for x in v])}")
