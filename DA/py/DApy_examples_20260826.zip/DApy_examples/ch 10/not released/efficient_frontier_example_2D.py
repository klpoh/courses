# -*- coding: utf-8 -*-
# Example on Parento Analysis for 2 attributes case (2026 04 19)
from DApy.mcdm import ParetoAnalysis
import matplotlib.pyplot as plt

# Big data set
data2D = {
    "P1": (13.5, 22.3),
    "P2": (10.8, 21.2),
    "P3": (12.5, 16.0),
    "P4": (14.4, 21.6),
    "P5": (13.7, 23.560),
    "P6": (8.0, 24.4),
    "P7": (11.9, 20.4),
    "P8": (9.6, 21.1),
    "P9": (9.7, 17.3),
    "P10": (10.8, 14.0),
    "P11": (10.2, 18.9),
    "P12": (12.9, 22.5),
    "P13": (11.5, 19.1),
    "P14": (10.2, 18.5),
    "P15": (10.8, 18.0),
    "P16": (10.6, 21.1),
    "P17": (12.9, 23.6),
    "P18": (9.590, 23.6),
    "P19": (10.6, 18.8),
    "P20": (8.2, 19.0),
    "P21": (4.8, 16.8),
    "P22": (11.3, 25.8),
    "P23": (11.7, 18.4),
    "P24": (8.0, 16.0),
    "P25": (14.5, 16.2),
    "P26": (7.0, 20.9),
    "P27": (10.0, 17.3),
    "P28": (9.6, 21.1),
    "P29": (13.0, 21.9),
    "P30": (12.9, 22.9),
}


maxmin = ['max','min']
directions_list = [(d1, d2) 
        for d1 in maxmin for d2 in maxmin]
                   
for dirs in directions_list:
    print(f"Directions: {dirs}")
    pa2d = ParetoAnalysis(data2D, dirs, labels=['z11','z22'])
    eff = pa2d.efficient_points()
    for k, v in eff.items():
        print(f"{k:3}: {', '.join([f'{x:6.3f}' for x in v])}")
    ax = pa2d.plot_frontier()
    # Customise the axes any way you like
    ax.set_title(f"Efficient frontier {dirs}")
    ax.grid()
    ax.set_xlim(4,16)
    ax.set_ylim(12,28)
    plt.show()
    # Check if new point is efficient
    print(pa2d.is_efficient((20,30)))

