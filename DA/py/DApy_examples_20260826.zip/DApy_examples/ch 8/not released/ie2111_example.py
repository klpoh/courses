# -*- coding: utf-8 -*-
# IE2111 Chapter 5 example (2026 04 19)

from DApy.sensit import OneWaySensitivity
import pandas as pd
import numpy_financial as npf

data = {'I'   : [-13225, -11500, -10350],
        'A'   : [  1800,   3000,   3750],
        'SV'  : [   900,   1000,   1100],
        'N'   : [     5,      6,      7],
        'rate': [  0.08,    0.1,   0.12]  }

scenarios = ['Invest', "Don't Invest"]
    
def npv_1(I, A, SV, N, rate):
    return I - npf.pv(rate, N, A, SV)
def npv_2(I, A, SV, N, rate):
    return 0  

obj_func = [npv_1, npv_2]
colors = ['blue','orange','green']
value_label = "NPV ($)"

# Plot individual tornados
table_dfs = []
pd.set_option('display.max_columns', None)
for i, name in enumerate(scenarios):
    m = OneWaySensitivity(obj_func[i], data, label=name)
    df = m.sensit()
    m.plot_tornado(colors[i], obj_label=value_label)
    print(df)
    table_dfs.append(df)

# Plot combined tornados
OneWaySensitivity.combine_tornadoes(table_dfs, labels=scenarios, 
    colors=colors, obj_label=value_label)
    