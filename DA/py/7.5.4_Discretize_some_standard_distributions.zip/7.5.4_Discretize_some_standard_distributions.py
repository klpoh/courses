# -*- coding: utf-8 -*-
# 7.5.4_Discretize_some_standard_distributions.py
import numpy as np
from scipy.stats import norm
from scipy.stats import uniform
from scipy.stats import triang
from scipy.optimize import root

""" Discretize some known standard distributuions by moments matching"""
def main():
# Uncoment functions you want to run
    discretize_standard_normal()
    discretize_standard_uniform()
    discretize_sym_standard_triangular()

def discretize_standard_normal():
    dist_name = "Standard Normal"
    g2b = (-1, 1,               0.5, 0.5)
    g3b = (-1, 0, 1,            0.2, 0.6, 0.2)
    g4b = (-2, -0.5, 0.5, 2,    0.1, 0.4, 0.4, 0.1)
    g5b = (-3, -1.5, 0, 1.5, 3, 0.05, 0.2, 0.5, 0.2, 0.05)
    guesses = [(), (), g2b, g3b, g4b, g5b]
    # Generate the first 9 non-central moments of the standard normal distribution
    moments = np.array([norm.moment(n, loc=0, scale=1) for n in range(0, 10)])
    for nbr in range(2, 6):
        print(f"\n{dist_name}, {nbr} branches:")
        solution = root(mom_matching, guesses[nbr], args=(nbr,moments[:2*nbr]))
        if not solution.success: print("Warning:", solution.message) 
        display_results(solution.x)

def discretize_standard_uniform():
    dist_name = "Standard Uniform"
    g2b = (0.2, 0.8,              0.5,  0.5)
    g3b = (0.1, 0.5, 0.9,         0.25, 0.5, 0.25)
    g4b = (0.1, 0.3, 0.7, 0.9,    0.2,  0.3, 0.3, 0.2)
    g5b = (0.05, 0.25, 0.5, 0.75, 0.95, 0.1, 0.25, 0.3, 0.25, 0.1)
    guesses = [(),(), g2b, g3b, g4b, g5b]
    # Generate the first 9 non-central moments of the standard uniform distribution
    moments = np.array([uniform.moment(n, loc=0, scale=1) 
                        for n in range(0, 10)])
    for nbr in range(2, 6):
        print(f"\n{dist_name}, {nbr} branches:")
        solution = root(mom_matching, guesses[nbr], args=(nbr,moments[:2*nbr]))
        if not solution.success: print("Warning:", solution.message) 
        display_results(solution.x)
        

def discretize_sym_standard_triangular():
    dist_name = "Triangular (0, 0.5, 1)"
    g2b = (0.2, 0.8,                0.5, 0.5)
    g3b = (0.1, 0.5, 0.9,           0.2, 0.6, 0.2)
    g4b = (0.1, 0.3, 0.7, 0.9,      0.2, 0.3, 0.3, 0.2)
    g5b = (0.1, 0.3, 0.5, 0.7, 0.9, 0.1, 0.2, 0.4, 0.2, 0.1)
    guesses = [(),(), g2b, g3b, g4b, g5b]
    # Generate the first 9 non-central moments of the triangular distribution
    moments = np.array([triang.moment(n, 0.5, loc=0, scale=1) 
                        for n in range(0,10)])
    for nbr in range(2, 6):
        print(f"\n{dist_name}, {nbr} branches:")
        solution = root(mom_matching, guesses[nbr], args=(nbr,moments[:2*nbr]))
        if not solution.success: print("Warning:", solution.message) 
        display_results(solution.x)

def mom_matching(Z, nbr, mom):
    x = np.array(Z[:nbr])  # Z is actually [x1,x2,..xn,p1,p2,..pn]
    p = np.array(Z[nbr:])  # so, we disect it 
    # matching the first 2n-1 moments
    return [sum(p*x**j) - mom[j] for j in range(2*nbr)]

def display_results(results):
    nbr = len(results)//2
    for i in range(nbr):
        print(f"x{i+1} = {results[i]:9.6f}, p{i+1} = {results[i+nbr]:.6f}")


if __name__ == "__main__":
    main()
