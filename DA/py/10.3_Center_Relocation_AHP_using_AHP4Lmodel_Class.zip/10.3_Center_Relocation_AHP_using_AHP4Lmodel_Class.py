# -*- coding: utf-8 -*-
# 10.3_Center_Relocation_AHP_using_AHP4Lmodel_Class.py
from DecisionAnalysisPy import AHP4Lmodel
import numpy as np

""" Solve Drug Counseling Center Relocation Problem using AHP4Lmodel Class """

       
Goal = "Best Site for Relocation"
alternatives = ["Site 1", "Site 2", "Site 3", "Site 4", "Site 5", "Site 6"]

main_criteria = ["Good conditions for staff",
                 "Easy access for clients",
                 "Suitability of space for center's functions",
                 "Administrative convenience" ]

main_criteria_matrix = np.array([2, 2, 3, 
                                    1, 2, 
                                       1 ])

# Containers for data
sub_criteria = []
sub_criteria_matrices = []
alt_matrices = []

# Main Criterion 1: "Good Conditions for staff"
# List of subcriteria for Criterion 1
sub_criteria.append(["Office size",
                     "Convenience of staff commuting",
                     "Office attractiveness",
                     "Office privacy",
                     "Staff parking" ])

# Pairwise comparison of subcriteria for Criterion 1
sub_criteria_matrices.append(np.array([2, 3, 3, 3,
                                          2, 2, 2,
                                             1, 1,
                                                1 ]))

# Pairwise comparison of alternatives w.r.t. each sub-criterion
alt_matrices.append([np.array([2, 9, 2,  9,  2,
                                  5, 1,  5,  1,
                                    1/5, 1, 1/4,
                                         5,  1,
                                            1/4 ]),
                     np.array([2, 1/2, 5, 9,  2,
                                  1/3, 3, 6,  1,
                                       9, 9,  3,
                                          2,  1/3,
                                              1/6 ]),
                     np.array([1/3, 1/2, 3, 1/3, 1/3,
                                     1,  8,  1,   1,
                                         1,  1,   1,
                                             1/9, 1/8,
                                                   1 ]),
                     np.array([3, 2, 9,  3,   2,
                                  1, 3,  1,  1/2,
                                     4,  1,   1,
                                        1/3, 1/2,
                                              1 ]),
                        
                     np.array([1/6, 1/3, 1, 1/9, 1/5,
                                     2,  6,	1/2,  1,
                                         3,  1/3, 1/2,
                                             1/9, 1/5,
                                                   2  ]) ])

# Main Criterion 2: "Easy access for clients"
# List of subcriteria for Criterion 2
sub_criteria.append(["Closeness to client's homes",
                     "Access to public transportation" ])

# Pairwise comparison of subcriteria for Criterion 2
sub_criteria_matrices.append(np.array([ 1 ]))

# Pairwise comparison of alternatives w.r.t. each sub-criterion
alt_matrices.append([np.array([1, 3, 1/2, 1/3,  1,
                                  3, 1/2, 1/3,  1,
                                     1/5, 1/9, 1/3,
                                          1/2,  2,
                                                3 ]),
                     np.array([1, 1, 1, 7,  1,
                                  1, 1, 7,  1,
                                     2, 9,  1,
                                        5,  1,
                                           1/7 ]) ])

# Main Criterion 3: "Suitability of space for for center's functions"
# List of subcriteria for Criterion 3
sub_criteria.append(["Number and suitability of counseling rooms",
                     "Number and suitability of conference rooms",
                     "Suitability of reception and waiting area" ])

# Pairwise comparison of subcriteria for Criterion 3
sub_criteria_matrices.append(np.array([ 2, 2, 
                                           2 ]))

# Pairwise comparison of alternatives w.r.t. each sub-criterion
alt_matrices.append([np.array([1/8, 2, 1/5, 1/9, 1/5,
                                    9,  2,   1,   2,
                                       1/9, 1/9, 1/9,
                                            1/2,  1,
                                                  2 ]),
                    np.array([1, 6, 6, 1/2,  2,
                                 5,	5, 1/2,	 2,
                                    1, 1/9, 1/3,
                                       1/9,	1/3,
                                             3 ]),
                    np.array([1, 1, 5,  2,   2,
                                 1,	4, 1/2,  1,
                                    5, 1/2,	 2,
                                       1/9, 1/3,
                                             3  ])] )
  
# Main Criterion 4: "Administrative Convenience"
# List of subcriteria for Criterion 4
sub_criteria.append(["Adequacy of space for admin work",
                     "Flexibility of the space layout" ])

# Pairwise comparison of subcriteria for Criterion 4
sub_criteria_matrices.append(np.array([ 2 ]))

# Pairwise comparison of alternatives w.r.t. each sub-criterion
alt_matrices.append([np.array([1/7, 1/5, 1/9, 1/5, 1/6,
                                     1,   1,   1,   1,
                                         1/2,  1,   1,
                                               2,   2,
                                                    1 ]),
                     np.array([1/4, 1/5, 1/9,  1,	1/4,
                                      1,  2,   4,    1,
                                         1/2,  5,    1,
                                               9,    1,
                                                    1/4 ]) ])

## End of Model Definition and Data ##
# Create an instance of a 4-Level AHP model
DC_relocate = AHP4Lmodel(Goal, main_criteria, main_criteria_matrix, 
                        sub_criteria, sub_criteria_matrices, 
                        alternatives, alt_matrices)
# Take a look a the model structure and data
DC_relocate.model()

# Solve the model
DC_relocate.solve(method="Algebra")

# Do sensitivity analysis
DC_relocate.sensit(ymax=0.35, ystep=0.05)
