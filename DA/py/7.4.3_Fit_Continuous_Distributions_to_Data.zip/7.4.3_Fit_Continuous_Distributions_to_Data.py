# -*- coding: utf-8 -*-
""" 7.4.3_Fit_Continous_Distributions_to_Data.py """
""" Fit Continuous Distributions to Data """
import pandas as pd
import numpy as np
from scipy import stats
import matplotlib.pyplot as plt

# Read the data from Excel file
data = pd.read_excel ("7.4.3_data.xlsx", sheet_name="data1", header=None)
data = data.values.flatten()

# Visualize the data with a density histogram and display descrption
bins = 20
fig0, ax0 = plt.subplots(dpi=100)
ax0.hist(data, bins=bins, histtype='stepfilled', density=True, alpha=0.9)
ax0.set_xlabel("Data value")
ax0.set_ylabel("Density")
plt.show()

desc = stats.describe(data)
print("\nData Description:")
print(f"  size = {desc.nobs}")
print(f"  minmax = {desc.minmax}")
print(f"  mean = {desc.mean}")
print(f"  var = {desc.variance}")
print(f"  skewness = {desc.skewness}")
print(f"  kurtosis= {desc.kurtosis}")

# List of distributions to fit
Dists = ['beta','expon','gamma','lognorm','logistic', 'laplace',
         'norm', 'rayleigh','triang','uniform','weibull_min']

# Loop through the list of distributions to fit
res = {}
for d in Dists:
    # Fit distribution to data
    dist = getattr(stats, d)
    print(f"Fitting distribution {d}:")
    params_fit = dist.fit(data)
    print(f"  Parameters = {params_fit}")
    # Perform the Kolmogorov-Smirnov test on fitted result.
    Dv, pv = stats.kstest(data, d, args=params_fit)
    # Keep the results 
    res[d] = {'Params'  : params_fit,
              'KS_D': Dv,
              'KS_pv': pv }

# Sort the results by KS stats
results = {dist: vals for dist, vals in 
        sorted(res.items(), key=lambda x: x[1]['KS_D']) }

# Compare the PDF of the fitted distributions with the data
max_to_plot = 6
num_to_plot = min(max_to_plot, len(results))

fig1, ax1 = plt.subplots(dpi=100)
ax1.hist(data, bins=bins, histtype='stepfilled', label='data',
         density=True, alpha=0.4)
ax1.set_ylabel("Probability")
for d in list(results.keys())[:num_to_plot]:
    params = results[d]['Params']
    dist = getattr(stats, d)
    x = np.linspace(dist.ppf(0.001, *params), 
                    dist.ppf(0.999, *params), 500)
    pdf_fitted = dist.pdf(x, *params)
    ax1.plot(x, pdf_fitted, lw=2, label=d)
ax1.legend()
ax1.grid('dotted')
plt.show()

# Compare the CDF of the fitted distributions with the data ECDF
def ecdf(data):
    # Compute ECDF of the data
    x = np.sort(data)
    n = x.size
    y = np.arange(1,n+1)/n
    return(x,y)

fig2, ax2 = plt.subplots(dpi=100)
x, y = ecdf(data)
ax2.scatter(x, y, lw=2, label='data' )
ax2.set_ylabel("CDF")
for d in list(results.keys())[:num_to_plot]:
    params = results[d]['Params']
    dist = getattr(stats, d)
    x = np.linspace(dist.ppf(0.001, *params), 
                    dist.ppf(0.999, *params), 500)
    cdf_fitted = dist.cdf(x, *params)
    ax2.plot(x, cdf_fitted, lw=2, label=d)
ax2.legend()
ax2.grid('dotted')
plt.show()

# Show the top fitted parameters
num_to_show = 20
num_to_show = min(num_to_show, len(results))
print(f"\nThe top {num_to_show} distributions:")
  
for i, (d, vals) in enumerate(list(results.items())[:num_to_show]):
    dist = getattr(stats, d)
    params = vals['Params']
    print(f"\nDistribution {i+1}: {d}")
    print(f"  Parameters = {params}")
    print(f"  KS stats = {vals['KS_D']}")
    pv = vals['KS_pv']
    print(f"  p-value = {pv}", end=" ")
    if pv < 0.05:
        print(" < 0.05")
    else:
        print("")
    print(f"  mean = {dist(*params).mean()}")
    print(f"  var = {dist(*params).var()}")
    print(f"  sd = {dist(*params).std()}")
