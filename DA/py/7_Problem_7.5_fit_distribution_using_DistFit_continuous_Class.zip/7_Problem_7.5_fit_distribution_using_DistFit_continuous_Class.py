# -*- coding: utf-8 -*-
""" Solutions to Problem 7.5 using DistFit_continuous Class"""
from DecisionAnalysisPy import DistFit_continuous

data = [ 0.1, 2.6, 2.9, 0.5,
         1.2, 1.8, 4.8, 3.3,
         1.7, 0.2, 1.5, 2.0,
         4.2, 0.6, 1.0, 2.6,
         0.9, 3.4, 1.7, 0.4 ]

# Use DistFit_continuous to fit the data
p75 = DistFit_continuous(data)

# About the data
bins = 5
p75.data_hist(bins=bins)
p75.data_describe()

# Fit an exponential distribution with loc = 0.
p75.fit(['expon'], options={'floc': 0})

# Show the PDF and CDF of the fitted distribution
p75.plot_pdf(1, bins=bins, dpi=100)
p75.plot_cdf(1, dpi=100)

# See the fitted paramters
p75.parameters()
