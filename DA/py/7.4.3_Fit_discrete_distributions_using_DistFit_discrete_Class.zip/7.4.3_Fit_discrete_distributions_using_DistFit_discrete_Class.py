# -*- coding: utf-8 -*-
# 7.4.3_Fit_discrete_distributions_using_DistFit_discrete_Class.py
from DecisionAnalysisPy import DistFit_discrete
import pandas as pd

""" Fit Discrete Distributions to Data using DistFit_discrete Class """

# Read the data from Excel file
data = pd.read_excel ("7.4.3_data.xlsx", sheet_name="data2", header=None)
data = data.values.flatten()

# Use DisFit_describe Class to fit.
ex2 = DistFit_discrete(data)

# Visualize and describe the data
ex2.data_hist(dpi=100)
ex2.data_describe()

#  'poisson'   # Poisson (mu)
#  'binom'     # Binomial (n, p)
#  'nbinom'    # Negative Binomial (n, p)
#  'betabinom' # Beta-Binomial (n, a, b)
#  'randint'   # randint (a, b)
#  'geom'      # geom(p)

# Distributions to fit and their parameter initial guess
Dists = { 'poisson'  : (10, ),
          'binom'    : (20, 0.5),
          'nbinom'   : (20, 0.5),
          'betabinom': (20, 10, 10),
          'randint'  : (3, 17),
          'geom'     : (0.5,)}

ex2.fit( Dists, solver='Nelder-Mead') # default solver
# ex2.fit( Dists, solver='Powell')    # alternative solver

# Plot the results found
ex2.plot_pmf(5, dpi=100)
ex2.plot_cdf(5, dpi=100)

# See the fitted parameters
ex2.parameters(5)
