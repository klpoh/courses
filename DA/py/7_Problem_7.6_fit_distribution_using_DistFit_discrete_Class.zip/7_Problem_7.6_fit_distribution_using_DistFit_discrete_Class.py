# -*- coding: utf-8 -*-
# 7_Problem_7.6_fit_distribution_using_DistFit_discrete_Class.py
from DecisionAnalysisPy import DistFit_discrete

""" Solutions to Problem 7.6 using DistFit_discrete Class"""

data = [7, 12, 6, 9, 5, 2, 9,  9,
        7,  3, 9, 9, 5, 1, 7, 10,
        1,  8, 6, 3, 4, 5, 3, 13]

# Use DistFit_discrete class to fit the data
p76 = DistFit_discrete(data)

# About the data
p76.data_hist()
p76.data_describe()

#  'poisson'   # Poisson (mu)
#  'binom'     # Binomial (n, p)
#  'nbinom'    # Negative Binomial (n, p)
#  'betabinom' # Beta-Binomial (n, a, b)
# Distributions to fit and their parameter initial guess
Dists = { 'poisson'  : (6, ),
          'binom'    : (14, 0.5),
          'nbinom'   : (10, 0.5),
          'betabinom': (20, 5, 5) }

# Fit the four distributions
p76.fit(Dists)

# Show the PMF and CDF of the fitted distributions
p76.plot_pmf(2, dpi=100)
p76.plot_cdf(2, dpi=100)

# See the fitted paramters
p76.parameters(2)

