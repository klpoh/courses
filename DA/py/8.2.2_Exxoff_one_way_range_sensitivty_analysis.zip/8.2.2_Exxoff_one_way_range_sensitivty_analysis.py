# -*- coding: utf-8 -*-
# 8.2.2_Exxoff_one_way_range_sensitivity_analysis.py
from DecisionAnalysisPy import OneWayRangeSensit
import numpy_financial as npf
""" Exxoff Problem: One-Way Range Sensitivty Analysis (2025 01 26) """

# Uncertain variable names and their [low, base, high] values
v_data = { 'c' : [0.65, 0.88, 1.11],
           'p' : [0.62, 0.95, 1.28],
           'f' : [0.42, 0.48, 0.54],
           'L' : [ 14,   20,   26 ] }    

# Fixed parameters name and value
f_data = {'marr' : 0.1 }

# Objective functions, one for each alternative. 
# Arguments must be in the same order as above

def npv_1(c, p, f, L, marr):
    return -npf.pv(marr, 5, 0, -7-npf.pv(marr, L, 50*f*(1-p*c)))*1000
def npv_2(c, p, f, L, marr):
    return -npf.pv(marr, 5, 0, -7)*1000
def npv_3(c, p, f, L, marr):
    return 0

# The alternative names and their objective functions 
obj_fns = {"Invest in R&D and Market"       : npv_1,
           "Invest in R&D and Don't market" : npv_2,
           "Don't invest in R&D"            : npv_3 }

# Label for the objective function outputs
obj_label = 'NPV($K)'

# Perform one-way range sensitivity analysis
exoff = OneWayRangeSensit(v_data, f_data, obj_fns, obj_label)
# Show variable and objective base values
exoff.base_values()
# Show sensitivity range tables
exoff.sensit_table()
# Show individual tornado diagrams
exoff.tornados()
# Show combined tornados
exoff.combined_tornados(xlim=(-30000,60000), annotate=False)
# Show individual spider diagrams
exoff.spiders()


# Plot combined tornados for the 2 initial alterntives
def npv_invest(c, p, f, L, marr):
    return max(npv_1(c, p, f, L, marr), npv_2(c, p, f, L, marr)) 
    # return -npf.pv(0.1, 5, 0, -7+max(0,-npf.pv(0.1, L, 50*f*(1-p*c))))

init_objs = { "Invest in R&D"       : npv_invest,
              "Don't invest in R&D" : npv_3 }

# Perform one-way range sensitivity analysis
ex_init = OneWayRangeSensit(v_data, f_data, init_objs, obj_label)
# Show variable and objective base values
ex_init.base_values()
# Show sensitivity range tables
ex_init.sensit_table()
# Show individual tornado diagrams
ex_init.tornados()
# Show combined tornados
ex_init.combined_tornados(xlim=(-10000,60000), annotate=False)
# Show individual spider diagrams
ex_init.spiders()

