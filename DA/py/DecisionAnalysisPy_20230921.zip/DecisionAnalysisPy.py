# -*- coding: utf-8 -*-
""" DecisionAnalysisPy Module (Ver 2023 09 21)
    Classes and Functions used for the Decision Analysis courses 
    by Prof. K.L Poh """

import numpy as np
import matplotlib.pyplot as plt
import pandas as pd
from cycler import cycler
from scipy import stats
from scipy.optimize import root
from scipy.optimize import minimize
import fractions

#############################################################################
class RiskDeal:
    """ Class for risky deals with single-stage (flatten) probability 
    distribution:

    RiskDeal(x, p, states=None, name='unnamed')  
    Parameters:
      p = list or array of probabilities of deal
      x = list or array of payoff values of deal
      states = list of state names of deal
      name   = name of deal 
    
    Attributes:
      p = np.array of probabilities
      x = np.array of payoff values
      states = list of state names; default = [x0, x1, x2, ...]
      name = name of deal, default = 'unnamed'
      EV = expected value of deal
      
    Methods:
      cdf(z): 
          Compute CDF(z) of deal
      
      plot_CDF(plot_range, num=1000, dpi=100):
          Plot the CDF of the deal 
          Parameters:
            plot_range = tuple(xL, xH (included), step) 
                       = parameters for x-axis, e.g. (-10, 110, 5)  
            num = Number of points to plot the graph (default 1000)
            dpi = dpi to plot
            
      plot_EPF(plot_range, num=1000, dpi=100):
          Plot the EPF of the deal 
          Parameters:
            plot_range = tuple(xL, xH (included), step) 
                       = parameters for x-axis, e.g. (-10, 110, 5)  
            num = Number of points to plot the graph (default 1000)
            dpi = dpi to plot

       PISP(w0, uw, uw_inv=None, method='hybr', guess=None, 
                silent=False):
           Compute Personal Indifferent Selling Price of Deal
           Parameters:
              w0 = intial wealth
              uw = wealth utility function
              uw_inv = inverse wealth utility function; 
                        If not provided, an equation solver will be used.
              method = solver method used: 'hybr' (default) or 'lm'
              guess = starting point for solver
              silent = False (default): print message; True: no message
    
        CE(w0, uw, uw_inv=None, method='hybr', guess=None, 
                 silent=False):
            Compute Certainty Equivalent of deal = PISP

        PIBP(w0, uw, method='hybr', guess=None, silent=False):
            Compute personal indifferent buying price of Deal.
            Parameters:
                w0 = intial wealth
                wu = wealth utility function
                method = solver method used: 'hybr' (default), 'lm'
                guess = starting point for solver
                silent = False (default): print message; True: no message
            
    """
    
    def __init__(self, p=None, x=None, states=None, name='unnamed'):
        """ 
        Parameters: 
          p = list or array of probabilities of the deal
          x = list or array of payoff values of the deal
          states = list of state names of deal (optional)
          name   = name of deal (optional)
        """
        
        # self.nbr = len(x)
        self.p = np.array(p) # convert to array if not already so
        self.x = np.array(x) # convert to array if not already so
        self.name = name
        
        # Sort the values in increasing order
        order = np.argsort(self.x)
        self.x = self.x[order]
        self.p = self.p[order]

        if states is not None: 
            self.states = [states[i] for i in order]
        else: 
            self.states = ['x'+str(i) for i in order]

        self.EV = np.dot(self.p, self.x)


    def cdf(self, z):
         """ Retruns the CDF(z) = F(z <= X) """
         F = np.cumsum(self.p)
         for v, f in zip(self.x[::-1], F[::-1]):
             if z >= v:
                 return f
         return 0

    
    def plot_CDF(self, plot_range, num=1000, dpi=100):
        """ Plot the CDF of the deal 
        Parameters:
          plot_range = tuple(xL, xH (included), step) 
                     = parameters for x-axis, e.g. (-10, 110, 5)  
          num = Number of points to plot the graph (default 1000)
          dpi = dpi to plot
        """
        (xL, xH, step) = plot_range
        xv  = np.linspace(xL, xH, num)
        cdfs= np.array([ self.cdf(z) for z in xv ])
        fig1, ax1 = plt.subplots(dpi=dpi)
        ax1.plot(xv, cdfs, label=self.name, c='r', lw=2)
        ax1.legend(loc='lower right')
        ax1.set_ylim(0, 1)
        ax1.set_yticks(np.linspace(0, 1, 11))
        ax1.set_ylabel("Cumulative Probability")
        ax1.set_xlim(xL, xH)
        ax1.set_xticks(np.arange(xL, xH+step/2, step))
        ax1.set_title('Cumulative Distribution')
        ax1.grid()
        plt.show()
        
                    
    def plot_EPF(self, plot_range, num=1000, dpi=100):
        """ Plot the Excess Distribution of the Deal 
        Parameters:
          plot_range = tuple(xL, xH (included), step) 
                     = parameters for x-axis, e.g. (-10, 110, 5)
          num = Number of points to plot graph (default 1000)
          dpi = dpi to plot (default 100)
        """
        (xL, xH, step) = plot_range
        xv  = np.linspace(xL, xH, num)
        epfs= np.array([ 1- self.cdf(z) for z in xv ])
        fig2, ax2 = plt.subplots(dpi=dpi)
        ax2.plot(xv, epfs, label=self.name, c='b', lw=2)
        ax2.legend(loc='upper right')
        ax2.set_ylim(0, 1)
        ax2.set_yticks(np.linspace(0, 1, 11))
        ax2.set_ylabel("Excess Probability")
        ax2.set_xlim(xL, xH)
        ax2.set_xticks(np.arange(xL, xH+step/2, step))
        ax2.set_title('Excess Distribution')
        ax2.grid()
        plt.show()            
            
    
    def PISP(self, w0, uw, uw_inv=None, method='hybr', guess=None, 
             silent=False):
        """ 
        Compute Personal Indifferent Selling Price of Deal
        Parameters:
          w0 = intial wealth
          uw = wealth utility function
          uw_inv = inverse wealth utility function; 
                    If not provided, an equation solver will be used.
          method = solver method used: 'hybr' (default) or 'lm'
          guess = starting point for solver
          silent = False (default): print message; True: no message
        Returns:
          Personal Indifferent Selling Price of Deal
        """
        uw_vec = np.vectorize(uw)
        if uw_inv is not None:
            # Compute PISP using inverse wealth utility function
            if not silent: 
                print("  ..using inverse wealth utility function to find PISP")
            return uw_inv(np.dot(self.p, uw_vec(w0+self.x))) - w0
        else:
            if not silent: 
                print(f"  ..using solver {method} to find PISP")
            eq = lambda s: uw_vec(w0+s)-np.dot(self.p, uw_vec(w0+self.x))
            if guess is None:
                guess = self.EV/2
            if method=='hybr':
                sol = root(eq, x0=guess, method ='hybr',
                       options={'xtol':1e-12,'maxfev':10000})
            else:
                sol = root(eq, x0=guess, method='lm',
                       options={'xtol':1e-12, 'maxiter':10000})
            if not (sol.success or silent):
                print("  ..message:", sol.message)
            return sol.x[0]    

    def CE(self, w0, uw, uw_inv=None, method='hybr', guess=None,
               silent=False):
        """ Compute Certainty Equivalent of deal = PISP """
        return self.PISP(w0, uw, uw_inv, method, guess, silent)


    def PIBP(self, w0, uw, method='hybr', guess=None, silent=False):
        """ 
        Compute personal indifferent buying price of Deal.
        Parameters:
          w0 = intial wealth
          wu = wealth utility function
          method = solver method used: 'hybr' (default), 'lm'
          guess = starting point for solver
          silent = False (default): print message; True: no message
        Returns:
          Personal Indifferent Buying Price of deal
        """
        uw_vec = np.vectorize(uw)
        eq = lambda b: uw_vec(w0)-np.dot(self.p, uw_vec(w0 - b + self.x))
        if guess is None:
            guess = self.EV/2
        if not silent: print(f"  ..using solver {method} to find PIBP")
        if method=='hybr':
            sol = root(eq, x0=guess, method ='hybr',
                       options={'xtol':1e-12,'maxfev':10000})
        else:
            sol = root(eq, x0=guess, method='lm',
                       options={'xtol':1e-12, 'maxiter':10000})
        if not (sol.success or silent):
            print("  ..message:", sol.message)
            print("  ..number of function evaluations:", sol.nfev)
        return sol.x[0]


#############################################################################
def plot_risk_profiles(Deals, plot_range, num=1000, 
                           CDF=True, EPF=True, dpi=100):
    """ Function to plot and compare risk profiles of a list of 
            RiskDeal instances.
    Parameters: 
      Deals = list of RiskDeal objects
      plot_range = (xL, xH (included), step) 
                 = parameters for ploting x-axis, e.g (-10, 110, 5)
      num: Number of points used for plotting
    """
    (xL, xH, step) = plot_range
    xv = np.linspace(xL, xH, num)
    cdfs=[np.array([D.cdf(z) for z in xv]) for D in Deals]
     
    if CDF:
        fig1, ax1 = plt.subplots(dpi=dpi)
        # linestyle_cycler = cycler('linestyle',['-','--',':','-.'])
        cc = (cycler(color=list('rbgc')) +
              cycler(linestyle=['-', '--', ':', '-.']))
        ax1.set_prop_cycle(cc)
        for p, D in zip(cdfs, Deals):
            ax1.plot(xv, p, label=D.name, lw=2)
        ax1.legend(loc='lower right')
        ax1.set_xlim(xL, xH)
        ax1.set_ylabel("Cumulative Probability")
        ax1.set_ylim(0, 1)
        ax1.set_yticks(np.linspace(0, 1, 11))
        ax1.set_xlim(xL, xH)
        ax1.set_xticks(np.arange(xL, xH+step/2, step))
        ax1.set_title('Cumulative Distribution')
        ax1.grid()
        plt.show()
    
    if EPF:
        fig2, ax2 = plt.subplots(dpi=dpi)
        # linestyle_cycler = cycler('linestyle',['-','--',':','-.'])
        cc = (cycler(color=list('rbgc')) +
              cycler(linestyle=['-', '--', ':', '-.']))
        ax2.set_prop_cycle(cc)
    
        for p, D in zip(cdfs, Deals):
            ax2.plot(xv, 1-p, label=D.name, lw=2)
        ax2.legend(loc='upper right')
        ax2.set_ylabel("Excess Probability")
        ax2.set_ylim(0, 1)
        ax2.set_yticks(np.linspace(0, 1, 11))
        ax2.set_xlim(xL, xH)
        ax2.set_xticks(np.arange(xL, xH+step/2, step))
        ax2.set_title('Excess Distribution')
        ax2.grid()
        plt.show()

    
#############################################################################
def is1SD(A, B, compare_range, num=1000):
    """ Determine if Deal A 1st order stochastic dominates Deal B
    Parameters: 
      A, B = RiskDeal instances to be compared
      compare_range= tuple(xL, xH) = range of values to compare
      num = number of points for numerical comparison of EPFs
    Returns:
      True if A 1SD B; False otherwise.
    """
    (xL, xH) = compare_range
    xv = np.linspace(xL, xH, num)
    A_minus_B = [B.cdf(z)-A.cdf(z) for z in xv ]
    # Finally, check if A 1SD B
    return all(np.array(A_minus_B) >= 0)

#############################################################################
def is2SD(A, B, plot_range, num=1000, show_plot=True, dpi=100):
    """ Function to plot the cumulative difference in area 
        under EPF of deals A and B, and then determine if 
        A second-order stochastic dominates B.
    Parameters:
      A, B  = RiskDeal instances to be compared
      plot_range = (xL, xH, step) = parameters for x-axis 
      num = number of points between xL and xH to sample. 
               default = 1000
      show_plot = False if no plotting needed
      dpi = dpi to plot
    Returns:
      True if A 2SD B; False otherwise.
    """
     
    (xL, xH, step) = plot_range
    # if xL == None: xL = min(A.x.min(), B.x.min())
    # if xH == None: xH = max(A.x.max(), B.x.max())
    
    xv = np.linspace(xL, xH, num)
    # Compute a list of differences in cumulative area under CDF 
    AF = np.cumsum(A.p)
    BF = np.cumsum(B.p)
    # A_minus_B = [AuCDF(B.x,B.p,t)-AuCDF(A.x,A.p,t) for t in xv]
    A_minus_B = [AuCDF(B.x,BF,t)-AuCDF(A.x,AF,t) for t in xv]
    
    if show_plot:
        plot_risk_profiles([A, B], plot_range, num=num, dpi=dpi)
        fig, ax = plt.subplots(dpi=dpi)
        ax.plot(xv, A_minus_B, 'g-', lw=2)
        ax.set_title("Delta cumulative area under Excess Distributions")
        ax.set_ylabel(f"Delta({A.name} - {B.name})")
        ax.set_xlim(xL, xH)
        ax.set_xticks(np.arange(xL, xH+step/2, step))
        ax.grid()
        plt.show()
    # Finally, check if A 2SD B
    return all(np.array(A_minus_B) >= 0)

def AuCDF(X, F, t):
    """ Function to compute area under CDF up to x-value t.
        Used in is2SD function 
    Parameters:
        X = np.array of X values
        P = np.array of probabilities 
        t = target x value to compute area up to 
    Returns:
        Area under CDF up to target value
    """
    if t <= X[0]:
        return 0
    A = 0
    x0, f0 = X[0], F[0]
    for x, f in zip(X[1:], F[1:]):
        # We are done in this segment. 
        if t <= x:
            return A + (t-x0)*f0
        # Add rectangular area of this segment and go to next segment
        A += (x-x0)*f0
        x0, f0 = x, f
    # you are here because t > X[-1]
    return A + (t-x0)*f0 

#############################################################################
class ExpUtilityFunction:
    """Class for Exponential Utility Function u(x)= a - b exp(-x/RT)
    ExpUtilityFunction(RT=None, L=None, H=None):
    Parameters:
      RT = risk tolerance. If omitted, can be determined later
      L = lower bound such that u(L) = 0 (optional)
      H = Upper bound such that u(H) = 1 (optional)
    
    Attributes:
      RT = risk tolerance
      L = lower bound such that u(L) = 0
      H = upper bound such that u(H) = 1
      a = constant that fits the boundary conditions u(L)=0, u(H)=1
      b = constant that fits the boundary conditions u(L)=0, u(H)=1
               b > 0 if RT > 0,  b < 0 if RT < 0
      risk_attitude = "risk averse" or "risk seeking"
      
    Methods:
      set_RT(RT):  Set risk tolerance to RT without changing L and H
      set_bounds(L, H):  Set L and H without changing RT
      u(x): Compute and return u(x)
      find_RT_5050CE(L, H, X05, guess): Find RT using 50-50 CE method
      plot(xmin, xmax): Plot the utility function from xmin(L) to xmax(H)
      fun_str(): Return a string representation of the utility function
    """
    def __init__(self, RT=None, L=None, H=None):
        """
        Parameters:
          RT = risk tolerance. If omitted, can be determined later
          L = lower bound such that u(L) = 0 (optional)
          H = Upper bound such that u(H) = 1 (optional)
        """       
        self.RT = RT
        self.L = L
        self.H = H
        self.a = None
        self.b = None
        self.risk_attitude = None
        if RT is not None:
            self.risk_attitude = "risk averse" if RT>0 else "risk seeking"
            if L is not None and H is not None:
                # Fit a and b to boundary conditions u(L)=0,u(H)=1
                self.a = 1./(1-np.exp(-(H-L)/RT))
                self.b = self.a*np.exp(L/RT)
     
    def set_RT(self, RT):
        """ Set the Risk Tolerance without changing L and H 
        Parameter:
          RT = risk tolerance
        """
        self.RT = RT
        self.risk_attitude = "risk averse" if RT>0 else "risk seeking"
        if self.L is not None and self.H is not None:
            # Refit a and b to boundary conditions u(L)=0,u(H)=1
            self.a = 1./(1-np.exp(-(self.H-self.L)/RT))
            self.b = self.a*np.exp(self.L/RT)
        
    def set_bounds(self, L, H):
        """Set boundaries L and H without changing RT
        Parameters:
          L = lower bound such that u(L)=0
          H = Upper bound such that u(H)=0
        """
        self.L, self.H = L, H
        self.a = None  # needs to be updated if L and H are changed
        self.b = None  # needs to be updated if L and H are changed
        if self.RT is not None:
            self.a = 1./(1-np.exp(-(H-L)/self.RT))
            self.b = self.a*np.exp(L/self.RT)

    def u(self, x):
        """ Compute utility value u(x)
        Parameter:
          x = value whose utility is to be evaluated.
        Returns:
          u(x) utility value of x
        """
        if any(v is None for v in [self.a, self.b, self.RT]):
            return "Incomplete parameters"
        return self.a - self.b*np.exp(-x/self.RT)
    
    def find_RT_5050CE(self, L, H, X05, guess):
        """ Find the risk tolerance using 50-50 CE method
        Parameters:
          L = lower bound
          H = upper bound
          X05 = CE for (L:50, H:50) Deal
          guess: +ve for risk averse, -ve for risk seeking
        Returns: 
          risk tolerance
        """
        self.L = L
        self.H = H
        risk_averse = X05 < (H+L)/2
        self.risk_attitude = "Risk averse" if risk_averse else "Risk seeking"
        # Guess should be +ve for risk averse, -ve for risk seeking
        if not risk_averse and guess > 0: 
            guess = -guess
            print(">> warning: guess should be -ve for risk seeking case")
        # The function whose root we wish to find 
        func=lambda r: (1.0-np.exp(-(X05-L)/r))/(1.0-np.exp(-(H-L)/r))-0.5
        # Find the risk tolerance using solver
        sol = root(func, guess)
        if not sol.success:
            print("Solution not successful, try changing guess")
            return None
        self.RT = sol.x[0]
        self.a = 1./(1-np.exp(-(H-L)/self.RT))
        self.b = self.a*np.exp(L/self.RT)
        return self.RT

    def plot(self, xmin=None, xmax=None):
        """Plot the exponential utility function in the range xmin to xmax.
        Parameters:
          xmin (optional) = lower limit for plot. Default = L
          xmax (optional) = upper limit for plt.  Default = H
        """   
        rt,L,H,a,b = self.RT, self.L, self.H, self.a, self.b
        if any(v is None for v in [rt, L, H, a, b]):
            return "Incomplete Parameters to plot"
        if rt == 0:
            return "The utility function is u(x)=x"
        if xmin is None: xmin=L
        if xmax is None: xmax=H
        # Pretty format the utility function as string
        if rt > 0: ufstring= f"u(x) = {a:.4f} - {b:.4f} exp(-x/{rt:.4f})"
        else:      ufstring= f"u(x) = {a:.4f} + {-b:.4f} exp(x/{-rt:.4f})"
        # Plot the utility function 
        x = np.linspace(xmin, xmax, 101)
        u_func = lambda x : a - b*np.exp(-x/rt)
        fig, ax = plt.subplots(figsize=(6.4, 4.8))
        ax.plot(x, u_func(x), 'r', lw=2)
        ax.set_xlabel("x")
        ax.set_ylabel("u(x)")
        ax.set_title(ufstring, fontsize=14, pad=10)
        ax.grid()
        plt.show()

    def fun_str(self):
        """ String representing the utility function
        Parameter:
           Nil
        Returns:
           A string representing the utility function
        """
        rt, a, b = self.RT, self.a, self.b
        if any(v is None for v in [rt, a, b]):
            return "Incomplete parameters"
        if rt > 0: ufstring= f"u(x) = {a:.4f} - {b:.4f} exp(-x/{rt:.4f})"
        else:      ufstring= f"u(x) = {a:.4f} + {-b:.4f} exp(x/{-rt:.4f})"
        return ufstring

    def params(self):
        """ All the parameters of the utility function
        Parameter:
           Nil
        Return:
           A dictionary { "L" : L, "H" : H, "RT": RT,
                           "a": a, "b" : b, "risk_attitude": risk_attitude}
        """
        return {"L": self.L,"H": self.H,"RT": self.RT,"a": self.a,"b": self.b,
                "risk_attitude": self.risk_attitude }

#############################################################################
# Updated 2023 08 15
class DistFit_continuous:
    """ Class for fitting Continuous Distrbutions to Data using 
        scipy.stats.rv_continuous.fit
        
    DistFit(data):
      Parameter: 
          data = 1-D Array of data to fit.
      Attributes:
          data = Data used for fitting
          results = DataFrame of fitted results
          Distributions = List of distributions to fit
      
      Methods:
          data_hist(bins=None, dpi=100):
              Plot a density histogram of the data
            Parameters:
              bins = number of bin to plot (default = None)
              dpi = dpi to plot (default=100)
      
          data_describe(): 
              Describe the data descriptive statistics
      
          fit(Dists, method, options): 
              Fit the named distributions in the list
            Parameters:
              Dists = list of distributions to fit
              method = 'MLE' (default) or 'MM'
              options = dict of other options to pass to
                             scipy.stats.rv_continuous.fit
              
          plot_pdf(N=3, bins=None, dpi=100): 
              Plot the PDFs of the fitted distributions over the data
            Parameters:
              N = number of top distributions to plot (default=3)
              bins = number of bins to plot data
              dpi = dpi to plot (default = 100)
    
          plot_cdf(N=3, dpi=100)
              Plot the CDFs of the fitted distributions over the data ECDF
            Parameters:
              N = number of top distributions to plot (default=3)
              dpi = dpi to plot (default=100)
      
          parameters(N=3): 
              Show parameters of top fitted results
            Parameters:
              N = number of top distributions to show (default=3)
            Return: 
              Nested dictionary of fitted results.
    """
    
    def __init__(self, data):
        """ 
        Parameter: 
            data =  1-D Array of data to fit.
        """
        self.data = np.array(data)
        self.results = None
        self.Distributions = None
        return None
   
    def data_hist(self, bins=None, dpi=100):
        """ Plot a density histogram of the data  
        Parameter:  
            bins = number of bins to plot 
        """
        fig0, ax0 = plt.subplots(dpi=dpi)
        ax0.hist(self.data, bins=bins, histtype='stepfilled', 
                     density=True, alpha=0.8)
        ax0.set_xlabel("Data value")
        ax0.set_ylabel("Density")
        plt.show()
        return None

    def data_describe(self):
        """ Describe the data 
        Parameter:  None
        """
        desc = stats.describe(self.data, ddof=0)
        print("\nData Description:")
        print(f"  size = {desc.nobs}")
        print(f"  minmax = {desc.minmax}")
        print(f"  mean = {desc.mean}")
        print(f"  var = {desc.variance}")
        print(f"  skewness = {desc.skewness}")
        print(f"  kurtosis= {desc.kurtosis}")
        return None

    def fit(self, Distributions, method='MLE', options={}):
        """ Fit the data to list of distributions 
        Parameters:  
            Distributions = list of distributions to fit 
            method = 'MLE' (default) or 'MM' 
            options = dict of other options to pass to
                scipy.stats.rv_continuous.fit 
        Return:     
            Nested dictionary of all fitted results
        """
        self.Distributions = Distributions
        # Dict to keep results while looping
        res = {}
        # Loop through the list of distributions to fit
        for d in self.Distributions:
            dist = getattr(stats, d)
            params_fit = dist.fit(self.data, method=method, **options)
            # Perform 2-sided Kolmogorov-Smirnov test on fitted parametrs.
            Dv, pv = stats.kstest(self.data, d, args=params_fit)
            # Keep the results 
            res[d] = {'Params' : params_fit,
                      'KS_D' : Dv,
                      'KS_pv': pv }

        # Sort the results by KS stats
        results = {dist: vals for dist, vals in 
                sorted(res.items(), key=lambda x: x[1]['KS_D']) }
        
        print(f"\nNumber of distributions fitted = {len(results)}")

        for i, (d, vals) in enumerate(list(results.items())):
            dist = getattr(stats, d)
            params = vals['Params']
            print(f"\nDistribution {i+1}: {d}")
            print(f"  Parameters = {params}")
            print(f"  KS stats = {vals['KS_D']}")
            pv = vals['KS_pv']
            print(f"  p-value = {pv}", end=" ")
            if pv < 0.05:
                print(" < 0.05")
            else:
                print("")
            print(f"  mean = {dist(*params).mean()}")
            print(f"  var = {dist(*params).var()}")
            print(f"  sd = {dist(*params).std()}")
        
        self.results = results
        return results

    def plot_pdf(self, num_to_plot=3, bins=None, dpi=100):
        """ Plot the pdf of the fitted distributions and data 
        Parameters:  
            num_to_plot = number of distributions to plot (default = 3)
            bins = number of bins for data plot
            dpi = dpi to plot (default=100)
        """
        if self.results is None:
            print("Data not fitted yet")
            return None
    
        num_to_plot = min(num_to_plot, len(self.Distributions))
        fig1, ax1 = plt.subplots(dpi=dpi)
        ax1.hist(self.data, bins=bins, histtype='stepfilled', 
                 density=True, alpha=0.2)
        ax1.set_ylabel("Probability")
        for d in list(self.results.keys())[:num_to_plot]:
            params = self.results[d]['Params']
            dist = getattr(stats, d)
            x = np.linspace(dist.ppf(0.001, *params), 
                            dist.ppf(0.999, *params), 500)
            pdf_fitted = dist.pdf(x, *params)
            ax1.plot(x, pdf_fitted, lw=2, label=d)
        ax1.legend()
        ax1.grid(ls='--')
        plt.show()
        return None
    
    def _ecdf(self, data):
        # Private function to compute ECDF of the data
        x = np.sort(data)
        n = x.size
        y = np.arange(1,n+1)/n
        return(x,y)
    
    def plot_cdf(self, num_to_plot=3, dpi=100):
        """ Plot the CDF of the fitted distributions and ECDF of data 
        Parameters:  
            num_to_plot = number of distributions to plot (default=3)
            dpi = dpi to plot (default=100)
        """
        if self.results is None:
            print("Data not fitted yet")
            return None
        
        num_to_plot = min(num_to_plot, len(self.results))
        fig2, ax2 = plt.subplots(dpi=dpi)
        x, y = self._ecdf(self.data)
        ax2.scatter(x, y, lw=2, label='data' )
        ax2.set_ylabel("CDF")
        for d in list(self.results.keys())[:num_to_plot]:
            params = self.results[d]['Params']
            dist = getattr(stats, d)
            x = np.linspace(dist.ppf(0.001, *params), 
                            dist.ppf(0.999, *params), 500)
            cdf_fitted = dist.cdf(x, *params)
            ax2.plot(x, cdf_fitted, lw=2, label=d)
        ax2.legend()
        ax2.grid(ls='--')
        plt.show()
        return None
    
    def parameters(self, num_to_show=3):
        """ Show the fitted parameters 
        Parameter: 
            num_to_show = number of distributions to show (default=3)
        """
        if self.results is None:
            print("Data not fitted yet")
            return None
    
        num_to_show = min(num_to_show, len(self.Distributions))
        print(f"\nThe top {num_to_show} distributions are:")
        # for d in self.results.index[:num_to_show]:
            
        for i, (d, vals) in enumerate(list(self.results.items())[:num_to_show]):
            dist = getattr(stats, d)
            params = vals['Params']
            print(f"\nDistribution {i+1}: {d}")
            print(f"  Parameters = {params}")
            print(f"  KS stats = {vals['KS_D']}")
            pv = vals['KS_pv']
            print(f"  p-value = {pv}", end=" ")
            if pv < 0.05:
                print(" < 0.05")
            else:
                print("")
            print(f"  mean = {dist(*params).mean()}")
            print(f"  var = {dist(*params).var()}")
            print(f"  sd = {dist(*params).std()}")
            
        return self.results

#############################################################################
# Updated 2023 08 15
class DistFit_discrete:
    """ Class for fitting Discrete Distributions to Data using MLE method 

    DistFit_discrete(data):
      Parameter: data = 1-D Array of data to fit.
    
    Attributes:
      data = Data used for fitting
      results = DataFrame of fitted results
      Distributions = Dictionary of distributions to fit
      
    Methods:
      data_hist(dpi=100):  
          Plot relative frequencies of data
        Parameters:
          dpi = dpi to plot (default=100)
      
      data_describe(): 
          Describe the data descriptive statistics
      
      fit(Dists, solver='Nelder-Mead'): 
        Parameters:
          Dists =  Dictionary of distributions and initial guess
                      { name : tuple of parameters' initial values }
          solver = Solver for optimizing MLE
              Can be one of ('Nelder-Mead' (default) or 'Powell')
        Return:
           Nested dictionary of all fitted results
            
      plot_pmf(N=3, dpi=100): 
          Plot the PMF of the fitted distributions and data
        Parameters:
            N = Number of top distributions to plot (default=3)
            dpi = dpi to plot (default=100)
          
      plot_cdf(N=3, dpi=100): 
          Plot the CDF of fitted distributions and data ECDF
        Paramters:
          N = Number of top distributions to plot (default=3)
          dpi = dpi to plot (default=100)
          
      parameters(N=3): 
          Show parameters of top fitted results
        Parameters:
          N = number of top distributions to show (default=3)
        Return:
          Nested dictioonay of fitted results
        
    """
    
    def __init__(self, data):
        """ 
        Parameter: 
           data =  1-D Array of data to fit.
        """
        self.data = np.array(data)
        self.results = None
        self.Distributions = None
        return None
        
    def data_hist(self, dpi=100):
        """  Plot relative frequencies of the data
        Parameter:  dpi to plot (default=100)
        """
        fig0, ax0 = plt.subplots(dpi=dpi)
        values, counts = np.unique(self.data, return_counts=True)
        ax0.bar(values, counts/counts.sum())
        ax0.set_xticks(np.arange(values.min()-1, values.max()+2))
        ax0.set_xlabel("Data value")
        ax0.set_ylabel("Frequency density")
        plt.show()
        return None

    def data_describe(self):
        """ Describe the data 
        Parameter:  None
        """
        desc = stats.describe(self.data, ddof=0)
        print("\nData Description:")
        print(f"  size = {desc.nobs}")
        print(f"  minmax = {desc.minmax}")
        print(f"  mean = {desc.mean}")
        print(f"  var = {desc.variance}")
        print(f"  skewness = {desc.skewness}")
        print(f"  kurtosis= {desc.kurtosis}")
        return None

    
    def _nLogLikelihood(self, params, dist):
        """ Compute negative Log Likelihood function
          Parameters:
            params = parameters of distribution
            dist = a scipy.stats distribution class or object
        """
        return -dist.logpmf(self.data, *params).sum() 


    def fit(self, Dists, solver='Nelder-Mead'):
        """ Fit the data to distributions
        Parameters:  
            Dists =  Dictionary 
                        { name : tuple of parameters' initial values }
            solver = 'Nelder-Mead' (default) or 'Powell'
            
        Return:     
            Nested dictionary of all fitted results 
        """
        self.Distributions = Dists
        # Loop through each distribution to fit 
        # Dictionaries to keep successful results
        res = {}
        
        for d, x0 in self.Distributions.items():
            dist = getattr(stats, d)
            # Perform MLE Optimization
            if solver=='Nelder-Mead':
                options={'maxiter':10000,'xatol':1E-8,'fatol':1E-8}
            elif solver=='Powell':
                options={'maxiter':10000,'xatol':1E-8,'fatol':1E-8}
            else:
                print("Wrong solver specified")
                return None
            print(f"\nFitting distribution {d}:")
            sol = minimize(self._nLogLikelihood, x0=x0, args=(dist,),
                           method=solver,options=options)
            print(f"  MLE {sol.message}")
            params_fit = sol.x
            print(f"  Fitted Parameters = {params_fit}")
            # Keep the results if successful
            if sol.success:
                 # Perform Kolmogorov-Smirnov test and store result
                 Dv, pv = stats.kstest(self.data, d, args=params_fit)
                 res[d] = {'Params' : params_fit,
                           'KS_D' : Dv,
                           'KS_pv': pv }       
                
        print(f"\nNumber of distributions fitted = {len(res)}")

        # Sort the results by KS_stats
        results = {dist: vals for dist, vals in 
                sorted(res.items(), key=lambda x: x[1]['KS_D']) } 

        self.results = results
        return results
        

    def plot_pmf(self, num_to_plot=3, dpi=100):
    
        """ Plot the PMF of the fitted distributions and data 
        Parameters:  
          num_to_plot = number of distributions to plot (default = 3)
          dpi = dpi to plot (Default = 100)
        """
        if self.results is None:
            print("Data not fitted yet")
            return None
        
        # Visualize the fitted distributions and compare them with the data
        num_to_plot = min(num_to_plot, len(self.results))
        dist2plot = list(self.results.keys())[:num_to_plot]

        fig1, ax1 = plt.subplots(dpi=dpi)
        values, counts = np.unique(self.data, return_counts=True)
        ax1.bar(values, counts/counts.sum(), label='data', alpha=0.3)
        ax1.set_ylabel("Probability")
        x = np.arange(values.min()-1, values.max()+2)
        for d in dist2plot:
            params_fit = self.results[d]['Params']
            dist = getattr(stats, d)
            ax1.scatter(x, dist.pmf(x, *params_fit), label=d)
        ax1.set_xticks(x)
        ax1.legend()
        ax1.grid(ls='--')
        plt.show()
        return None
    
    def _step_func(self, x, y):
        """ Compute coordinates to line plot x and y as step function """
        xval = []
        for item in x:
            xval.append(item)
            xval.append(item)
        yval = [0]
        for item in y[:-1]:
            yval.append(item)
            yval.append(item)
        yval.append(1)
        return (xval, yval)
      
    def plot_cdf(self, num_to_plot=3, dpi=100):
    
        """ Plot the CDF of the fitted distributions and data 
        Parameters:  
           num_to_plot = number of distributions to plot (default = 3)
           dpi = dpi to plot (Default = 100)
        """
        if self.results is None:
            print("Data not fitted yet")
            return None
        
        # Visualize the fitted distributions and compare them with the data
        num_to_plot = min(num_to_plot, len(self.results))
        values, counts = np.unique(self.data, return_counts=True)

        fig2, ax2 = plt.subplots(dpi=dpi)
        cdf_data = np.cumsum(counts/counts.sum())
        ax2.plot(*self._step_func(values, cdf_data), label='data' )
        ax2.scatter(values, cdf_data, label=None)
        x = np.arange(values.min()-1, values.max()+2)
        for d in list(self.results.keys())[:num_to_plot]:
            params_fit = self.results[d]['Params']
            dist = getattr(stats, d)
            ax2.scatter(x, dist.cdf(x, *params_fit), label=d)
        ax2.set_xticks(x)
        ax2.set_yticks(np.linspace(0,1,11))
        ax2.set_ylabel('CDF')
        ax2.legend()
        ax2.grid(ls='--')
        plt.show()
        return None

     
    def parameters(self, num_to_show=3):
        """ Show the fitted parameters 
        Parameter: 
            num_to_show = number of distributions to show (default=3)
        Return:
            Nested dictionary of results
        
        """
        if self.results is None:
            print("Data not fitted yet")
            return None
        
        num_to_show = min(num_to_show, len(self.results))
        print(f"\nThe top {num_to_show} distributions:")
          
        for i, (d, vals) in enumerate(list(self.results.items())[:num_to_show]):
            dist = getattr(stats, d)
            params = vals['Params']
            print(f"\nDistribution {i+1}: {d}")
            print(f"  Params = {vals['Params']}")
            print(f"  KS_stats = {vals['KS_D']}")
            pv = vals['KS_pv']
            print(f"  p-value = {pv}", end=" ")
            if pv < 0.05:
                print(" < 0.05")
            else:
                print("")
            print(f"  mean = {dist(*params).mean()}")
            print(f"  var = {dist(*params).var()}")
            print(f"  sd = {dist(*params).std()}")
            
        return self.results
        
    
#############################################################################
class norm_2p:
    """ Class for Normal Distribution with 2 known
        percentile values
    norm_2p(x1, q1, x2, q2):
    Parameters:
      x1, q1 = First value and its percentile 
      x2, q2 = Second value and its percentile
       
    Attributes:
      x1, q1 = First value and its percentile 
      x2, q2 = Second value and its percentile
      mu = mean of fitted distribution
      sigma = standard deviation of fitted distribution
      
    Methods:
      display_cdf(): Display the CDF of the distribution.
      discretize(nbr=3): Discretize the distribution
            with nbr number of branches.
    """
    def __init__(self, x1, q1, x2, q2):
        """
        Parameters:
          x1, q1 = First value and its percentile 
          x2, q2 = Second value and its percentile
        """
        self.x1 = x1
        self.q1 = q1
        self.x2 = x2
        self.q2 = q2
       
        if q1 == 0.5:
           self.mu = self.x1
           z2 = stats.norm.ppf(self.q2)
           self.sigma = (self.x2 - self.mu)/z2
        elif q2 == 0.5:
            self.mu = self.x2
            z1 = stats.norm.ppf(self.q1)
            self.sigma = (self.x1 - self.mu)/z1
        else:
           # middle of x1 and x2, (x1, x2) is about 2 sigmas apart
           guess = ((self.x1+self.x2)/2, abs((self.x1-self.x2)/2))
           sol = root(self._eq, guess, 
                      args=((self.x1, self.x2), (self.q1, self.q2)))
           if not sol.success: print("Warning", sol.message)
           self.mu, self.sigma = sol.x
        
    def _eq(self, param, x, q):
        """ CDF equation to solve."""
        return (stats.norm.cdf(x[0], *param) - q[0],
                stats.norm.cdf(x[1], *param) - q[1] )
 
    def display_cdf(self):
        """ Display the CDF of the distribution.
        Parameter: 
          None 
        """
        
        xmin = stats.norm.ppf(0.001, loc=self.mu, scale=self.sigma)
        xmax = stats.norm.ppf(0.990, loc=self.mu, scale=self.sigma)
        x = np.linspace(xmin, xmax, 100)
        y = stats.norm.cdf(x, self.mu, self.sigma)
        fig, ax = plt.subplots()
        ax.plot(x, y, lw=2)
        ax.plot([self.x1, self.x2],[self.q1,self.q2],'ro', ms=7)
        ax.set_yticks(np.linspace(0, 1, 11))
        ax.set_ylabel("Cumulative Probability")
        ax.set_xlabel("X")
        ax.grid()
        plt.show()

    def discretize(self, nbr=3):
        """ Discretize the distribution using moments matching
        Parameter:
          nbr = number of branches (default=3)
        Returns:
          List of x-values, List of probabilities
        """
        x, p = [], []
        if nbr==1:  # Trival case, but we include it here anyway
            x.append(self.mu)
            p.append(1)
        elif nbr==2:
            x.append(self.mu - self.sigma)
            x.append(self.mu + self.sigma)
            p.append(0.5)
            p.append(0.5)
        elif nbr==3:
            x.append(self.mu - 1.732051*self.sigma)
            x.append(self.mu)
            x.append(self.mu + 1.732051*self.sigma)
            p.append(1/6)
            p.append(2/3)
            p.append(1/6)
        elif nbr== 4:
            x.append(self.mu - 2.334414*self.sigma)
            x.append(self.mu - 0.741964*self.sigma)
            x.append(self.mu + 0.741964*self.sigma)
            x.append(self.mu + 2.334414*self.sigma)
            p.append(0.045876)
            p.append(0.454124)
            p.append(0.454124)
            p.append(0.045876)
        elif nbr==5:
            x.append(self.mu - 2.856970*self.sigma)
            x.append(self.mu - 1.355626*self.sigma)
            x.append(self.mu)
            x.append(self.mu + 1.355626*self.sigma)
            x.append(self.mu + 2.856970*self.sigma)
            p.append(0.011257)
            p.append(0.222076)
            p.append(0.533333)
            p.append(0.222076)
            p.append(0.011257)
        else:
            print("Number of branches should be within 1 and 5")
    
        return x, p

#############################################################################

class OneWayRangeSensit():
    """ Class for performing one-way range sensitivity analysis 
    OneWayRangeSensit(alternatives, range_data, title="Untitled", 
                 output_label="$NPV"):
    Parameters:
      alternatives : dictionary of alternatives and objective functions
      range_data : dictionary of variable names and low, base, high values
      title : optional string, default = "Untitled"
      output_label : optional string, default = "$NPV"

    Attributes:
      title = title
      Alternatives = Dictionary of alternatives and objective functions
      Var_data = Dictionary of variable names and low, base, high values
      output_label = label for the objective function outputs
      
    Methods:
      sensit(show_tables=True, show_tornados=True): 
             Perform one-way range sensitivity for each alternative, 
             Show sensitivty tables, and plot tornado diagrams
    combined_tornados():
          Plot a combined tornado diagram for all alternatives.
    """
    
    def __init__(self, alternatives, range_data, title="Untitled", 
                 output_label="$NPV"):
        """
        Parameters:
          alternatives : dictionary of alternatives and objective functions
          range_data : dictionary of variable names and low, base, high values
          title : optional string, default = "Untitled"
          output_label : optional string, default = "$NPV"
        """
        self.title = title
        self.Alternatives = alternatives
        self.Alt_names = list(alternatives.keys())
        self.Obj_functions = alternatives.values()
        self.Var_data = range_data
        self.Var_names = range_data.keys()
        self.output_label = output_label
        self.Lows = []
        self.Highs = []
        self.Bases = []
        self.sensit_done = False
    
    
    def sensit(self, show_tables=True, show_tornados=True, precision=4):
        """ Perform one-way range sensitivity analysis on each alternative, 
            generate results table, and plot tornado diagram
        Parameters:
          show_tables = True (default) or False
          show_tornados = True (default) or False
          precision = number of decimal places to display, default=4
        Returns:
          None
        """
        print(f"\nOne-Way Range Sensitivity for {self.title}")    
    
        self.Lows, self.Highs, self.Swings, self.Bases = [], [], [], []
    
        for i, fn in enumerate(self.Obj_functions):
            
            results = self._range_sensit_table(fn)
            # Unpack the results
            sensit_df, base_npv, min_npv, max_npv = results
            
            if show_tables:
                print(f"\nAlternative: {self.Alt_names[i]}")
                pd.options.display.float_format=(
                    '{:,.'+str(precision)+'f}').format
                # pd.options.display.float_format = '{:,.6f}'.format
                print(sensit_df)
                txt = " {} {} =  {:,."+str(precision)+"f}"
                print(txt.format("\n  Base",  self.output_label, base_npv))
                print(txt.format(    " Min ", self.output_label, min_npv))
                print(txt.format(    " Max ", self.output_label, max_npv))
                '''
                print(f"\n  Base {self.output_label} = {base_npv:,.6f}")
                print(f"  Min  {self.output_label} = {min_npv:,.6f}")
                print(f"  Max  {self.output_label} = {max_npv:,.6f}")
                '''
            # Save the results for combined tornado plotting
            self.Lows.append(list(sensit_df['obj_low']))
            self.Swings.append(list(sensit_df['swing']))
            self.Highs.append(list(sensit_df['obj_high']))
            self.Bases.append(base_npv)
            self.sensit_done = True
            
            if show_tornados:
                #  Draw the tornado diagram
                print(f"\n Tornado diagram for {self.Alt_names[i]}:")
                self._tornado_diagram(sensit_df.index, sensit_df['obj_low'], 
                     sensit_df['obj_high'], base_npv, self.Alt_names[i])

    def _range_sensit_table(self, fun):
        """Perform one-way range sensitivity analysis
        Parameters:
          fun = objective function to use
        Returns:  
          Pandas dataframe of results
        """
        data = pd.DataFrame.from_dict(self.Var_data, orient='index',
                                  columns=['low', 'base', 'high'])
        # Compute base case obj value
        base_values = [p[1] for p in self.Var_data.values()]
        obj_base = fun(*base_values)
        lows, highs = [], []
        for y in data.index:
            v = []
            # Set the low value for variable y
            for x in data.index:
                if x==y: v.append(data['low'][x])
                else:    v.append(data['base'][x])
            # Compute objective value when variable y is at low value
            obj_low = fun(*v)
    
            v = []
            # Set the high value for variable y
            for x in data.index:
                if x == y: v.append(data['high'][x])
                else:      v.append(data['base'][x])
            # Compute objective value when variable y is at high value
            obj_high = fun(*v)
            if obj_high < obj_low:
                obj_low, obj_high = obj_high, obj_low  # arrange in order
            lows.append(obj_low)
            highs.append(obj_high)
        # Add to data frame
        data['obj_low'] = lows
        data['obj_high'] = highs
      
        # Determine the min and max objective values
        obj_min = min(list(data['obj_high']) + list(data['obj_low']))
        obj_max = max(list(data['obj_high']) + list(data['obj_low']))
        # Compute the swing for each variable and append it to data.
        data['swing']=[abs(hi-lo) for hi,lo in zip(data['obj_high'],
                                                   data['obj_low'])]
        # Sort the factors by swing in descending order for plotting
        # data.sort_values(['swing'], inplace=True, ascending=False)
        return data, obj_base, obj_min, obj_max

    def _tornado_diagram(self, labels, limits1, limits2, base_value, name):
        """Plot Tornado Diagram 
        Parameters: 
          labels = array of variable names (str)
          limits1 = array of low values for the variables (numeric)
          limits2 - array of high values for the variables (numeric)
          base_value = base value for the tornado diagram (numeric)
          name = lablel for the x-axis (str)
        Returns:
          None """

        nvars = len(labels)
        assert nvars==len(limits1), "Wrong data size!"
        assert nvars==len(limits2), "Wrong data size!"
        data = pd.DataFrame()
        data['var'] = labels
        data.set_index('var', inplace=True)
        data['lo'] = [min(limits1[i], limits2[i]) for i in range(nvars)]
        data['hi'] = [max(limits1[i], limits2[i]) for i in range(nvars)]
        data['swing'] = [ data['hi'][v] -data['lo'][v] for v in data.index]
        data.sort_values(['swing'], ascending=False, inplace=True)
        
        # fig, ax = plt.subplots(figsize=(8,4))
        fig, ax = plt.subplots(figsize=(12, nvars+2))
        ax.invert_yaxis()
        ax.xaxis.set_visible(True)
        ax.xaxis.grid(True)
        # Compute the min and max values for the tornado diagram axis
        swing_range = data['hi'].max() - data['lo'].min()
        if swing_range == 0: margin = 10
        else: margin = 0.1*swing_range
        xmin, xmax = data['lo'].min()-margin, data['hi'].max()+margin
        ax.set_xlim(xmin, xmax)
        ax.set_xlabel(self.output_label, fontsize=14)
        # Plot the tornado diagram
        for v in data.index:
            ax.barh(v, data['swing'][v], left=data['lo'][v], height=0.4, 
                    color='black', align='center')
        ax.get_xaxis().set_major_formatter(
           plt.FuncFormatter(lambda x, loc: f"{int(x):,}"))
        ax.tick_params(axis="y", labelsize=16)
        # Plot the base value vertical line
        ax.vlines(base_value, -0.5, nvars-0.5, 'r')
        # Draw the zero NPV vertical line if necessary
        if xmin < 0 and xmax > 0:
            ax.vlines(0, -0.5, nvars-0.5, 'b', ls="--")
        ax.set_title(f"Tornado diagram for {name}")
        plt.show()
        
        
    def combined_tornados(self, xL=None, xH=None, xstep_size=None):
        """Plot combined tornados
          Parameters:
            xL = lower limit for plotting combined tornados
            xH = upper limit for plotting combined tornados
            xstep_size = x-axis step_size 
          Returns: None
        """
        if not self.sensit_done:
            # Do it silently
            self.sensit(show_table=False, show_tornado=False)
        
        print(f"\nCombined Tornado Diagrams for {self.title}")
        nvar = len(self.Var_names)
        nalt = len(self.Alt_names)
        xmin = min(min(self.Lows))
        xmax = max(max(self.Highs))
        xrange = xmax - xmin
        if xL == None: xmin = xmin - 0.1*xrange
        else: xmin = xL
        if xH == None: xmax = xmax + 0.1*xrange
        else: xmax = xH
        
        fig, ax = plt.subplots(figsize=(12, nvar+2))
        ax.xaxis.set_visible(True)
        ax.set_xlim(xmin, xmax)
        if xstep_size is not None:
            ax.set_xticks(np.linspace(xmin, xmax, 
                                      int((xmax-xmin)/xstep_size+1)))
        ax.set_xlabel(self.output_label, fontsize="x-large")
        ax.set_ylim(-0.25, nvar)
        ax.invert_yaxis()
        ax.xaxis.grid(True)
        colors = "rbgcmy"
        
        for a in range(nalt):
            ax.vlines(self.Bases[a], -0.25, nvar, color='black', ls='--')
            for y in range(nvar):
                ax.barh(y+0.2*a, self.Swings[a][y], 0.2, self.Lows[a][y], 
                        color=colors[a])

        ax.vlines([0], -0.25, nvar, 'black')    
        ax.set_yticks(range(nvar))
        ax.set_yticklabels(self.Var_names, fontsize='x-large')
        ax.get_xaxis().set_major_formatter(
           plt.FuncFormatter(lambda x, loc: f"{int(x):,}"))
        ax.legend(self.Alt_names, ncol=nalt, bbox_to_anchor=(0.5, 1),
               loc='lower center', fontsize='large')
        leg = ax.get_legend()
        for a in range(nalt):
            leg.legendHandles[a].set_color(colors[a])
            leg.legendHandles[a].set_linestyle('solid')
            leg.legendHandles[a].set_linewidth(8)
            
        plt.show()
         
#############################################################################
class AHPmatrix:
    """ Class for AHP pairwise comparison matrices
    AHPmatrix(A, upper_triangle=False, description=''):
    Parameters:
      A = a valid AHP pairwise comparison matrix
           upper_triangle=True if A is upper triangle, 
                          False (default) if otherwise.
      description = string name for A
 
    Attributes:
      A = the pairwise comparison matrix
      w = the priority weight after A is solved
      size = the size of the matrix A
      lambda_max = the dominance eigen value of A
      CI = the inconsistency index of A
      CR = the inconsistency ratio of A
      
    Methods:
      solve(method):
        method = "Algebra"(default),"Power", "RGM", 
                      "ColsNorm", "GenEigen"
      pprint(): Pretty print matrix A
        
    """
    # Random indices for computing CR. Internal use only.
    __RI=(0.58,0.90,1.12,1.24,1.32,1.41,1.45,1.49,1.51,1.54,1.56,1.57,1.58)
        
    def __init__(self, A, upper_triangle=False, description=''):
        """
        Parameters:
          A = a valid AHP pairwise comparison matrix
          upper_triangle = True if A is upper triangle, 
                          False (default) if otherwise.
          description = name string for A
        """
        A = np.array(A)
        self.A = self.FromUpperTriangle(A) if upper_triangle else A
        self.size, _ = self.A.shape
        self.w = None
        self.lambda_max = None
        self.CI = None
        self.CR = None
    
    def FromUpperTriangle(self, Upper):
        """Convert an upper triangle AHP matrix to a full matrix
        Parameter:
          Upper = a flatten array of the upper triangle elements of A
        Returns: 
          A in full AHP matrix 
        """
        valid_len = [int(n*(n-1)/2) for n in range(2,16)]
        try:
            size = valid_len.index(len(Upper))+2
        except: 
            print("Invalid upper triangle array size")
            return None
        A = np.identity(size)
        A[np.triu_indices(size,1)] = 1 / Upper
        A = A.T
        A[np.triu_indices(size,1)] = Upper
        return A
    
    def solve(self, method="Algebra"):
        """ Solve the AHP matrix using specified method. 
        Parameters:
          method = "Algebra" (default), "Power", "RGM", "ColsNorm", "GenEigen" 
        Returns: 
            w, lambda_max, CI, CR of the matrix.
        """
        METHODS = {
            "Algebra" : self.Algebra,
            "RGM": self.RGM,
            "ColsNorm" : self.ColsNorm,
            "Power" : self.Power,
            "GenEigen" : self.GenEigen }
        assert method in METHODS
        return METHODS[method](self.A)
  
    def Algebra(self, A):
        """ Compute the AHP matrix A using linear algebra method.
        Parameter:
          A = matrix to evaluate
        Returns: 
          w, lambda_max, CI, CR of A
        """
        n = self.size
        # Solve for lambda such that Det(A - lambda*I) = 0
        sol = root(lambda x: np.linalg.det(A-np.eye(n)*x), n)
        self.lambda_max = sol.x[0]
        # Find w by solving a set of linear equations M w = b
        # M = A - lambda_max I for first n-1 rows
        M = A - np.eye(n)*self.lambda_max  
        # Replace the last row with [1, 1..., 1]
        M[n-1] = np.ones(n)
        b = np.append(np.zeros(n-1), [1])  # b = [0, 0, ..., 1]
        self.w = np.linalg.solve(M,b)
        self.CI = (self.lambda_max-n)/(n-1)
        self.CR = 0 if n == 2 else self.CI/self.__RI[n-3]
        return self.w, self.lambda_max, self.CI, self.CR
    
    def Power(self, A):
        """ Compute the AHP matrix A using Power Iterations method.
        Parameter:
          A = matrix to evaluate
        Returns: 
          w, lambda_max, CI, CR of A
        """
        gm = stats.gmean(A, axis=1)   # Use RGM method as initial value
        w = gm/gm.sum()
        max_iter= 1000000
        epsilon = 1.E-16
        for iter in range(max_iter):
            w1 = np.dot(A,w)    # w(k+1) = A w(k) 
            w1 = w1/w1.sum()    # normalize w(k+1)
            if all(np.absolute(w1-w) < epsilon):
                w = w1
                # print(f"Tolerance {epsilon} achieved at iter #{iter}")
                break
            w = w1
        self.w = w
        self.lambda_max = (np.dot(A,self.w)/self.w).mean()
        n = self.size
        self.CI = (self.lambda_max-n)/(n-1)
        self.CR = 0 if n==2 else self.CI/self.__RI[n-3]
        return self.w, self.lambda_max, self.CI, self.CR
    
    def RGM(self, A):
        """ Compute the AHP matrix A using the RGM approximation method.
        Parameter:
          A = matrix to evaluate
        Returns: 
          w, lambda_max, CI, CR of A
        """
        gm = stats.gmean(A, axis=1)   
        self.w = gm/gm.sum()
        self.lambda_max = (np.dot(A,self.w)/self.w).mean()
        n = self.size
        self.CI = (self.lambda_max-n)/(n-1)
        self.CR = 0 if n==2 else self.CI/self.__RI[n-3]
        return self.w, self.lambda_max, self.CI, self.CR
    
    def ColsNorm(self, A):
        """ Compute the AHP matrix A using columns normalization 
            approximation method.
        Parameter:
          A = matrix to evaluate
        Returns: 
          w, lambda_max, CI, CR of A
        """
        self.w = (A/A.sum(axis=0)).mean(axis=1)
        self.lambda_max = (np.dot(A,self.w)/self.w).mean()
        n = self.size
        self.CI = (self.lambda_max-n)/(n-1)
        self.CR = 0 if n==2 else self.CI/self.__RI[n-3]
        return self.w, self.lambda_max, self.CI, self.CR
    
    def GenEigen(self, A):
        """ Compute AHP matrix using general np.linalg.eig function 
        Parameter:
          A = matrix to evaluate
        Returns: 
          w, lambda_max, CI, CR of A
        """
        # Compute all the eigenvalues and eigenvectors
        eigVal, eigVec = np.linalg.eig(A)
        # Get the dominant real eigenvalue and its eigenvector
        self.lambda_max, self.w = max([(val.real, vec.real) 
                    for val, vec in zip(eigVal, eigVec.T) 
                       if np.isreal(val)])
        self.w = self.w/self.w.sum()  # Normalize it
        n = self.size
        self.CI = (self.lambda_max-n)/(n-1)
        self.CR = 0 if n==2 else self.CI/self.__RI[n-3]
        return self.w, self.lambda_max, self.CI, self.CR
     
    def pprint(self):
        """ Pretty print A in fraction format where applicable """
        np.set_printoptions(formatter={
          'float_kind':lambda x: 
              str(fractions.Fraction(x).limit_denominator(100)).center(4)})
        print(self.A)
        np.set_printoptions(formatter=None)
   
#############################################################################   
class AHP3Lmodel:
    """ Class for 3-Level AHP Models 
    AHP3model(Goal, MC, MC_matrix, alt_names, alt_matrices)
    Parameters:
      Goal = Goal.
      MC = list of main criteria.
      MC_matrix = upper triangle of criteria pairwise comparison 
                    matrix w.r.t. Goal.
      alternatives = list of alternative names.
      alt_matrices  = list of alternatives pairwise comparison matrices 
                      (upper triangular) w.r.t each main criterion. 

    Attributes:
      Goal = Goal
      MC = list of main criteria
      MC_matrix = upper triangle of criteria pairwise comparison 
                    matrix w.r.t. Goal.
      alternatives = list of alternative names
      alt_matrices = list of alternatives pairwise comparison matrix 
                      (upper triangular) w.r.t each main criterion.
      n_MC  = number of main criteria
      n_alt = number of alternative
      
    Methods:
      model(): Get a summary of the AHP model
      solve(method='Algebra'): solve the model using method
      sensit(): perform sensitivity analysis and generate 
               rainbow diagrams
    """
       
    def __init__(self, Goal, MC, MC_matrix, alternatives, alt_matrices):
        """
        Parameters:
          Goal = Goal.
          MC = list of main criteria.
          MC_matrix = upper triangle of criteria pairwise comparison 
                        matrix w.r.t. Goal.
          alternatives = list of alternative names.
          alt_matrices  = list of alternatives pairwise comparison matrices 
                      (upper triangular) w.r.t each main criterion. 
        """
        self.Goal = Goal
        self.MC = MC
        self.n_MC  = len(self.MC)
        self.MC_matrix = AHPmatrix(MC_matrix, upper_triangle=True)
        self.alternatives = alternatives
        self.n_alt = len(alternatives)
        self.alt_matrices = [AHPmatrix(alt_matrices[k], upper_triangle=True) 
                         for k in range(self.n_MC)]
        self.solved = False  

    def model(self):
        """ Print a summary of the model and data """
        
        print("Model Summary:")
        print(f"Goal: {self.Goal}")
        print("Criteria:")
        print(f"  Number = {self.n_MC}")
        print(f"  {self.MC}")
        print(f"\nPairwise comparison w.r.t. Goal {self.Goal}:")
        self.MC_matrix.pprint()
        
        print("\nAlternatives:")
        print(f"  Number = {self.n_alt}")        
        print(f"  {self.alternatives}")
        
        for cr in range(self.n_MC):
            print(f"\nPairwise comparison w.r.t criterion {self.MC[cr]}")
            self.alt_matrices[cr].pprint()


    def solve(self, method="Algebra"):
        """ Solve the 3-level AHP model using specified method.
        parameters:
          method = method for solving matrix (default="Algebra")
             (see AHPmatrix class for other choices).
        Returns: 
          dictionary { Alternative_name : Global Weight}
        """
        print("\nModel Summary:")
        print(f"  Goal: {self.Goal}")
        print(f"  Criteria: {self.MC}")
        print(f"  Alternatives: {self.alternatives}")
    
        # Compute main criteria local weights
        self.cr_w, lam, CI, CR = self.MC_matrix.solve(method=method)
        if CR > 0.1: print("Warning: CR > 0.1")
        
        print(f"\nCriteria w.r.t. Goal {self.Goal}:\n")
        np.set_printoptions(formatter={
          'float_kind':lambda x: 
              str(fractions.Fraction(x).limit_denominator(100)).center(4)})
        print(self.MC_matrix.A)
        np.set_printoptions(formatter=None)
        
        with np.printoptions(precision=6, suppress=True):
            print(f"Lambda_max = {lam:.6f}, CI= {CI:.6f}, CR= {CR:.6f}")
            print("Criteria Weights=", self.cr_w)
    
        # Compute the local weights of the alternatives w.r.t. each criterion
        self.alt_local_weights = np.ones((self.n_alt, self.n_MC))
        for j in range(self.n_MC):
            A = self.alt_matrices[j]
            w, lam, ci, cr = A.solve(method=method)
            if cr > 0.1: print("Warning: CR > 0.1")
            print(f"\nAlternatives w.r.t. criterion {self.MC[j]}")
            np.set_printoptions(formatter={
            'float_kind':lambda x: 
                str(fractions.Fraction(x).limit_denominator(100)).center(4)})
            print(A.A)
            np.set_printoptions(formatter=None)
            with np.printoptions(precision=6, suppress=True):
                print(f"Lambda_max = {lam:.6f}, CI= {ci:.6f}, CR= {cr:.6f}")
                print("Local Weights=", w)
            # Put the alternative local weights into columns 
            self.alt_local_weights[:, j] = w
    
        # Compute the Alternative's Global weights.
        self.alt_global_weights = np.dot(self.alt_local_weights, self.cr_w)
        
        # Keep results in a dictionary and print them out
        results_dict = {self.alternatives[i]: self.alt_global_weights[i] 
                        for i in range(self.n_alt)}
        print("\nResults:")
        print("\n".join(f"  {k} :{v:.6f}" for k, v in results_dict.items()))
        print("\nSorted Results:")
        print("\n".join(f"  {k} :{v:.6f}" for k, v in 
            sorted(results_dict.items(), key=lambda x: x[1], reverse=True)))
        
        self.solved = True
        return results_dict

    def sensit(self):
        """ Perform sensitivity analysis by plotting rainbow diagrams """
                
        if not self.solved:
            print("Model must be solved first")
            return None
        
        # Plotting Rainbow diagrams
        print("\nSensivity Analysis:")
        for cr in range(self.n_MC):
            print("\nRainbow Diagram for changing weight of criterion",
                  self.MC[cr])
            table = self._sensit_table(self.alt_local_weights, self.cr_w, cr)
            fig0, ax0 = plt.subplots()
            ax0.plot(np.linspace(0,1,11), table, lw=2)
            ax0.set_ylabel("Alternative Global Weight")
            ax0.set_yticks(np.linspace(0,1,11))
            ax0.set_ylim((0,1))
            ax0.set_xlabel(f"Weight of criterion {self.MC[cr]}")
            ax0.set_xticks(np.linspace(0,1,11))
            ax0.set_xlim((0,1))
            ax0.set_title(f"Rainbow Diagram for Criterion {self.MC[cr]}")
            ax0.legend(self.alternatives)
            ax0.grid()
            ax0.vlines(self.cr_w[cr],0,1,ls="--")
            plt.show()
 
    def _sensit_table(self, alt_lw, base, idx):
        """ Compute alternative global weights when weight of criterion idx 
            is varied from 0 to 1. Private """
        alt_gw = []
        size = len(base)
        for p in np.linspace(0,1,11):
            w = np.empty(size)
            for j in range(size):
                if not (j==idx):
                    w[j]=(1-p)*base[j]/(1-base[idx])
                else:
                    w[j]=p
            alt_gw.append(np.dot(alt_lw, w))
        return alt_gw

#############################################################################

class AHP4Lmodel:
    """ Class for 4-Level AHP Models 
    AHP4Lmodel(Goal, MC, rix, SC, SC_matrices, 
                       alternatives, alt_matrices):
    Parameters:
      Goal = Goal
      MC = list of main criteria
      rix = pairwise comparison matrix of main criteria  
                      (upper triangle) w.r.t. Goal.
      SC = list of lists of sub-criteria w.r.t. each main criterion
      SC_matrices = list of lists of pairwise comparison matrices 
                        (upper triangle) w.r.t each main criterion
      alternatives = list of alternative names
      alt_matrices = list of lists of alternative pairwise comparison 
                  matrices (upper triangle) w.r.t. each sub-criterion
    
    Attributes:
      goal = Goal
      MC = list of main criteria
      n_MC  = number of main criteria
      rix = AHPmatrix for main criteria  
      SC = list of lists of sub-criteria w.r.t. each main criterion
      SC_matrices = list of lists of AHPmatrix w.r.t each main criterion
      alternatives = list of alternative names
      alt_matrices = list of lists of alternative AHPmatrix w.r.t. each 
                     sub-criterion
      n_alt = number of alternatives

      MC_w = array of main criteria weights
      SC_weights = list of arrays of sub-criteria weights
      alt_weights = list of arrays of alternative weights
    
    Methods:
      model() : show model summary
      solve(method='Algebra'): solve the AHP model using method
      sensit(ymax=None): perform sensitivity analysis. 
                         ymax = upper limit of rainbow diagrams to plot 
    """
    
    def __init__(self, Goal, MC, MC_matrix, SC, SC_matrices, 
                       alternatives, alt_matrices):
        """
        Parameters:
          Goal = Goal
          MC = list of main criteria
          MC_matrix = pairwise comparison matrix of main criteria  
                      (upper triangle) w.r.t. Goal.
          SC = list of lists of sub-criteria w.r.t. each main criterion
          SC_matrices = list of lists of pairwise comparison matrices 
                        (upper triangle) w.r.t each main criterion
          alternatives = list of alternative names
          alt_matrices = list of lists of alternative pairwise comparison 
                         matrices (upper triangle) w.r.t. each sub-criterion
        """
        self.Goal = Goal
        
        self.MC = MC
        self.n_MC  = len(self.MC)
        self.MC_matrix = AHPmatrix(MC_matrix, upper_triangle=True)
        
        self.SC = SC
        self.SC_matrices = []
        for X in SC_matrices:
            if X is None:
                self.SC_matrices += [X]
            else:
                self.SC_matrices += [AHPmatrix(X, upper_triangle=True)]
        
        self.alternatives = alternatives
        self.n_alt = len(self.alternatives)
        self.alt_matrices = [[AHPmatrix(A, upper_triangle=True) for A in L]
                            for L in alt_matrices]
          
        # self.leaf_criteria = [x for items in SC for x in items]
        self.MC_w = []
        self.SC_weights = []
        self.alt_weights = []
        self.solved = False

    def model(self):
        """ Display a summary of the AHP model """
        
        print(f"\nGoal: {self.Goal}")
        print(f"Number of main criteria = {self.n_MC}")
        print(f"Main Criteria: {self.MC}")
        
        print(f"\nPairwise comparison of Main Criteria wrt {self.Goal}:")
        self.MC_matrix.pprint()

        for cr in range(self.n_MC):
            print(f"\nMain Criteron {cr+1}: {self.MC[cr]}")
            if self.SC[cr] is not None: 
                print(f"  Number of sub-criteria = {len(self.SC[cr])}")
                print(f"  {self.SC[cr]}")
                print(f"Pairwise comparison Sub Criteria wrt {self.MC[cr]}:")
                self.SC_matrices[cr].pprint()
                
                for scr in range(len(self.SC[cr])):
                    print(f"\nNumber of alternatives = {self.n_alt}")
                    print(f"{self.alternatives}")          
                    print("\nPairwise comparison of Alternatives wrt"
                          f" {self.SC[cr][scr]}")
                    self.alt_matrices[cr][scr].pprint()
            else:
                print(f"Criterion {self.MC[cr]} has no sub-criterion")
                print(f"\nNumber of alternatives = {self.n_alt}")
                print(f"{self.alternatives}")
                print(f"Pairwise comparison w.r.t. {self.MC[cr]}")
                self.alt_matrices[cr][0].pprint()
                    

    def solve(self, method="Power"):
        """ Solve the AHP model using method to compute AHP matrices 
        Parameters:
          method = method to use for computing AHP matrices
        Returns:
          dictionary {Alt_i: global weight_i for alternative i}
        """
        
        print(f"\nGoal: {self.Goal}")
        print(f"Alternatives: {self.alternatives}")
        print(f"Main Criteria: {self.MC}")
       
        # Compute the main criteria weights
        self.MC_w, lam, CI, CR = self.MC_matrix.solve(method=method)
        if CR > 0.1: print("Warning: CR > 0.1")
        print("\nPairwise comparison of Main Criteria w.r.t."
              f" Goal {self.Goal}:")
        self.MC_matrix.pprint()
        with np.printoptions(precision=6, suppress=True):
            print(f"Lambda = {lam:.6f}, CI= {CI:.6f}, CR= {CR:.6f}")
            print(f"Main criteria weights= {self.MC_w}")
        
        # For each main criterion, compute its sub-criteria weight and
        # alternative weights w.r.t each sub-criterion.
        self.SC_weights = []
        self.alt_weights = []
        for mc in range(self.n_MC):
            print(f"\nMain Criteria {mc+1}: {self.MC[mc]}")
            if self.SC[mc] is not None:
                print(f"Sub Criteria: {self.SC[mc]}")
                # Compute the subcriteira weights
                w,lam,CI,CR = self.SC_matrices[mc].solve(method=method)
                print(f"Pairwise comparison of Sub-Criteria for {self.MC[mc]}:")
                self.SC_matrices[mc].pprint()
                with np.printoptions(precision=6, suppress=True):
                    print(f"Lambda = {lam:.6f}, CI= {CI:.6f}, CR= {CR:.6f}")
                    print(f"Sub-citeria weights= {w}")
                self.SC_weights.append(w)
                n_sc = len(self.SC[mc])
                for sc in range(n_sc):
                    # Compute alternative local weights
                    w,lam,CI,CR = self.alt_matrices[mc][sc].solve(method=method)
                    print(f"\nPairwise comparison of Alternatives wrt {self.SC[mc][sc]}")
                    self.alt_matrices[mc][sc].pprint()
                    with np.printoptions(precision=6, suppress=True):
                        print(f"Lambda = {lam:.6f}, CI= {CI:.6f}, CR= {CR:.6f}")
                        print(f"Alternative weights= {w}")
                    self.alt_weights.append(w)
        
            if self.SC[mc] is None:
                print("Sub Criteria: None")
                # Compute the sub-criteira weights
                self.SC_weights.append(np.array([1]))
                # Compute alternative local weights
                w,lam,CI,CR = self.alt_matrices[mc][0].solve(method=method)
                print(f"\nPairwise comparison of Alternatives wrt {self.MC[mc]}")
                self.alt_matrices[mc][0].pprint()
                with np.printoptions(precision=6, suppress=True):
                    print(f"Lambda = {lam:.6f}, CI= {CI:.6f}, CR= {CR:.6f}")
                    print(f"Alternative weights= {w}")
                self.alt_weights.append(w)
            
        # Compute alternative global weights     
        global_w = self._global_w(self.MC_w, self.SC_weights)
        
        self._print_results(self.alternatives, global_w)
        self.solved = True
        return {self.alternatives[i]: global_w[i] for i in range(self.n_alt)}
        
    def sensit(self, ymax=1, ystep=0.1):
        """ Sensitivity Analysis: Plotting Rainbow diagrams 
        Parameters:
          ymax = upper lime of y-axis to plot
          ystep = step size of y-axis to plot """
        
        print("\nSensitivity Analysis:")
        for mc in range(self.n_MC):
            print("\nRainbow Diagram for changing weight of main criterion", 
                  self.MC[mc])
            table = self._sensit_MC_table(self.MC_w, mc)
            fig, ax = plt.subplots(dpi=100)
            ax.plot(np.linspace(0, 1, 11), table, lw=2)
            ax.vlines(self.MC_w[mc],0,ymax,ls="--")
            ax.set_xlabel(f"Weight of main-criterion {self.MC[mc]}")
            ax.set_xticks(np.linspace(0, 1, 11))
            ax.set_xlim((0, 1))
            ax.set_ylabel("Alternative Global Weight")
            ax.set_yticks(np.arange(0, ymax+0.001, ystep))
            ax.set_ylim((0, ymax))
            ax.legend(self.alternatives)
            ax.grid()
            plt.show()
            
            if self.SC[mc] is not None:
                for sc in range(len(self.SC[mc])):
                    print("\nRainbow Diagram for changing weight of sub-criterion", 
                          self.SC[mc][sc])
                    table = self._sensit_SC_table(self.SC_weights[mc], sc, mc)
                    fig, ax = plt.subplots(dpi=100)
                    ax.plot(np.linspace(0, 1, 11), table, lw=2)
                    ax.vlines(self.MC_w[mc],0, ymax,ls="--")
                    ax.set_xlabel(f"Weight of sub-criterion {self.SC[mc][sc]}")
                    ax.set_xticks(np.linspace(0, 1, 11))
                    ax.set_xlim((0, 1))
                    ax.set_ylabel("Alternative Global Weight")
                    ax.set_yticks(np.arange(0, ymax+0.001, ystep))
                    ax.set_ylim((0, ymax))
                    ax.legend(self.alternatives)
                    ax.grid()
                    plt.show()

    def _global_w(self, mc_w, sc_w):
        """ Compute alternative global weights 
        mc_w = array of main criteria weights
        sc_w = list of arrays of sub-criteria weights """

        leaf_weights = []
        for mc in range(self.n_MC):
            if self.SC[mc] is None:
                leaf_weights.append(mc_w[mc])
            else:
                for sc in range(len(self.SC[mc])):
                    leaf_weights.append(mc_w[mc]*sc_w[mc][sc])
      
        return np.dot(np.array(self.alt_weights).T, np.array(leaf_weights))        


    def _print_results(self, names, values):
        """ Pretty print the results """
        # Put in dictionary
        results = {names[i]: values[i] for i in range(len(names))}
        print("\nResults:")
        print("\n".join(f"  {k} : {v:.6f}" for k, v in results.items()))
        print("\nSorted Results:")
        print("\n".join(f"  {k} : {v:.6f}" for k, v in 
                sorted(results.items(), key=lambda x: x[1], reverse=True)))

        
    def _sensit_MC_table(self, base, idx):
        """ Compute a table of alternative global weights when weight of 
            main criterion idx is varied from 0 to 1 """
        alt_gw = []
        size = len(base)
        for p in np.linspace(0,1,11):
            w = np.empty(size)
            for j in range(size):
                if not (j==idx):
                    w[j]=(1-p)*base[j]/(1-base[idx])
                else:
                    w[j]=p
            alt_gw.append(self._global_w(w, self.SC_weights))             
        return alt_gw
    
    def _sensit_SC_table(self, base, idx, mc):
        """ Compute a table of alternative global weights when weight 
            of a sub-criterion idx is varied from 0 to 1 """
        alt_gw = []
        size = len(base)
        for p in np.linspace(0,1,11):
            w = np.empty(size)
            for j in range(size):
                if not (j==idx):
                    w[j]=(1-p)*base[j]/(1-base[idx])
                else:
                    w[j]=p
            sc_w = self.SC_weights.copy()
            sc_w[mc] = w
            alt_gw.append(self._global_w(self.MC_w, sc_w))            
        return alt_gw
    
#############################################################################
class AHPratings_model:
    """ Class for AHP Ratings Method model 
    Parameters:
      Criteria = dict of main criteria names and matrices
      Ratings = dict of criteria ratings and their matrices
      echo (False) = Bool to show progress of model creation or not
      method ('Algebra') = a valid method for solving AHP matrix
      
    Methods:
      show_model: Pretty print the model
        Parameter: 
          Nil
        
      evaluate: Evaluate the rated candidates
        Parameter:
          Dict of candidates and their ratings under each criterion
        Return:
          Dict of candidate names and their total scores
          
      sensit: Perform Sensitivity Analysis with Rainbow Diagrams 
        Parameter:
          Dict of candidates and their ratings under each criterion
        Outputs:
          A rainbow diagram for each criterion
    """
    
    def __init__(self, Criteria, Ratings, echo=False, method='Algebra'):
        """ Constructor for the AHP Ratings Method model """
        self.Criteria = Criteria
        self.Ratings = Ratings
        self.Criteria_w = {}
        self.Rating_scores = {}
        
        self.create_model(echo, method)

    def create_model(self, echo, method):
        """ Create AHP Ratings Method Model 
        Parameters:
          echo = Bool to show progress or not
          method = a valid method to solve AHP matrix
        """
        # Evaluate the main criteria matrix.
        w_cr, lam, CI, CR = self.Criteria['A'].solve(method=method)
        self.Criteria['w'] = w_cr
        self.Criteria['lambda'] = lam
        self.Criteria['CI'] = CI
        self.Criteria['CR'] = CR
    
        for i, cr in enumerate(self.Criteria['Names']):
            self.Criteria_w[cr] = w_cr[i]
        
        if echo:
            print(f"\nMain Criteria:  {self.Criteria['Names']}")
            self.Criteria['A'].pprint()
            print(f"  lambda_max = {lam:.4f},  CI = {CI:4f},  CR = {CR:4f}")
            print("  Criteria weights = ", end="")
            self.pprint_w(w_cr)
        
        # Solve each of the criterion matrixes
        for k, cr in enumerate(self.Criteria['Names'], 1):
            A = self.Ratings[cr]['A']
            w, lam, CI, CR = A.solve(method=method)
            wi = w/w.max()
            
            # Ratimg_scores[cr,r] = score for rating r under criterion cr
            for i, r in enumerate(self.Ratings[cr]['Ratings']):
                self.Rating_scores[cr, r] = wi[i]
                
            self.Ratings[cr]['w'] = w
            self.Ratings[cr]['wi'] = wi
            self.Ratings[cr]['lambda'] = lam
            self.Ratings[cr]['CI'] = CI
            self.Ratings[cr]['CR'] = CR
            
            if echo:
                print(f"\nCriterion {k}: {cr}")
                print(f"Ratings = {self.Ratings[cr]['Ratings']}")
                A.pprint()
                print(f" lambda_max = {lam:.4f},  CI = {CI:4f},  CR = {CR:4f}")
                print(" normalized w = ", end="")
                self.pprint_w(w)
                print(" idealized  w = ", end="")
                self.pprint_w(wi)
        
        if echo:
            print("\nAHP Ratings Method Model created.")
        return True

    def show_model(self):
        """ Show the Model information 
          Parameter: Nil 
          Return: Nil
        """
        print("\nAHP Ratings Method Model:")
        print(f"  Main Criteria = {self.Criteria['Names']}")
        self.Criteria['A'].pprint()
        print(f"  Lambda_max = {self.Criteria['lambda']:.4f},",
              f"  CI = {self.Criteria['CI']:.4f}",
              f"  CR = {self.Criteria['CR']:.4f}")
        print("  w = ", end="")
        self.pprint_w(self.Criteria['w'])
              
        for k, cr in enumerate(self.Criteria['Names'], 1):
            print(f"\nCriterion {k}: {cr}")
            print(f"Ratings = {self.Ratings[cr]['Ratings']}")
            self.Ratings[cr]['A'].pprint()
            print(f" Lambda_max = {self.Ratings[cr]['lambda']:.4f}",
                  f"  CI = {self.Ratings[cr]['CI']:.4f}",
                  f"  CR = {self.Ratings[cr]['CR']:.4f}")
            print(" normalized w = ", end="")
            self.pprint_w(self.Ratings[cr]['w'])
            print(" idealized  w = ", end="")
            self.pprint_w(self.Ratings[cr]['wi'])
    
    def evaluate(self, candidates):
        """ Evaluate the rated employees 
        Parameter:
          Dict of candidates and their ratings under each criterion
        Return:
              Dict of candidate names and their total scores
        """
        Scores = {}
        for person, rated in candidates.items():
            Scores[person] = \
                sum([self.Criteria_w[cr]*self.Rating_scores[cr, rated[cr]] 
                                  for cr in rated.keys()])
        print("\nOverall Scores (sorted):")
        for person, score in sorted(Scores.items(), key=lambda x:x[1],
                               reverse=True):
            print(f"  {person:12s} : {score:.6f}")
        return Scores


    def sensit(self, candidates, dpi=100):
        """ Perform Sensitivity Analysis with Rainbow Diagrams 
        Parameter:
          employees = Dict of candidates and their ratings 
                          under each criterion
          dpi = dpi to plot rainbow diagram (default 100)
        Outputs:
          A rainbow diagram for each criterion
        """
        base_w = self.Criteria_w
        adj_w = self.Criteria_w.copy()
        
        print("\nSensivity Analysis:")
        for cr in self.Criteria['Names']:
            fig0, ax0 = plt.subplots(dpi=dpi)
            x = np.linspace(0,1,11)
            for person, rated in candidates.items():
                y = []
                for p in x:
                   for c in adj_w.keys():
                       if c==cr:
                           adj_w[c]=p
                       else:
                           adj_w[c]=(1-p)*base_w[c]/(1-base_w[cr])
                   score=sum([adj_w[c]*self.Rating_scores[c, rated[c]] 
                                  for c in rated.keys()])
                   y.append(score)
                ax0.plot(x, y, label=person, lw=2)
            
            ax0.vlines(base_w[cr], 0, 1, ls='--')
            ax0.set_title(f"Rainbow Diagram for Criterion {cr}")
            ax0.set_ylabel("Total Weight")
            ax0.set_yticks(np.linspace(0,1,11))
            ax0.set_ylim((0,1))
            ax0.set_xlabel(f"Weight of criterion {cr}")
            ax0.set_xticks(np.linspace(0,1,11))
            ax0.set_xlim((0,1))
            ax0.legend()
            ax0.grid()
            plt.show()

    def pprint_w(self, w):
        """ Pretty print an array of reals """
        print(','.join([f"  {x:.6f}" for x in w]))
        
#############################################################################
class Cost_Effective_Analysis:
    
    """ Perform cost-effective analysis and plot efficient frontier 
    Parameters:
      Attributes: ['Cost attribute name', 'Effectivess attribute name']
      Alternatives:
          dict as { alternative_name : (cost, effectiveness)}
                
     Methods:
       get_efficient_set():
           Returns a sub-dictionary of alternatives that are efficient
            
       plot_efficient_frontier(xlim, ylim, figsize=None, dpi=100): 
          Plot the efficient points and frontier 
            xlim = (xmin, xmax) values to plot
            ylim = (ymin, ymax) values to plot
            figsize = figsize to plot
            dpi = dpi to plot
    """
      
    def __init__(self, Attributes, Alternatives):
        
        self.attr = Attributes
        self.alt = Alternatives
        self.eff_set = None
        
        
    def get_efficient_set(self):
        """ Return the alternatives that are efficient in a dictionary """
 
        # Sort the alternatives in increasing cost attribute
        A = dict(sorted(self.alt.items(), key=lambda v: v[1][0]))
        
        # change the costs to negative for easy vector dominance analysis
        X = {k: np.array([-x1, x2]) for k, (x1, x2) in A.items()}
        
        # Assume all alternatives are efficient
        self.eff_set = A.copy()
        
        # Remove alternatives that are dominated 
        for k, x in X.items():
            for y in X.values():
                if all(y >= x) and any (y > x):
                    del self.eff_set[k]
                    break
        return(self.eff_set)


    def plot_efficient_frontier(self, xlim, ylim, figsize=None, dpi=100):
        """ Plot the efficient frontier with the given parameters """

        if self.eff_set is None:
            self.eff_set = self.get_efficient_set()
            
        # Plot the efficient frontier
        fig, ax = plt.subplots(figsize=figsize, dpi=dpi)
        
        # Plot all altenatives and label them
        ax.scatter([v[0] for v in self.alt.values()], 
                   [v[1] for v in self.alt.values()])
        for k, v in self.alt.items():
            ax.annotate(k, v, fontsize='large')
        
        # Plot the efficient frontier
        ax.plot([v[0] for v in self.eff_set.values()], 
                [v[1] for v in self.eff_set.values()],
                'r-', lw=2,)
        
        # Plot the 2 frontier horizontal and verical dashlines
        min_cost = list(self.eff_set.values())[0]
        max_cost = list(self.eff_set.values())[-1]
        ax.plot([min_cost[0], min_cost[0]], [min_cost[1], ylim[0] ], 'r--', lw=2)
        ax.plot([max_cost[0], xlim[1] ], [max_cost[1], max_cost[1]], 'r--', lw=2)
        
        ax.set_xlabel(self.attr[0], fontsize='x-large')
        ax.set_ylabel(self.attr[1], fontsize='x-large')
    
        ax.set_xlim(xlim)
        ax.set_ylim(ylim)
        
        ax.grid()
        plt.show()
