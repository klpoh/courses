# -*- coding: utf-8 -*-
# 10_Problem_10.4_Design_Selection_Problem_complete_cost_effectiveness_analysis.py
from DecisionAnalysisPy import AHP3Lmodel, Cost_Effective_Analysis
import numpy as np

""" Problem 10.4: System Selection Problem: 
    (a) Perform effectiveness analysis with AHP using AHP3Lmodel Class
    (b) Perform cost-effectiveness and efficient frontier analysis using
        Cost_Effective_Analysis Class """

# Effectiveness analysis using AHP model 
goal = "Best System"
main_criteria =["Human Productivity", "Economics", "Design", "Operations"]

# Upper triangle of criteria pairwise comparison matrix
main_cr_matrix = np.array([ 3, 3, 7,
                               2, 5,
                                  7 ])

alternatives = ["System A", "System B", "System C" ]
# Upper triangles of alternatives pairwise comp matrix wrt each criterion
alt_matrixs  = [ np.array([ 3,   5,   2 ]),
                 np.array([1/3, 1/2,  3 ]),
                 np.array([1/2, 1/7, 1/5]),
                 np.array([ 3,  1/5, 1/9])]

# Create an instance of a 3-Level AHP model
P104 = AHP3Lmodel(goal, main_criteria, main_cr_matrix,
                   alternatives, alt_matrixs)

P104.model()

sys_global_wt = P104.solve(method='Power')
# "Power", "Algebra", "RGM", "ColsNorm", "GenEigen"

# Performance sensitivity analysis
P104.sensit()

# Perform cost-effectiveness and efficient frontier analysis
Attributes = ['EUAC ($K)', 'Effectiveness']

EUAC = {'System A' : 100,
        'System B' :  80,
        'System C' : 110 }

EUAC_Eff = { system : (EUAC[system],sys_global_wt[system]) 
                for system in alternatives}

# Create a Cost-Effective Analysis Problem
SysSelect = Cost_Effective_Analysis(Attributes, EUAC_Eff)

# Get the efficient set 
eff_set = SysSelect.get_efficient_set()
print("\nEfficient system:")
for sys, vals in eff_set.items():
    print(f"  {sys}: {vals}")

# Plot the efficient frontier
SysSelect.plot_efficient_frontier((60, 120), (0, 0.6), dpi=100)
