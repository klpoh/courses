# -*- coding: utf-8 -*-
# 7.4.3_Fit_continuous_distributions_using_DistFit_continuous_Class.py
from DecisionAnalysisPy import DistFit_continuous
import pandas as pd

""" Fit continuous distributions using DistFit_continuous Class """
# Read the data from Excel file
data = pd.read_excel ("7.4.3_data.xlsx", sheet_name="data1", header=None)
data = data.values.flatten()

# List of distributions to fit
Dists = ['beta','expon','gamma','lognorm','logistic', 'laplace',
         'norm', 'rayleigh','triang','uniform','weibull_min']

# Use DisFit_continuous with the data
ex1 = DistFit_continuous(data)

# Visualise and describe the data
bins = 20
ex1.data_hist(bins=bins, dpi=100)
ex1.data_describe()

# Fit the distributuions the data
ex1.fit(Dists)

# Plot the top results
ex1.plot_pdf(5, bins=bins, dpi=100)
ex1.plot_cdf(5, dpi=100)

# See the fitted parameters and statistic for top 5 distributions
ex1.parameters(5)
