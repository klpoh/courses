# -*- coding: utf-8 -*-
# 7.4.4 Fit normal distribution to 2 percentiles (2026 08 28)
import numpy as np
from scipy.stats import norm
import matplotlib.pyplot as plt

# Percentile data
x = np.array([100, 352.27])
p = np.array([0.2, 0.9])

# Inverse standard normal CDF
z = norm.ppf(p)

# [1, z] matrix
Z = np.column_stack((np.ones(len(z)),z))

# Compute mu and sigma
mu, sigma = np.linalg.inv(Z) @ x
print(f"mu = {mu:.2f}")
print(f"sigma = {sigma:.2f}")

# Plot the CDF of the fitted normal distribution
xmin = norm.ppf(0.01, loc=mu, scale=sigma)
xmax = norm.ppf(0.99, loc=mu, scale=sigma)
xp = np.linspace(xmin, xmax, 500)
yp = norm.cdf(xp, mu, sigma)

fig, ax = plt.subplots()
ax.plot(xp, yp, lw=2, color='blue',
        label=fr"$N({mu:.2f}, {sigma:.2f}^2)$")
ax.plot(x, p,'ro', ms=7)
ax.set_xlim(xmin,xmax)
ax.set_ylim(0,1)
ax.set_ylabel("F(x)")
ax.legend()
ax.grid()
plt.show()
