# -*- coding: utf-8 -*-
# 9.2.x_Compute_AHP_matrix_using_AHPmatrix_Class.py
from DecisionAnalysisPy import AHPmatrix
import numpy as np

""" Compute AHP Matrix using different methods with AHPmatrix Class """

A3 = AHPmatrix([[1, 1/3, 1/2],
                [ 3,  1,  3 ],
                [ 2, 1/3, 1 ]])

# Pretty print the matrix
A3.pprint()

# Evaluate the matarix using 5 diferent methods
for method in ["Algebra", "Power", "RGM", "ColsNorm", "GenEigen"]:
    w, lam, ci, cr = A3.solve(method)
    print(f"method = {method}")
    np.set_printoptions(precision=6, suppress=True)
    print(f"  w={w}")
    print(f"  lambda_max={lam:.6f},  CI={ci:6f},  CR={cr:6f}")
    
# You can also get individual attrbutes after evaluating it
A3.solve(method='Power')
print(f"\nsize = {A3.size}")
print(f"w = {A3.w}")
print(f"lambda_max={A3.lambda_max:.6f}, CI={A3.CI:.6f}, CR={A3.CR:.6f}")

# We can also enter just the upper triangle
T3 = AHPmatrix([1/3, 1/2, 3], upper_triangle=True)
T3.pprint()
w, lam, ci, cr = T3.solve("Algebra")
print(f"  w={w}")
print(f"  lambda_max={lam:.6f},  CI={ci:6f},  CR={cr:6f}")
