# -*- coding: utf-8 -*-
# 7.4.3 Fitting a discrete distribution to data (2026 08 28)
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from scipy import stats
from scipy.optimize import minimize

# Read the data from Excel
df = pd.read_excel("7.4.3_example_data.xlsx", "dataset_2", header=None)
data = df.dropna().values.flatten()

# Visualize the date with a density histogram
fig, ax = plt.subplots()
bins = np.arange(min(data), max(data) + 2) - 0.5
ax.hist(data, bins=bins, density=True, rwidth=0.8, 
        color='skyblue', edgecolor='white', label='data')
ax.set_xlabel("Value")
ax.set_ylabel("Density")
ax.legend()
plt.show()

# Negative log-likelihood function to be minimized.
def neg_log_likelihood(params, dist, data):
    try:
        logpmf = dist.logpmf(data, *params)
        if np.any(np.isnan(logpmf)) or np.any(np.isinf(logpmf)):
            return np.inf
        return -np.sum(logpmf)
    except:
        return np.inf

# Fit a poisson distribution using MLE method
dist_name = 'poisson'
dist = getattr(stats, dist_name)
x0 = np.mean(data)
bounds = [(1e-6, None)]
solver = "L-BFGS-B"   # can also try "TNC"
sol = minimize(neg_log_likelihood, x0=x0, args=(dist, data),
                   method=solver, bounds=bounds)
if sol.success:
    obj_val = sol.fun
    params = sol.x
    print(f"Optimal obj value = {obj_val}")
    print(f"Fitted {dist_name} with parameters = {params}")
    # Compute AIC and BIC 
    loglik = -neg_log_likelihood(params, dist, data)
    k = len(params)
    AIC = 2*k - 2*loglik
    BIC = k*np.log(len(data)) - 2*loglik
    print(f"AIC = {AIC}")
    print(f"BIC = {BIC}")
else:
    print("MLE solver failed")
    exit()

# Visualise the fitted distribution
fig, ax = plt.subplots()
bins = np.arange(min(data), max(data) + 2) - 0.5
ax.hist(data, bins=bins, density=True, rwidth=0.8, color='skyblue', 
        edgecolor='white', label='data')
x = np.arange(min(data), max(data) + 1)
ax.stem(x, dist.pmf(x, *params), linefmt='r--', markerfmt='ro', 
         basefmt=" ", label=f"Fitted {dist_name}")
ax.set_xticks(x)
ax.set_xlabel("Value")
ax.set_ylabel("Probability")
ax.legend()
plt.show()

