# -*- coding: utf-8 -*-
# 7.4.3_Fit_Discrete_Distributions_to_Data.py
""" Fit Discrete Distributions to Data"""
import pandas as pd
import numpy as np
from scipy import stats
from scipy.optimize import minimize
import matplotlib.pyplot as plt

# Read the data from Excel file 
data = pd.read_excel ("7.4.3_data.xlsx", sheet_name="data2", header=None)
data = data.values.flatten()

# Plot data and show description
fig0, ax0 = plt.subplots(dpi=100)
values, counts = np.unique(data, return_counts=True)
ax0.bar(values, counts/counts.sum())
ax0.set_xticks(np.arange(values.min()-1, values.max()+2))
ax0.set_xlabel("Data value")
ax0.set_ylabel("Frequency density")
ax0.grid('dotted')
plt.show()

# Display description of the data
desc = stats.describe(data)
print("\nData Description:")
print(f"  size = {desc.nobs}")
print(f"  minmax = {desc.minmax}")
print(f"  mean = {desc.mean}")
print(f"  var = {desc.variance}")
print(f"  skewness = {desc.skewness}")
print(f"  kurtosis= {desc.kurtosis}")

#  'poisson'   # Poisson (mu)
#  'binom'     # Binomial (n, p)
#  'nbinom'    # Negative Binomial (n, p)
#  'betabinom' # Beta-Binomial (n, a, b)
#  'randint'   # randint (a, b)
#  'geom'      # geom(p)

# Distributions to fit and their parameter initial guess
Dists = { 'poisson'  : (10, ),
          'binom'    : (20, 0.5),
          'nbinom'   : (20, 0.5),
          'betabinom': (20, 10, 10),
          'randint'  : (3, 17),
          'geom'     : (0.5,)}

# Negative Log Likelihood function to minimize
def nLogLikelihood(params, dist, data):
    return -dist.logpmf(data, *params).sum() 

# Dict to keep successful results as we loop through the distributions
res = {}
for d, x0 in Dists.items():
    dist = getattr(stats, d)
    # Perform MLE Optimization
    sol = minimize(nLogLikelihood, x0=x0, args=(dist, data),
      method='Nelder-Mead',
      options={'maxiter':50000,'xatol':1E-8,'fatol':1E-8})
    # method='Powell',
    # options={'maxiter':10000,'xtol':1E-8,'ftol':1E-8})
    print(f"\nFitting Distribution {d}:")
    print(f"  MLE {sol.message}")
    params_fit = sol.x
    print(f"  Fitted Parameters = {params_fit}")
    # Keep the results if successful
    if sol.success:
        # Perform Kolmogorov-Smirnov test and store result
        Dv, pv = stats.kstest(data, d, args=params_fit)
        res[d] = {'Params' : params_fit,
                  'KS_D' : Dv,
                  'KS_pv': pv }

print(f"\nNumber of distributions fitted = {len(res)}")

# Sort the results by KS_stats
results = {dist: vals for dist, vals in 
        sorted(res.items(), key=lambda x: x[1]['KS_D']) }

# Plot PMF of fitted distributions and compare them with the data
num_to_plot = 5
num_to_plot = min(num_to_plot, len(results))

fig1, ax1 = plt.subplots(dpi=100)
ax1.bar(values, counts/counts.sum(), label='data', alpha=0.4)
ax1.set_ylabel("Probability")
x = np.arange(values.min()-1, values.max()+2)
for d in list(results.keys())[:num_to_plot]:
    dist = getattr(stats, d)
    params_fit = results[d]['Params']
    ax1.scatter(x, dist.pmf(x, *params_fit), label=d)
ax1.set_xticks(x)
ax1.legend()
ax1.grid(ls='--')
plt.show()

# Plot CDF of fitted distributions and compare them with the data
def step_func(x, y):
    ''' Compute coordinates to line plot x and y as step function '''
    xval = []
    for item in x:
        xval.append(item)
        xval.append(item)
    yval = [0]
    for item in y[:-1]:
        yval.append(item)
        yval.append(item)
    yval.append(1)
    return (xval, yval)
    
fig2, ax2 = plt.subplots(dpi=100)
cdf_data = np.cumsum(counts/counts.sum())
ax2.plot(*step_func(values, cdf_data), label='data' )
ax2.scatter(values , cdf_data, label=None)
x = np.arange(values.min()-1, values.max()+2)
for d in list(results.keys())[:num_to_plot]:
    dist = getattr(stats, d)
    params_fit = results[d]['Params']
    ax2.scatter(x, dist.cdf(x, *params_fit), label=d)
ax2.set_xticks(x)
ax2.set_yticks(np.linspace(0,1,11))
ax2.set_ylabel('CDF')
ax2.legend()
ax2.grid(ls='--')
plt.show()

# Show the top fitted parameters
num_to_show = 10
num_to_show = min(num_to_show, len(results))
print(f"\nThe top {num_to_show} distributions:")
  
for i, (d, vals) in enumerate(list(results.items())[:num_to_show]):
    dist = getattr(stats, d)
    params = vals['Params']
    print(f"\nDistribution {i+1}: {d}")
    print(f"  Params = {vals['Params']}")
    print(f"  KS_stats = {vals['KS_D']}")
    pv = vals['KS_pv']
    print(f"  p-value = {pv}", end=" ")
    if pv < 0.05:
        print(" < 0.05")
    else:
        print("")
    print(f"  mean = {dist(*params).mean()}")
    print(f"  var = {dist(*params).var()}")
    print(f"  sd = {dist(*params).std()}")
