# -*- coding: utf-8 -*-
# 6.2.4_Selling_Price_indep_Wealth_under_Delta_Property_RiskDeal_Class.py
import numpy as np
from DecisionAnalysisPy import RiskDeal

""" Demostrate Selling Price independent of Wealth under Delta Property """
    
# Create the deal
Deal = RiskDeal(p=[0.5, 0.5], x=[100, 0], states=['up','down'], 
                name='Coin_game_0_100')

# Define the wealth utilty function and its inverse
uw = lambda w : 1 - 2**(-w/50)
uw_inv = lambda y : -50*np.log(1-y)/np.log(2)

# Compute PISP at different initial wealth
for w0 in [0, 100, 500, 1000]:
    print(f"\nInitial wealth = {w0}")
                   
    # Compute PISP with inverse wealth utility function provided
    s1 = Deal.PISP(w0, uw, uw_inv)
    print(f"Selling price  = {s1:.6f}")
        
    # Compute PISP without inverse wealth utility function
    s2 = Deal.PISP(w0, uw)
    print(f"Selling price  = {s2:.6f}")
    
print("\nNotice that Selling Price is independent of wealth")
