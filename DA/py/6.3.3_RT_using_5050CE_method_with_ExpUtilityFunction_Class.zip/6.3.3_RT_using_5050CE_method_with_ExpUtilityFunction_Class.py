# -*- coding: utf-8 -*-
# 6.3.3_RT_using_5050CE_method_with_ExpUtilityFunction_Class.py
from DecisionAnalysisPy import ExpUtilityFunction
import numpy as np
from scipy.optimize import root

""" Find Risk Tolerance using 50-50 CE Method with ExpUtilityFunction Class """

print("\nRisk averse case:")
L, H, X05 = 0, 100, 34

# First, let's do it the hard way by showing off your solver skills.
eq=lambda r: (1.0-np.exp(-(X05-L)/r))/(1.0-np.exp(-(H-L)/r))-0.5
sol = root(eq, x0=50)
if not sol.success:print("Warning:", sol.message)
RT = sol.x[0]
print(f"Risk Tolerence = {RT}")

# Next, do it the easy way using ExpUtilityFunction.find_RT_5050CE method
# Create an instance of the function and then find RT using 50-50 CE method
f1 = ExpUtilityFunction()
rt1 = f1.find_RT_5050CE(L, H, X05, guess=50)
f1.plot()

print(f"  Risk tolerance = {rt1}")
print(f"  Utility function is {f1.fun_str()}")
print(f"  Parameters = {f1.params()}")
print( "  Check key utility values:")
print(f"    u({L}) = {f1.u(L)}")
print(f"    u({X05}) = {f1.u(X05)}")
print(f"    u({H}) = {f1.u(H)}")
   
print("\nRisk seeking case:")
L, H, X05 = 0, 100, 65

# First, let's do it the hard way by showing off your solver skills.
eq=lambda r: (1.0-np.exp(-(X05-L)/r))/(1.0-np.exp(-(H-L)/r))-0.5
sol = root(eq, x0=-50)
if not sol.success:print("Warning:", sol.message)
print(f"Risk Tolerence = {sol.x[0]}")

# Next, do it the easy way using ExpUtilityFunction.find_RT_5050CE method
# Create an instance of the function and then find RT using 50-50 CE method
f2 = ExpUtilityFunction()
rt2 = f2.find_RT_5050CE(L, H, X05, guess=-50)  
f2.plot()

print(f"  Risk tolerance = {rt2}")
print(f"  Utility function is {f2.fun_str()}")
print(f"  Parameters = {f2.params()}")
print( "  Check key utility values:")
print(f"    u({L}) = {f2.u(L)}")
print(f"    u({X05}) = {f2.u(X05)}")
print(f"    u({H}) = {f2.u(H)}")
