# -*- coding: utf-8 -*-
# 4.3_PartyProblem_plot_risk_profiles_using_RiskDeal_Class.py
from DecisionAnalysisPy import RiskDeal
from DecisionAnalysisPy import plot_risk_profiles

""" Plotting Risk Profiles for the Party Problem """
   
# Create the 3 risky deals
ID = RiskDeal(p=[0.4, 0.6], 
              x=[40,   50], 
              states=['sunny','rainy'],
              name='Indoors')

PR = RiskDeal(p=[0.4, 0.6], 
              x=[90,   20], 
              states=['sunny','rainy'],
              name='Porch')

OD = RiskDeal(p=[0.4, 0.6], 
              x=[100,   0], 
              states=['sunny','rainy'],
              name='Outdoors')

# Parameters for plotting risk profiles
plot_range=(-10, 110, 10)
npoints = 1000

# Plot the 3 risk profiles individually
for deal in [ID, PR, OD]:
    print(f"\nRisk Profiles for {deal.name}:")
    deal.plot_CDF(plot_range, npoints, dpi=100)
    deal.plot_EPF(plot_range, npoints, dpi=100)
    

# Plot all the risk profiles together for comparison
print("\nRisk Profiles for the Party Problem")
plot_risk_profiles([ID, PR, OD], plot_range, 
                   num=npoints, CDF=True, EPF=True, dpi=100)


    