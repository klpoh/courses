# -*- coding: utf-8 -*-
# 6.1.2_Selling_Price_under_General_Risk_Preference_using_RiskDeal_Class.py
from DecisionAnalysisPy import RiskDeal
import numpy as np

""" Compute Personal Indifferent Selling Price (PISP) under 
    General Risk Preference usikng RiskDeal Class """

# Create the risky deal
D61 = RiskDeal(p=[0.7, 0.3], x=[10, -5], states=['Win','Lose'], 
                   name='Example_6.1')

# Define the wealth utility function
def uw(w):
    if w >= 0:
        return np.sqrt(w)
    else:
        return -np.sqrt(-w)

# Define the wealth utility inverese function
def uw_inv(y):
    if y >= 0:
        return np.square(y)
    else:
        return -np.square(y)

# Compute the PISP at different w0 with and without invese function
for w0 in [10, 100, 1000, 10000]:
    print(f"\nInitial wealth = {w0}")
           
    # Compute PISP with inverse wealth utility function provided
    s1 = D61.PISP(w0, uw, uw_inv)
    print(f"  Selling price  = {s1:.6f}")
        
    # Compute PISP without inverse wealth utility function
    s2 = D61.PISP(w0, uw)
    print(f"  Selling price  = {s2:.6f}")
    
    # Risk preimum is EV - PISP
    pi = D61.EV - s1
    print(f"  Risk Premium   ={pi:.6f}")

