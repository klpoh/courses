# -*- coding: utf-8 -*-
# 8.4.2_LIM_one_way_range_sensitivty_analysis.py
from DecisionAnalysisPy import OneWayRangeSensit
import numpy_financial as npf

""" LIM Marketing and Service Support Case Study (2025 01 26) """

# Uncertain variable names and their [low, base, high] values
v_data = {   'nsold'   : [  25,   30,   50],
             'c_alpha' : [   9,   10,   11],
             'alpha'   : [0.13, 0.15, 0.17],
             'c_beta'  : [ 7.8,  8.0,  8.1],
             'beta'    : [0.68, 0.70, 0.72],
             'trg_c'   : [   4,    8,   10]}    

# Fixed parameters name and value
f_data = {'marr' : 0.03 }

# Objective functions, one for each alternative. 
# Arguments must be in the same order as above
def npv_1(nsold, c_alpha, alpha, c_beta, beta, trg_c, marr):
    return nsold*(30-(-npf.pv(marr, 5, alpha*c_alpha + beta*c_beta)))*1000
def npv_2(nsold, c_alpha, alpha, c_beta, beta, trg_c, marr):
    return nsold*(30-(-npf.pv(marr, 5, alpha*c_alpha)) -10 - trg_c)*1000
def npv_3(nsold, c_alpha, alpha, c_beta, beta, trg_c, marr):
    return (nsold*30 - max(750, 23*nsold))*1000
def npv_4(nsold, c_alpha, alpha, c_beta, beta, trg_c, marr):
    return -25.0*1000

# The alternative names and their objective functions 
obj_fns = { "Present Arrangement" : npv_1,
            "Train user"          : npv_2,
            "Contract IPX"        : npv_3,
            "Withdraw from market": npv_4 }

# Label for the objective function outputs
obj_label = "NPV($)"

# Perform one-way range sensitivity analysis
Lim = OneWayRangeSensit(v_data, f_data, obj_fns, obj_label)
# Show variable and objective base values
Lim.base_values()
# Show sensitivity range tables
Lim.sensit_table()
# Show individual tornado diagrams
Lim.tornados(annotate=True)
# Show combined tornados
Lim.combined_tornados((-200000, 400000), annotate=False)
# Show individual spider diagrams
Lim.spiders()

