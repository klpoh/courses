# -*- coding: utf-8 -*-
# Cost effectiveness analysis: Center Relocation Problem (2026 04 21)
from DApy.mcdm import AHPNode, AHPModel
import numpy as np

# Use AHP to evaluate the effectivess without consideration of costs.
goal_pcm = np.array([
    [ 1,   2,  2, 3],
    [1/2,  1,  1, 2],
    [1/2,  1,  1, 1],
    [1/3, 1/2, 1, 1]   
])

goal = AHPNode("Goal", pcm=goal_pcm)

C1 = AHPNode('Good conditions for staff')
C2 = AHPNode('Easy access for clients')
C3 = AHPNode('Suitability of space')
C4 = AHPNode('Administrative convenience')

goal.children = [C1,C2,C3,C4]

# Subcriteria for C1 'Good conditions for staff'
C11 = AHPNode('Office size')
C12 = AHPNode('Staff commuting')
C13 = AHPNode('Office attractiveness')
C14 = AHPNode('Office privacy')
C15 = AHPNode('Staff parking')
C1.children = [C11,C12,C13,C14,C15]
C1.pcm = np.array([
    [ 1,   2,  3, 3, 3],
    [1/2,  1,  2, 2, 2],
    [1/3, 1/2, 1, 1, 1],
    [1/3, 1/2, 1, 1, 1],
    [1/3, 1/2, 1, 1, 1]
 ])

# Subcriteria for C2 'Easy access for clients'
C21 = AHPNode("Close to client's home")
C22 = AHPNode('Access to public transport')

C2.children = [C21,C22]
C2.pcm = np.array([
    [1, 1],
    [1, 1]
 ])

# Subcriteria for C3 'Suitability of space'
C31 = AHPNode('Counceling rooms')
C32 = AHPNode('Conference rooms')
C33 = AHPNode('Reception area')
C3.children = [C31,C32,C33]
C3.pcm = np.array([
  [ 1,   2,  2],
  [1/2,  1,	 2],
  [1/2, 1/2, 1]
])

# Subcriteria for C4 'Administrative convenience'
C41 = AHPNode('Adequacy of space')
C42 = AHPNode('Flexibilty of space')

C4.children = [C41,C42]
C4.pcm = np.array([
    [ 1,  2],
    [1/2, 1]
 ])

# The alternatives and their pairwise comparison matrices.
alternatives = ['Site 1','Site 2','Site 3','Site 4','Site 5','Site 6']

# Alternative PCMs
C11.alt_pcm = np.array([
    [ 1,   2,  9,  2,  9,  2 ],
    [1/2,  1,  5,  1,  5,  1 ],
    [1/9, 1/5, 1, 1/5, 1, 1/4],
    [1/2,  1,  5,  1,  5,  1 ],
    [1/9, 1/5, 1, 1/5, 1, 1/4],  
    [1/2,  1,  4,  1,  4,  1 ]
])

C12.alt_pcm = np.array([
    [1,	   2,  1/2,  5,  9,  2 ],
    [1/2,  1,  1/3,  3,  6,  1 ],
    [2,	   3,	1,	 9,  9,  3 ],
    [1/5, 1/3, 1/9,  1,  2, 1/3],
    [1/9, 1/6, 1/9, 1/2, 1, 1/6],
    [1/2,  1,  1/3,  3,  6,  1 ]
])

C13.alt_pcm = np.array([
    [ 1,  1/3, 1/2, 3, 1/3, 1/3],  
    [ 3,   1,   1,  8,  1,   1 ],
    [ 2,   1,   1,  1,  1,   1 ],
    [1/3, 1/8,  1,  1, 1/9, 1/8],  
    [ 3,   1,   1,  9,  1,   1 ],
    [ 3,   1,   1,  8,  1,   1 ]
])
    
C14.alt_pcm = np.array([
    [ 1,   3,	2,	9,	3,   2 ],
    [1/3,  1,   1,	3,	1,  1/2],  
    [1/2,  1,	1,	4,	1,	 1 ],
    [1/9, 1/3, 1/4, 1, 1/3, 1/2],
    [1/3,  1,	1,	3,	1,	 1 ],
    [1/2,  2,	1,	2,	1,	 1 ]
])

C15.alt_pcm = np.array([
    [1, 1/6, 1/3, 1, 1/9, 1/5],
    [6,	 1,	  2,  6, 1/2,  1 ],
    [3,	1/2,  1,  3, 1/3, 1/2],
    [1,	1/6, 1/3, 1, 1/9, 1/5],
    [9,	 2,   3,  9,  1,   2 ],
    [5,	 1,	  2,  5, 1/2,  1 ]
])

C21.alt_pcm = np.array([
    [ 1,   1,	3, 1/2, 1/3,  1 ],
    [ 1,   1,	3, 1/2, 1/3,  1 ],
    [1/3, 1/3,  1, 1/5, 1/9, 1/3], 
    [ 2,   2,	5,	1,	1/2,  2 ],
    [ 3,   3,	9,	2,   1,	  3 ],
    [ 1,   1,	3, 1/2, 1/3,  1 ]
])
    
C22.alt_pcm = np.array([
    [ 1,   1,   1,   1,	 7,	 1 ],
    [ 1,   1,   1,   1,	 7,  1 ],
    [ 1,   1,   1,	 2,	 9,  1 ],
    [ 1,   1,  1/2,  1,  5,	 1 ],
    [1/7, 1/7, 1/9, 1/5, 1, 1/7],
    [ 1,   1,	1,	 1,	 7,	 1 ]
])

C31.alt_pcm = np.array([
    [ 1,  1/8, 2, 1/5, 1/9, 1/5],
    [ 8,   1,  9,  2,	1,	 2 ],
    [1/2, 1/9, 1, 1/9, 1/9, 1/9],
    [ 5,  1/2, 9,  1,  1/2,  1 ],
    [ 9,   1,  9,  2,	1,	 2 ],
    [ 5,  1/2, 9,  1,  1/2,  1 ],
])
    
C32.alt_pcm = np.array([
    [ 1,	1,	6,	6, 1/2,  2 ],
    [ 1,	1,	5,	5, 1/2,  2 ],
    [1/6, 1/5,  1,	1, 1/9, 1/3],
    [1/6, 1/5, 	1,	1, 1/9, 1/3], 
    [ 2,   2,	9,	9,	1,	 3 ],
    [1/2, 1/2,  3,	3, 1/3,  1 ],
])
    
C33.alt_pcm = np.array([
    [ 1,   1,	1,	5,	2,	 2 ],
    [ 1,   1,	1,	4, 1/2,	 1 ],
    [ 1,   1,	1,	5, 1/2,  2 ],
    [1/5, 1/4, 1/5,	1, 1/9, 1/3],
    [1/2,  2,	2,	9,	1,	 3 ],
    [1/2,  1,  1/2,	3, 1/3,  1 ]
])

C41.alt_pcm = np.array([
    [ 1, 1/7, 1/5, 1/9, 1/5, 1/6],
    [ 7,  1,   1,	1,   1,	  1 ],
    [ 5,  1,   1,  1/2,  1,   1 ],
    [ 9,  1,   2,   1,   2,   2 ],
    [ 5,  1,   1,  1/2,  1,   1 ],
    [ 6,  1,   1,  1/2,  1,	  1 ],
])       

C42.alt_pcm = np.array([
    [ 1, 1/4, 1/5, 1/9, 1, 1/4],
    [ 4,  1,   1,   2,  4,  1 ],
    [ 5,  1,   1,  1/2, 5,  1 ],
    [ 9, 1/2,  2,   1,	9,  1 ],
    [ 1, 1/4, 1/5, 1/9, 1, 1/4],
    [ 4,  1,   1,   1,  4,  1 ]
]) 

# Build the AHP model solve it
eff_model = AHPModel(goal, alternatives)
eff_scores = eff_model.solve()

# Plot the hierarchy.
eff_model.plot_hierarchy(title='Counselling Center Relocation Problem',
                    figsize=(16,8))


# Perform Cost-Effectivess Analysis
from DApy.mcdm import ParetoAnalysis
import matplotlib.pyplot as plt

# Cost data
costs = {
 'Site 1': 48.0,
 'Site 2': 53.3,
 'Site 3': 54.6,
 'Site 4': 60.6,
 'Site 5': 67.8,
 'Site 6': 47.5
 }

# Built {key: (cost, effectiveness)} dict
cost_eff_data = {k: (costs.get(k), eff_scores.get(k)) 
                     for k in eff_scores.keys() | costs.keys()}
                
labels = ['EUAC ($K)', 'Effectiveness']

cost_eff_model = ParetoAnalysis(cost_eff_data, ['min','max'], 
                    labels=['EUAC($)','Effectivess'])

eff_sites = cost_eff_model.efficient_points()

# Sort eff solutions by increasing cost
sorted_sites = dict(sorted(eff_sites.items(), key=lambda item: item[1][0]))
for k, v in sorted_sites.items():
    print(f"{k:3}: {', '.join([f'{x:6.4f}' for x in v])}")

# Plot the efficient frointier
ax = cost_eff_model.plot_frontier()
# Customise the axes any way you like
ax.set_title("Efficient frontier for Counselling Center Relocation")
ax.set_xlim(40,80)
ax.set_ylim(0.1,0.2)
ax.grid()
plt.show()
