# -*- coding: utf-8 -*-
# LIM Problem One-Way Range Sensitivity Analysis (2026 04 21)
from DApy.sensit import OneWaySensitivity
import pandas as pd
import numpy_financial as npf

data = {'nsold'   : [  25,   30,   50],
        'c_alpha' : [   9,   10,   11],
        'alpha'   : [0.13, 0.15, 0.17],
        'c_beta'  : [ 7.8,  8.0,  8.1],
        'beta'    : [0.68, 0.70, 0.72],
        'trg_c'   : [   4,    8,   10]}    
marr = 0.03 

scenarios = ['Present arrangement',
             'Train user',
             'Contract IPX',
             'Withdraw from market']

def npv_1(nsold, c_alpha, alpha, c_beta, beta, trg_c):
    return nsold*(30-(-npf.pv(marr, 5, alpha*c_alpha + beta*c_beta)))*1000
def npv_2(nsold, c_alpha, alpha, c_beta, beta, trg_c):
    return nsold*(30-(-npf.pv(marr, 5, alpha*c_alpha)) -10 - trg_c)*1000
def npv_3(nsold, c_alpha, alpha, c_beta, beta, trg_c):
    return (nsold*30 - max(750, 23*nsold))*1000
def npv_4(nsold, c_alpha, alpha, c_beta, beta, trg_c):
    return -25.0*1000

obj_func = [npv_1, npv_2, npv_3, npv_4]
colors = ['blue','orange','green','black']
value_label = "NPV ($)"

# Plot individual tornados
dfs = []
pd.set_option('display.max_columns', None)
for i, name in enumerate(scenarios):
    m = OneWaySensitivity(obj_func[i], data, label=name)
    df = m.sensit()
    m.plot_tornado(colors[i], obj_label=value_label)
    print(f"\nScenario: {name}")
    print(f"Base objective value = {m.base_result}")
    print(df)
    dfs.append(df)

# Plot combined tornados
OneWaySensitivity.combine_tornadoes(dfs, labels=scenarios, 
    colors=colors, obj_label=value_label)
