# -*- coding: utf-8 -*-
# Exxoff Problem Stochastic Dominance Analysis (2026 04 21)
from  DApy.risk import DiscreteDeal

Invest = DiscreteDeal (
    name='Invest_in_R&D',
    x=[-4.3464, 16.4602, 21.7300, 46.3809, 53.9320, 66.2542, 86.1339 ],
    p=[0.25000,  0.4444,  0.0278,  0.0278,  0.1111,  0.1111,  0.0278 ],
    )

No_invest = DiscreteDeal(
    name="Don't_invest",
    x=[0], 
    p=[1]
    )

xlim= (-20, 100)
DiscreteDeal.first_order_SD(No_invest, Invest, xlim=xlim,
                            plot_epf=True, plot_cdf=False)

DiscreteDeal.second_order_SD(No_invest, Invest, xlim=xlim, plot=True)
