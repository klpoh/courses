# -*- coding: utf-8 -*-
# LIM Problem Stochastic Dominance Analysis (2026 04 21)
from  DApy.risk import DiscreteDeal

Train = DiscreteDeal(
    name = 'Train_User',
    x=[ 120.264,   150.786,  171.025, 187.633, 214.429, 
        230.102,   266.828,  288.499, 358.999 ],
    p=[ 0.095070, 0.137191, 0.191698, 0.042003, 0.276629,
        0.059869, 0.084695, 0.086394, 0.026451 ],
    )

IPX = DiscreteDeal(
    name = 'Use_IPX',
    x = [  115.809,  253.293,  315.189 ],
    p = [ 0.346637, 0.500215, 0.153149 ],
    )

xlim= (50, 400)
DiscreteDeal.first_order_SD(Train, IPX, xlim=xlim, 
                            plot_epf=True, plot_cdf=False)

DiscreteDeal.second_order_SD(Train, IPX, xlim=xlim, plot=True)
