# -*- coding: utf-8 -*-
# Exoff Problem One-Way Range Sensitviity Analysis (2026 04 21)
from DApy.sensit import OneWaySensitivity
import pandas as pd
import numpy_financial as npf

data = {'c' : [0.65, 0.88, 1.11],
        'p' : [0.62, 0.95, 1.28],
        'f' : [0.42, 0.48, 0.54],
        'L' : [ 14,   20,   26 ] }    
marr = 0.1
scenarios = ['Invest R&D, Market',
             "Invest R&D, Don't Market",
             "Don't Invest"]
  
def npv_1(c, p, f, L):
    return -npf.pv(marr, 5, 0, -7-npf.pv(marr, L, 50*f*(1-p*c)))*1000
def npv_2(c, p, f, L):
    return -npf.pv(marr, 5, 0, -7)*1000
def npv_3(c, p, f, L):
    return 0

obj_func = [npv_1, npv_2, npv_3]
colors = ['blue','orange','green']
value_label = "NPV ($)"

# Plot individual tornados
table_dfs = []
pd.set_option('display.max_columns', None)
for i, name in enumerate(scenarios):
    m = OneWaySensitivity(obj_func[i], data, label=name)
    df = m.sensit()
    print(f"\nScenario: {name}")
    print(f"Base objective value = {m.base_result}")
    print(df)
    m.plot_tornado(colors[i], obj_label=value_label)
    table_dfs.append(df)

# Plot combined tornados
OneWaySensitivity.combine_tornadoes(table_dfs, labels=scenarios, 
    colors=colors, obj_label=value_label)
