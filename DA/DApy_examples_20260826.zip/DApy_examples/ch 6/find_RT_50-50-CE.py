# -*- coding: utf-8 -*-
# Finding Risk Tolerance using 50-50 CE method (2026 04 21)
from  DApy.cara import ExponUtilityFunction

# Risk averse case
L, H, CE50 = 0, 100, 34

# CE50 < (H+L)/2 -> Risk averse -> RT > 0
U1 = ExponUtilityFunction()

# Provide a bracket 
rho = U1.RT_from_CE50(L, H, CE50, bracket=[1, 100])
print(f"risk tolerance = {rho:.4f}")

# Provide a single initial guess
rho = U1.RT_from_CE50(L, H, CE50, x0=50)
print(f"risk tolerance = {rho:.4f}")

# Check the CE with u(x)=0.5
CE = U1.CE(L, H, 0.5)
print(f"CE(u=0.5)= {CE}")

U1.plot(L, H)

# Risk seeking case
L, H, CE50 = 0, 100, 65

# CE50 > (H+L)/2 -> Risk seeking -> RT < 0
U2 = ExponUtilityFunction()

# Provide a bracket 
rho = U2.RT_from_CE50(L, H, CE50, bracket=[-100, -1])
print(f"risk tolerance = {rho:.4f}")

# Provide a single initial guess
rho = U2.RT_from_CE50(L, H, CE50, x0=-50)
print(f"risk tolerance = {rho:.4f}")

# Check the CE with u(x)=0.5
CE = U2.CE(L, H, 0.5)
print(f"CE(u=0.5)= {CE}")

U2.plot(L, H)

