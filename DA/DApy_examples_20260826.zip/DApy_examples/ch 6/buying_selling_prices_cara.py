# -*- coding: utf-8 -*-
# Demostrate Buying = Selling Prices under CARA (2026 04 21)
from  DApy.risk import DiscreteDeal
import numpy as np

def wuf(w):
    return 1 - 2**(-w/50)

Coin100 = DiscreteDeal(
    name = 'Coin Toss 0-100',
    x = np.array([0, 100]),
    p = np.array([0.5, 0.5])
    )

results = {}
for w0 in [0, 10, 100, 1000]:
    results[w0] = [Coin100.PISP(w0, wuf), Coin100.PIBP(w0, wuf)]

for k, v in results.items():
    print(f"w0 = {k:4}: PISP = {v[0]:.6f}, PSBP = {v[1]:.6f}")
