# -*- coding: utf-8 -*-
# Buying and Selling prices under general risk preference (2026 04 21)
from  DApy.risk import DiscreteDeal
import numpy as np

deal = DiscreteDeal( 
    x = np.array([ 10,  -5]),
    p = np.array([0.7, 0.3])
    )

wealth_uf = lambda w: np.sqrt(w) if w>=0 else -np.sqrt(-w)

# Personal Indifference Selling Prices
for w0 in [10, 100, 1000]:
    s = deal.PISP(w0, wealth_uf)
    print(f"w0 = {w0}: PISP = {s:.5f}\n")


# Personal Indifference Buying Prices
for w0 in [10, 100, 1000]:
    b = deal.PIBP(w0, wealth_uf)
    print(f"w0 = {w0}: PIBP = {b:.5f}\n")
