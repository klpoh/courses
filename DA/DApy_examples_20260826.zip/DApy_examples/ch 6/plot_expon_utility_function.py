# -*- coding: utf-8 -*-
# Plot Exponential Utility Functions (2026 04 21) 
from  DApy.cara import ExponUtilityFunction

# Plot single exponential utility function
U1 = ExponUtilityFunction(20)
U1.plot(L=0, H=100)

# Plot a risk seeking utility function and change the default title
U2 = ExponUtilityFunction(-30)
ax=U2.plot(L=0, H=100)
ax.set_title(f"A risk seeking function with RT = {U2.RT}")

# Plot many utility functions with the same axes and customise final plot.
import matplotlib.pyplot as plt
fig, ax = plt.subplots()
U3 = ExponUtilityFunction()
for r in [10, 20, 30, 40]:
    U3.RT = r
    ax = U3.plot(L=0, H=100, ax=ax)
ax.set_title("Risk Averse Exponential Utility Functions")
ax.legend()
plt.show()

fig, ax = plt.subplots()
U4 = ExponUtilityFunction()
for r in [-10, -20, -30, -40]:
    U4.RT = r
    ax = U4.plot(L=0, H=100, ax=ax)
ax.set_title("Risk Seeking Exponential Utility Functions")
ax.legend()
plt.show()

# Plot in anyway you like after getting the callable function.
import numpy as np
L, H = 0, 100
U5 = ExponUtilityFunction()
fig, ax = plt.subplots(figsize=(8,6.4))
x = np.linspace(L, H, 201)
for r in [5, 10, 20, 30, 40, 50]:
    U5.RT = r
    fun = U5.get_function(L=L, H=H)
    ax.plot(x, fun(x), label=r)
    ax.text(20, fun(20), r, ha='right')
ax.set_title("Exponetial Utility Functions")
ax.set_xticks(np.linspace(0,100,11))
ax.set_yticks(np.linspace(0,1,11))
ax.grid()
ax.legend()
plt.show()
