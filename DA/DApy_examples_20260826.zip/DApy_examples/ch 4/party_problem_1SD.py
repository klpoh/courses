# -*- coding: utf-8 -*-
# Party Problem first-order stochastic dominance analysis (2026 04 21)
from  DApy.risk import DiscreteDeal
import numpy as np

# Create the 3 discrete deals
Outdoors = DiscreteDeal(
    name= 'Outdoors',
    x= np.array( [0, 100]),
    p= np.array([0.6, 0.4])
    )
Porch = DiscreteDeal(
    name='Porch',
    x= np.array( [20, 90]),
    p= np.array([0.6, 0.4])
    )
Indoors = DiscreteDeal(
    name= 'Indoors',
    x= np.array([40, 50]),
    p= np.array([0.4, 0.6])
    )
xlim=(-10,110)

# We can plot the individual risk profiles here
# See previous example

## First-Order Stochastic Dominance
# Check if Indoors 1st order dominates Porch
DiscreteDeal.first_order_SD(Indoors, Porch, xlim=xlim)

# Check if Indoors 1st order dominates Outdoors
DiscreteDeal.first_order_SD(Indoors, Outdoors, xlim=xlim)

# Check if Indoors 1st order dominates Outdoors
DiscreteDeal.first_order_SD(Porch, Outdoors, xlim=xlim)
