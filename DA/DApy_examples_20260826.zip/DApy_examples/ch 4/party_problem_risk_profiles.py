# -*- coding: utf-8 -*-
# Party Problem - Risk Profiles plotting (2026 04 21)
from  DApy.risk import DiscreteDeal
import numpy as np

# Create the 3 deals
Outdoors = DiscreteDeal(
    name= 'Outdoors',
    x= np.array( [0, 100]),
    p= np.array([0.6, 0.4])
    )
Porch = DiscreteDeal(
    name='Porch',
    x= np.array( [20, 90]),
    p= np.array([0.6, 0.4])
    )
Indoors = DiscreteDeal(
    name= 'Indoors',
    x= np.array([40, 50]),
    p= np.array([0.4, 0.6])
    )

# Plot individual risk profiles in all format for each deal
xlim=(-20,120)  # x limits for plotting risk profiles
for deal in [Outdoors, Porch, Indoors]:
    deal.plot_pmf(xlim=xlim)
    deal.plot_cdf(xlim=xlim)
    deal.plot_epf(xlim=xlim)

# Compare the EPFs and customize the plot.
import matplotlib.pyplot as plt

fig, ax = plt.subplots()
for deal in [Outdoors, Porch, Indoors]:
    ax = deal.plot_epf(xlim=xlim, ax=ax)
ax.set_title('Risk Profiles for Party Problem')
ax.set_yticks(np.arange(0, 1.2, 0.1))
ax.set_xticks(np.arange(-20, 120, 10))
ax.legend()
plt.show()
