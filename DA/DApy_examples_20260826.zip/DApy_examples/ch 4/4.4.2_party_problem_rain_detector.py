# -*- coding: utf-8 -*-
# 4.4.2 Party Problem Rain Detector
from DApy.probability import ProbTree
import matplotlib.pyplot as plt

Weather = ['Sunny','Rainy']
prior = [0.4, 0.6]

Reading = ["'Sunny'","'Rainy'"]
true_sunny_rate = 0.80
true_rainy_rate = 0.80
det_performance = [[true_sunny_rate, 1-true_sunny_rate],
                   [1-true_rainy_rate, true_rainy_rate]]

# Create a probability tree and check CPTs.
Detector_tree = ProbTree(Weather, Reading, 
                         prior, det_performance,
                         'Weather','Dectector Reading')
Detector_tree.CPT(prob_decimals=2)

# Draw the probability tree.

ax1 = Detector_tree.draw_prob_tree(prob_decimals=2)
ax1.set_title("Detector reading given Weather",
              fontname='Times New Roman',
              fontsize='x-large', fontweight='bold')
plt.show()

# Flip the tree
Predict_tree = Detector_tree.flip_tree()
Predict_tree.CPT(prob_decimals=6)

# Draw the flipped tree
ax2=Predict_tree.draw_prob_tree(prob_decimals=6)
ax2.set_title("Weather given Detector reading",
              fontname='Times New Roman',
              fontsize='x-large', fontweight='bold')
plt.show()
