# -*- coding: utf-8 -*-
# 4.4.1 Party Problem Weather Clairvoyance
from DApy.probability import ProbTree
import matplotlib.pyplot as plt

Weather = ['Sunny','Rainy']
prior = [0.4, 0.6]

Clairvoyant = ['Says Sunny','Says Rainy']
true_sunny_rate = 1
true_rainy_rate = 1
clairvoyant_prob = [[true_sunny_rate, 1-true_sunny_rate],
                   [1-true_rainy_rate, true_rainy_rate]]

Clairvoyant_tree = ProbTree(
                    Weather, Clairvoyant, 
                    prior, clairvoyant_prob,
                    'Weather','Clairvoyance')
Clairvoyant_tree.CPT(prob_decimals=4)
ax1 = Clairvoyant_tree.draw_prob_tree(prob_decimals=2)
ax1.set_title("Clairvoyance given Weather",
              fontname='Times New Roman',
              fontsize='x-large', fontweight='bold')
plt.show()

Predict_tree = Clairvoyant_tree.flip_tree()
Predict_tree.CPT(prob_decimals=6)
ax2=Predict_tree.draw_prob_tree(prob_decimals=6)
ax2.set_title("Weather given Clairvoyance",
              fontname='Times New Roman',
              fontsize='x-large', fontweight='bold')
plt.show()
