# -*- coding: utf-8 -*-
# Employee rating example with data from Excel (2026 04 21)
from DApy.mcdm import AHPRating
import numpy as np
import pandas as pd

criteria = ['Quality','Education','Experience','Dependability']

criteria_pcm = np.array([
    [1,   5,   7,  3 ], 
    [1/5, 1,   3, 1/3],
    [1/7, 1/3, 1, 1/5], 
    [1/3,  3,  5,  1 ]])


rating_scales = {
    'Quality':   ['Excellent', 'Good', 'Meet Requirements', 'Need Improvements', 'Unsatisfactory'],
    'Education': ['Postgraduate', 'Bachelor', 'Diploma','Below Dip'],
    'Experience':['>10 years', '5-10 years', '3-5 years', '1-3 years', '<1 year'],
    'Dependability': ['Exceptional', 'Good', 'Satisfactory', 'Poor'] 
    }
  
# Set up Rating System
rating_pcms = {
    'Quality': np.array([
        [ 1,   1,   5,   7,  9],
        [ 1,   1,   3,   5,  7],
        [1/5, 1/3,  1,   3,  5],
        [1/7, 1/5, 1/3,  1,  2],
        [1/9, 1/7, 1/5, 1/2, 1]
        ]),
    'Education': np.array([
        [ 1,   3,   5,  9],
        [1/3,  1,   3,  7],
        [1/5, 1/3,  1,  3],
        [1/9, 1/7, 1/3, 1]
        ]),
    'Experience': np.array([
        [ 1,   1,   3,   5,  7],
        [ 1,   1,   2,   3,  5],
        [1/3, 1/2,  1,   2,  3],
        [1/5, 1/3, 1/2,  1,  3],
        [1/7, 1/5, 1/3, 1/3, 1]
        ]),
    'Dependability': np.array([
        [ 1,   3,   5,  9],
        [1/3,  1,   3,  5],
        [1/5, 1/3,  1,  3],
        [1/9, 1/5, 1/3, 1]
        ]) 
    }

# Create Rating System
emp_eval = AHPRating(criteria, criteria_pcm, rating_scales, rating_pcms)

# See rating system details
emp_eval.rating_system_details()

# Read candidates rating data from Excel
employee_ratings = AHPRating.read_candidate_ratings(
                    'employee_ratings_data.xlsx', 'employees',
                    display=True)

eval_results = emp_eval.evaluate(employee_ratings)
# Make sure we see everything in one whole table.
pd.set_option('display.max_columns', 100,
               'display.max_colwidth', 100,
               'display.width', 500)
print(eval_results)

# Run sensitivity_analysis on all candidates
emp_eval.sensit()

# Run sensitivity on specific list of candidates
emp_eval.sensit(['John Lim','Harry Lee'])
