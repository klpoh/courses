# -*- coding: utf-8 -*-
# Job Selection Problem with Growth subcriteria (2026 04 21)
from DApy.mcdm import AHPNode, AHPModel
import numpy as np
 
# Goal PCM (6 criteria)
goal_pcm = np.array([
    [ 1,   1,   1,  4,  1,  1/2],
    [ 1,   1,   2,  4,  1,  1/2],
    [ 1,  1/2,  1,  5,  3,  1/2],
    [1/4, 1/4, 1/5, 1, 1/3, 1/3],
    [ 1,   1,  1/3, 3,  1,   1 ],
    [ 2,   2,   2,  3,  1,   1 ]
])

goal = AHPNode("Goal", pcm=goal_pcm)

C1 = AHPNode('Research')
C2 = AHPNode('Growth')
C3 = AHPNode('Benefits')
C4 = AHPNode('Colleagues')
C5 = AHPNode('Location')
C6 = AHPNode('Reputation')

goal.children=[C1,C2,C3,C4,C5,C6]

# Subcriteria for C2 'Growth'
C21 = AHPNode('Short-term')
C22 = AHPNode('Long-term')
C2.children = [C21,C22]
C2.pcm = np.array([
    [1, 1/3],
    [3,  1]
])

alternatives = ['Company A','Company B','Company C']

# Alternative PCM w.r.t. leaf criteria
C1.alt_pcm = np.array([
    [1, 1/4, 1/2],
    [4,  1,   3 ],
    [2, 1/3,  1 ]
])

C21.alt_pcm = np.array([
    [1, 1/3, 1/7],
    [3,  1,  1/3],
    [7,  3,   1 ]
])

C22.alt_pcm = np.array([
    [ 1,   3,  5],
    [1/3,  1,  2],
    [1/5, 1/2, 1]
])


C3.alt_pcm = np.array([
    [ 1,  3, 1/3],
    [1/3, 1, 1/7],
    [ 3,  7,  1 ]
])

C4.alt_pcm = np.array([
    [ 1,  1/3, 5],
    [ 3,   1,  7],
    [1/5, 1/7, 1]
])

C5.alt_pcm = np.array([
    [ 1,   1,  7],
    [ 1,   1,  7],
    [1/7, 1/7, 1]
]) 

C6.alt_pcm = np.array([
    [ 1,   7,  9],
    [1/7,  1,  2],
    [1/9, 1/2, 1]
])

# Build the AHP model and solve it
model = AHPModel(goal, alternatives)
model.solve()

# Plot the global weights bar chart.
model.plot_global_weights()

# Plot the hierarchy tree in text form.
model.plot_text_tree()

# Peform sensitivity analysis
model.sensit()

# Display all the details about the model.
model.display_model()

# Plot the hierarchy in graphic form.
model.plot_hierarchy(title='Job Selection Problem with Growth Subcriteria')
