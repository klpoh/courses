# -*- coding: utf-8 -*-
# AHP matrix with preference order graph (2026 04 21)
from DApy.mcdm import AHPMatrix

# Matrix with transivity violation
PCM2 = [[ 1,  3, 1/3],
        [1/3, 1,  5 ],
        [ 3, 1/5, 1 ]]

# Compute A2 with default method and labels
A2 = AHPMatrix(PCM2)
A2.compute()
A2.print_results()

# Draw the preference graph
A2.preference_graph()
