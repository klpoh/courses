# -*- coding: utf-8 -*-
# Compute AHP matrix basics (2026 04 21)
from DApy.mcdm import AHPMatrix

PCM1 = [[1, 1/3, 1/2],
       [ 3,  1,   3 ],
       [ 2, 1/3,  1 ]]

# Create the AHP matrix
A1 = AHPMatrix(PCM1, labels=['Quality','Cost','Sustainability'])

# Display the matrix
A1.matrix()

# Compute A1 using 'eigen' method.
# Available methods: 'eigen' (default), 'algebra','power', 'rgm', 'column'
# Note that 'rgm' and 'column' are approximate methods (not recomended).
w, lam, ci, cr = A1.compute(method='eigen')
print(f"lambda_max={lam:.6f},  CI={ci:6f},  CR={cr:6f}")

# Display matrix and all results for copy and paste to Word.
A1.print_results()
