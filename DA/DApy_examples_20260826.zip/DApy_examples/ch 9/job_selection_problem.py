# -*- coding: utf-8 -*-
# Job Selection Problem (2026 04 21)
from DApy.mcdm import AHPNode, AHPModel
import numpy as np

goal_pcm = np.array([
    [ 1,   1,   1,  4,  1,  1/2],
    [ 1,   1,   2,  4,  1,  1/2],
    [ 1,  1/2,  1,  5,  3,  1/2],
    [1/4, 1/4, 1/5, 1, 1/3, 1/3],
    [ 1,   1,  1/3, 3,  1,   1 ],
    [ 2,   2,   2,  3,  1,   1 ]
])

goal = AHPNode("Goal", pcm=goal_pcm)

C1 = AHPNode('Research')
C2 = AHPNode('Growth')
C3 = AHPNode('Benefits')
C4 = AHPNode('Colleagues')
C5 = AHPNode('Location')
C6 = AHPNode('Reputation')

goal.children = [C1,C2,C3,C4,C5,C6]

# Define the alterantives and their PCMs.
alternatives = ['Company A','Company B','Company C']

# Alternative PCMs
C1.alt_pcm = np.array([
    [1, 1/4, 1/2],
    [4,  1,   3 ],
    [2, 1/3,  1 ]
])

C2.alt_pcm = np.array([
    [1, 1/4, 1/5],
    [4,  1,  1/2],
    [5,  2,   1 ]
])

C3.alt_pcm = np.array([
    [ 1,  3, 1/3],
    [1/3, 1, 1/7],
    [ 3,  7,  1 ]
])

C4.alt_pcm = np.array([
    [ 1,  1/3, 5],
    [ 3,   1,  7],
    [1/5, 1/7, 1]
])

C5.alt_pcm = np.array([
    [ 1,   1,  7],
    [ 1,   1,  7],
    [1/7, 1/7, 1]
]) 

C6.alt_pcm = np.array([
    [ 1,   7,  9],
    [1/7,  1,  2],
    [1/9, 1/2, 1]
])

# Build and solve the model
model = AHPModel(goal,alternatives)
model.solve()
model.plot_global_weights()
model.plot_text_tree()
model.sensit()
model.display_model()
model.plot_hierarchy(title='Job Selection Problem')

  