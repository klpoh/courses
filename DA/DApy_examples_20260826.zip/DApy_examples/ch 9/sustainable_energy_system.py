# -*- coding: utf-8 -*-
# Sustainable Energy System Problem (2026 04 21)
from DApy.mcdm import AHPNode, AHPModel
import numpy as np

goal_pcm = np.array([
    [1,  1,  1/5, 1/2],
    [1,  1,  1/5, 1/2],
    [5,  5,   1,   3 ],
    [2,  2,  1/3,  1 ]
])

goal = AHPNode("Goal", pcm=goal_pcm)

C1 = AHPNode('Technical')
C2 = AHPNode('Economic')
C3 = AHPNode('Environmental')
C4 = AHPNode('Social')
   
goal.children = [C1,C2,C3,C4]

# Subcriteria for C1 'Technical'
C11 = AHPNode('Tech readiness')
C12 = AHPNode('Safety')
C13 = AHPNode('Efficiency')
C14 = AHPNode('Useful life')
C1.children = [C11,C12,C13,C14]
C1.pcm = np.array([
    [ 1,   1,  3,  1 ],
    [ 1,   1,  3,  1 ],
    [1/3, 1/3, 1, 1/2],
    [ 1,   1,  2,  1 ]
])

# Subcriteria for C2 'Economic'
C21 = AHPNode('Investment cost')
C22 = AHPNode('O&M costs')
C23 = AHPNode('Feed-in-tariff')
C2.children = [C21,C22,C23]
C2.pcm = np.array([
    [1, 1/9, 1/5],
    [9,  1,   4 ],
    [5, 1/4,  1 ]
])
   
# Subcriteria for C3  'Environmental'
C31 = AHPNode('CO2 emission')
C32 = AHPNode('Land use')
C33 = AHPNode('Water consumption')
C3.children = [C31,C32,C33]
C3.pcm = np.array([
    [1, 1/4, 1/3],
    [4,  1,   1 ],
    [3,  1,   1 ]
])

# Subcriteria for C4  'Social'
C41 = AHPNode('Jobs creation')
C42 = AHPNode('Meet demands')
C4.children = [C41,C42]
C4.pcm = np.array([
    [ 1,  2],
    [1/2, 1]
])

alternatives = ['Solar PV','Wind','Nuclear','Biomass']

# Alternative PCMs
C11.alt_pcm = np.array([
    [ 1,   1,  3,  2 ],
    [ 1,   1,  3,  2 ],
    [1/3, 1/3, 1, 1/2],
    [1/2, 1/2, 2,  1 ]
])

C12.alt_pcm = np.array([
    [ 1,   2,  3, 1/2],
    [1/2,  1,  2, 1/2],
    [1/3, 1/2, 1, 1/4],
    [ 2,   2,  4,  1 ]
])

C13.alt_pcm = np.array([
    [1, 1/2, 1/2, 1/2],
    [2,  1,   1,   2 ],
    [2,  1,   1,   1 ],
    [2,  1/2, 1,   1 ]
])

C14.alt_pcm = np.array([
    [1, 1, 1/2,  1 ],
    [1, 1, 1/3, 1/2],
    [2, 3,  1,   3 ],
    [1, 2, 1/3,  1 ]
])

C21.alt_pcm = np.array([
    [1, 1/2,  1, 1],
    [2,  1,   2, 2],
    [1,  1/2, 1, 1],
    [1,  1/2, 1, 1]
])

C22.alt_pcm = np.array([
    [ 1,  2, 1/3, 1/7],
    [1/2, 1, 1/3, 1/9],
    [ 3,  3,  1,  1/3],
    [ 7,  9,  3,   1 ]
])

C23.alt_pcm = np.array([
    [1, 1/2, 1/2, 1/2],
    [2,  1,   1,   2 ],
    [2,  1,   1,   1 ],
    [2, 1/2,  1,   1 ]
])
   
C31.alt_pcm = np.array([
    [ 1, 1/2,  1/2, 3],
    [ 2,  1,   1/2, 5],
    [ 2,  2,    1,  5],
    [1/3, 1/5, 1/5, 1]
])

C32.alt_pcm = np.array([
    [ 1,   8,   7,  9],
    [1/8,  1,   1,  4],
    [1/7,  1,   1,  4],
    [1/9, 1/4, 1/4, 1]
])

C33.alt_pcm = np.array([
    [ 1, 1/2,  9,  8 ],
    [ 2,  1,   9,  9 ],
    [1/9, 1/9, 1, 1/2],
    [1/8, 1/9, 2,  1 ]
])

C41.alt_pcm = np.array([
    [ 1,  5, 6,  4 ],
    [1/5, 1, 1,  1 ],
    [1/6, 1, 1, 1/2],
    [1/4, 1, 2,  1 ]
])

C42.alt_pcm = np.array([
    [ 1, 1/5,  2, 1/2],
    [ 5,  1,   7,  2 ],
    [1/2, 1/7, 1, 1/3],
    [ 2,  1/2, 3,  1 ]
])

  
# Build and solve the model
model = AHPModel(goal, alternatives)
model.solve()
model.plot_global_weights()

model.plot_text_tree()

model.sensit()

model.display_model()

model.plot_hierarchy(title='Sustainable Energy System Problem', figsize=(16,8))

    