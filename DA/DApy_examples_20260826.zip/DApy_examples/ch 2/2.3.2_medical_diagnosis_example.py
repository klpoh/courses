# -*- coding: utf-8 -*-
# 2.3.2 medical diagnosis example (2026 06 17)
from DApy.probability import ProbTree
import matplotlib.pyplot as plt

# Set up the data
Lung_cancer = ['Positive','Negative']
prior = [0.4, 0.6]

Xray_result = ['Positive','Negative']
sensitivity = 0.60
specificity = 0.96
test_performance = [[sensitivity, 1-sensitivity],
                    [1-specificity, specificity]]

# Built the probability tree and check the probability distributions.
Test_tree = ProbTree(Lung_cancer, Xray_result, 
                prior, test_performance,
                'Lung Cancer','Xray Results')
Test_tree.CPT(prob_decimals=2)

# Show the probability tree.
ax1 = Test_tree.draw_prob_tree(prob_decimals=2)
ax1.set_title("Test results given Lung Cancer",
  fontname='Times New Roman',fontsize='x-large',fontweight='bold')
plt.show()

# Flip the tree and show the probabilities.
Diag_tree = Test_tree.flip_tree()
Diag_tree.CPT(prob_decimals=4)

# Show the flipped tree.
ax2=Diag_tree.draw_prob_tree(prob_decimals=4)
ax2.set_title("Lung Cancer given X ray results",
  fontname='Times New Roman',fontsize='x-large',fontweight='bold')
plt.show()
