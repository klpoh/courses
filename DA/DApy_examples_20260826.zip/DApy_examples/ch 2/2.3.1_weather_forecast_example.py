# -*- coding: utf-8 -*-
# 2.3.1 Weather Forecast example (2026 06 17)
from DApy.probability import ProbTree
import matplotlib.pyplot as plt

# Set up the data
Weather = ['Rain','No rain']
p_weather = [0.6, 0.4]

Forecast = ['Forecast rain','Forecast no rain']
q_forecast = [[0.9, 0.1],
              [0.3, 0.7]]

# Create a probability tree
weather_tree = ProbTree(Weather, Forecast, 
                p_weather, q_forecast, 'Weather','Forcast')

# Show the probability distributions
weather_tree.CPT(prob_decimals=2)

# Show the probability tree
ax1 = weather_tree.draw_prob_tree(prob_decimals=2)
ax1.set_title("Weather Forecast given Weather",
    fontname='Times New Roman',fontsize='x-large',fontweight='bold')
plt.show()

# Flip the tree to change the order of conditioning
forecast_tree = weather_tree.flip_tree()

# Show the probability distributions
forecast_tree.CPT(prob_decimals=6)

# Show the flipped tree
ax2=forecast_tree.draw_prob_tree(prob_decimals=6)
ax2.set_title("Predicting Weather given Forecasts",
              fontname='Times New Roman',
              fontsize='x-large', fontweight='bold')
plt.show()
