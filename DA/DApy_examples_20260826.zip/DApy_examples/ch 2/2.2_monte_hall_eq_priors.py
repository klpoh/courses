# -*- coding: utf-8 -*-
# 2.2 Monte Hall Equal Priors (2026 06 17)
from DApy.probability import ProbTree
import matplotlib.pyplot as plt
import numpy as np

# Base data: 3 doors with equal priors
Prize = ['A','B','C']
prior = [1/3, 1/3, 1/3]


# Case 1: Contestent chose A initially
Open_door = ['Open B','Open C']
p_open_door = [[0.5, 0.5],
               [0, 1],
               [1, 0]]

# Build the probability tree and check the probabilities
Prob_tree = ProbTree(Prize, Open_door, 
                prior, p_open_door,'Prize location','Open Door')
Prob_tree.CPT(prob_decimals=4)

# Show the probability tree
ax1 = Prob_tree.draw_prob_tree(prob_decimals=4)
ax1.set_title("Open door given prize location when intital choice is A",
              fontname='Times New Roman',
              fontsize='x-large', fontweight='bold')
plt.show()

# Flip the tree and show the probabilities
Predict_tree = Prob_tree.flip_tree()
Predict_tree.CPT(prob_decimals=6)

# Trace the decision to stay or to swap depending on door open
print("\nDecisions when Contestant chose A")
arr = Predict_tree.q
for k, open in enumerate(Open_door):
    print(f"If Host opens {open}:")
    max_val = np.max(arr[k])
    indices = np.where(arr[k] == max_val)[0]
    decisions = [Prize[i] for i in indices ]
    print("  Choose:", end=" ")
    for loc in decisions:
        print(loc, end='  ')
    print(f"  Max Probability = {max_val:.4f}")

# Show the flipped tree
ax2=Predict_tree.draw_prob_tree(prob_decimals=6)
ax2.set_title("Prize location given open door when intital choice is A",
  fontname='Times New Roman',fontsize='x-large', fontweight="bold")
plt.show()


# Case 2: Contestant chose B initially
Open_door = ['Open A','Open C']
p_open_door = [[0, 1],
               [0.5, 0.5],
               [1, 0]]

# Build the probability tree and check the probabilities
Prob_tree = ProbTree(Prize, Open_door, 
            prior, p_open_door,'Prize location','Open Door')
Prob_tree.CPT(prob_decimals=4)

# Show the probability tree
ax1 = Prob_tree.draw_prob_tree(prob_decimals=4)
ax1.set_title("Open door given prize location when intital choice is B",
  fontname='Times New Roman',fontsize='x-large',fontweight='bold')
plt.show()

# Flip the tree and show the probabilities
Predict_tree = Prob_tree.flip_tree()
Predict_tree.CPT(prob_decimals=6)

# Trace the decision to stay or to swap depending on door open
print("\nDecisions when Contestant chose B")
arr = Predict_tree.q
for k, open in enumerate(Open_door):
    print(f"If Host opens {open}:")
    max_val = np.max(arr[k])
    indices = np.where(arr[k] == max_val)[0]
    decisions = [Prize[i] for i in indices ]
    print("  Choose:", end=" ")
    for loc in decisions:
        print(loc, end='  ')
    print(f"  Max Probability = {max_val:.4f}")

# Show the flipped tree
ax2=Predict_tree.draw_prob_tree(prob_decimals=6)
ax2.set_title("Prize location given open door when intital choice is B",
              fontname='Times New Roman',
              fontsize='x-large', fontweight="bold")
plt.show()


# Case 3: Contestent chose C initially
Open_door = ['Open A','Open B']
p_open_door = [[0, 1],
               [1, 0],
               [0.5, 0.5]]

# Build the probability tree and check the probabilities
Prob_tree = ProbTree(Prize, Open_door, 
    prior, p_open_door,'Prize location','Open Door')
Prob_tree.CPT(prob_decimals=4)

# Show the probability tree
ax1 = Prob_tree.draw_prob_tree(prob_decimals=4)
ax1.set_title("Open door given prize location when intital choice is C",
              fontname='Times New Roman',
              fontsize='x-large', fontweight='bold')
plt.show()

# Flip the tree and show the probabilities
Predict_tree = Prob_tree.flip_tree()
Predict_tree.CPT(prob_decimals=6)

# Trace the decision to stay or to swap depending on door open
print("\nDecisions when Contestant chose C")
arr = Predict_tree.q
for k, open in enumerate(Open_door):
    print(f"If Host opens {open}:")
    max_val = np.max(arr[k])
    indices = np.where(arr[k] == max_val)[0]
    decisions = [Prize[i] for i in indices ]
    print("  Choose:", end=" ")
    for loc in decisions:
        print(loc, end='  ')
    print(f"  Max Probability = {max_val:.4f}")

# Show the flipped tree
ax2=Predict_tree.draw_prob_tree(prob_decimals=6)
ax2.set_title("Prize location given open door when intital choice is C",
  fontname='Times New Roman',fontsize='x-large',fontweight='bold')
plt.show()
