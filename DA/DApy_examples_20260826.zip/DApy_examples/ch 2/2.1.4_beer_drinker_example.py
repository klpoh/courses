# -*- coding: utf-8 -*-
# 2.1.4 Beer Drinker Example example (2026 06 17)
from DApy.probability import ProbTree
import matplotlib.pyplot as plt

# Set up the probability distributions
Beer_drinker = ['Beer drinker','Non-beer drinker']
p_beer = [0.2, 0.8]

Graduate = ['Graduate','Non-graduate']
q_grad = [[0.1, 0.9],
          [0.7, 0.3]]

# Create an probabilty tree instance
Beer_tree = ProbTree(Beer_drinker, Graduate, 
            p_beer, q_grad,'Beer Drinker','Graduate')

# Show the conditional probability table and add title
Beer_tree.CPT(prob_decimals=2)
ax1 = Beer_tree.draw_prob_tree(prob_decimals=2)
ax1.set_title("Graduate given Beer Drinking",
              fontname='Times New Roman',
              fontsize='x-large', fontweight='bold')
plt.show()

# Flip the tree to change the order of conditioning.
Grad_tree = Beer_tree.flip_tree()
Grad_tree.CPT(prob_decimals=6)
ax2=Grad_tree.draw_prob_tree(prob_decimals=6)
ax2.set_title("Beer drinking given Graduate",
              fontname='Times New Roman',
              fontsize='x-large', fontweight='bold')
plt.show()
