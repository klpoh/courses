# -*- coding: utf-8 -*-
# Problem 2.2 Taxi Cab Color Problem (2026 06 17)
from DApy.probability import ProbTree
import matplotlib.pyplot as plt

# Set up the data
Cab_colors = ['Blue','Green']
base_rate = [0.9, 0.1]
Witness = ['Says Blue','Says Green']
p_test = [[0.8, 0.2],
          [0.2, 0.8]]

# Create the tree
Prob_tree = ProbTree(Cab_colors, Witness, 
                     base_rate, p_test,
                     'Cab color','Witness says')
Prob_tree.CPT(prob_decimals=4)

# Draw the tree
ax1 = Prob_tree.draw_prob_tree(prob_decimals=4)
ax1.set_title("What witness says given cab color",
              fontname='Times New Roman',
              fontsize='x-large', fontweight='bold')
plt.show()

# Flip the tree and show the probabilities
Predict_tree = Prob_tree.flip_tree()
Predict_tree.CPT(prob_decimals=6)

# Draw the flipped tree.
ax2=Predict_tree.draw_prob_tree(prob_decimals=6)
ax2.set_title("Cab color given what witness says",
              fontname='Times New Roman',
              fontsize='x-large', fontweight='bold')
plt.show()
