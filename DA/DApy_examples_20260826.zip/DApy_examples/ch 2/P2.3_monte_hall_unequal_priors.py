# -*- coding: utf-8 -*-
# Problem 2.3 Monte Hall UnEqual Priors (2026 06 17)
from DApy.probability import ProbTree
import matplotlib.pyplot as plt
import numpy as np

Prize = ['Prize in A','Prize in B','Prize in C']
prior = [0.6, 0.1, 0.3]

# Helper function
def decisions(initial_choice, arr):
    print(f"\nDecisions when Contestent initial choice is {initial_choice}:")
    for k, open in enumerate(Open_door):
        print(f"  If Host opens {open}:")
        max_val = np.max(arr[k])
        indices = np.where(arr[k] == max_val)[0]
        decisions = [Prize[i] for i in indices ]
        print("    Choose:", end=" ")
        for loc in decisions:
            print(loc, end='  ')
        print(f"  Max Conditional Prob = {max_val:.4f}")

# Contestant chose A
Open_door = ['Open B','Open C']
p_open_door = [[0.5, 0.5],
               [0, 1],
               [1, 0]]

Prob_tree = ProbTree(
                Prize, Open_door, 
                prior, p_open_door,
                'Prize location','Host Opens Door')
Prob_tree.CPT(prob_decimals=4)
ax1 = Prob_tree.draw_prob_tree(prob_decimals=4)
ax1.set_title("Open door given prize location when inital choice is A",
              fontname='Times New Roman',
              fontsize='x-large', fontweight="bold")
plt.show()

Predict_tree = Prob_tree.flip_tree()
Predict_tree.CPT(prob_decimals=6)
decisions('A', Predict_tree.q)

ax2=Predict_tree.draw_prob_tree(prob_decimals=6)
ax2.set_title("Prize location given open door when inital choice is A",
              fontname='Times New Roman',
              fontsize='x-large', fontweight='bold')
plt.show()

# Contestant chose B
Open_door = ['Open A','Open C']

p_open_door = [[0, 1],
               [0.5, 0.5],
               [1, 0]]

Prob_tree = ProbTree(
                Prize, Open_door, 
                prior, p_open_door,
                'Prize location','Host Opens Door')
Prob_tree.CPT(prob_decimals=4)
ax1 = Prob_tree.draw_prob_tree(prob_decimals=4)
ax1.set_title("Open door given prize location when inital choice is B",
              fontname='Times New Roman',
              fontsize='x-large', fontweight='bold')
plt.show()

Predict_tree = Prob_tree.flip_tree()
Predict_tree.CPT(prob_decimals=6)
decisions('B', Predict_tree.q)

ax2=Predict_tree.draw_prob_tree(prob_decimals=6)
ax2.set_title("Prize location given open door when inital choice is B",
              fontname='Times New Roman',
              fontsize='x-large', fontweight='bold')
plt.show()

# Contestant chose C
Open_door = ['Open A','Open B']

p_open_door = [[0, 1],
               [1, 0],
               [0.5, 0.5]]

Prob_tree = ProbTree(
                Prize, Open_door, 
                prior, p_open_door,
                'Prize location','Host Opens Door')
Prob_tree.CPT(prob_decimals=4)
ax1 = Prob_tree.draw_prob_tree(prob_decimals=4)
ax1.set_title("Open door given prize location when inital choice is C",
              fontname='Times New Roman',
              fontsize='x-large', fontweight='bold')
plt.show()

Predict_tree = Prob_tree.flip_tree()
Predict_tree.CPT(prob_decimals=6)
decisions('C', Predict_tree.q)

ax2=Predict_tree.draw_prob_tree(prob_decimals=6)
ax2.set_title("Prize location given open door when inital choice is C",
              fontname='Times New Roman',
              fontsize='x-large', fontweight='bold')
plt.show()