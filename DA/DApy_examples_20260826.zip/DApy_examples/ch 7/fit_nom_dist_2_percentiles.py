# -*- coding: utf-8 -*-
# Fit a normal distribution to 2 percentile values (2026 06 17)
from DApy.probability import FitNormP
import matplotlib.pyplot as plt

# Two points (exact closed-form solution)
xs = [50,   90]
ps = [0.1, 0.9]

# Fit the distribution
norm_fit2p = FitNormP(xs, ps)
mu, sigma = norm_fit2p.fit()
print(f"mu    = {mu:.2f}")
print(f"sigma = {sigma:.2f}")

if not(mu is None or sigma is None):
    # Plot the fitted PDF
    ax = norm_fit2p.plot()
    ax.set_title("Fitted Normal Distribution to 2 Percentile Values")
    ax.grid()
    plt.show()
