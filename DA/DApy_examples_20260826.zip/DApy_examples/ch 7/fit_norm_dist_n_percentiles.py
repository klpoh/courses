# -*- coding: utf-8 -*-
# Fit a normal distribution to more than 2 percentile values (2026 06 17)
from DApy.probability import FitNormP
import matplotlib.pyplot as plt

xs = [40,   50,  70,  80,   90 ]
ps = [0.05, 0.1, 0.5, 0.75, 0.9]

# Fit the distribution
norm_fit5p = FitNormP(xs, ps)
mu, sigma, r_sq = norm_fit5p.fit()
print(f"mu    = {mu:.4f}")
print(f"sigma = {sigma:.4f}")
print(f"r_sq  = {r_sq:.4f}")  

# Plot the fitted PDF
ax = norm_fit5p.plot()
ax.set_title("Fitted Normal Distribution to 5 Percentil Values")
ax.grid()
plt.show() 
