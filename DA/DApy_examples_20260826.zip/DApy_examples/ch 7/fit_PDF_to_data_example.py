# -*- coding: utf-8 -*-
# Fit continuous distributions to data with scipy.stats (2026 04 21)
from DApy.probability import FitPDF
from DApy.utils import read_data_from_excel

# Read data from data file.  Replace this with your own data loader
file_name = "7.4.3_example_data.xlsx"
sheet_name = "data_1"
data = read_data_from_excel(file_name, sheet_name)
# you should check that the data was loaded correctly.

model = FitPDF(data)
model.fit(method='MLE')  # Can be 'MLE' (default) or 'MM' (not recommended)

# Sort and show the top results
# sort can be 'KS','AIC','BIC','RMSE_pdf'
results_KS=model.results(sort='KS', top_k=20)  

# Compare the PDF of the top 10.
model.plot_pdf(sort='KS',top_k=10)  # top_k = 10 (default)

# Compare the CDF of the top 10.
model.plot_cdf(sort='KS',top_k=10)

# Extract the results for lognormal (index = 5)
params = results_KS.iloc[5, results_KS.columns.get_loc('params')]
for p in params:
    print(float(p))

# Save results to excel
model.save_results_to_excel("outputs1.xlsx", sort='KS')
