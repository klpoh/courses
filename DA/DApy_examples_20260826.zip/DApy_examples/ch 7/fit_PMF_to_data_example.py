# -*- coding: utf-8 -*-
# Fit discrete distributions to data example (2026 04 21)
from DApy.probability import FitPMF
from DApy.utils import read_data_from_excel

# Read data from data file.  Replace this with your own data loader
file_name = "7.4.3_example_data.xlsx"
sheet_name = "data_2"
data = read_data_from_excel(file_name, sheet_name)
# you should check that the data was loaded correctly.

model = FitPMF(data)
model.fit()

# Sort and show the top results
# sort can be 'KS','AIC','BIC'
results_KS=model.results(sort='KS', top_k=5) 

# Compare the PMFs
model.plot_pmf(sort='KS',top_k=5)  # top_k = 10 (default)

# Compre the CDFs
model.plot_cdf(sort='KS',top_k=5)

# Extract the results for binom (index = 3)
params = results_KS.iloc[3, results_KS.columns.get_loc('params')]
for p in params:
    print(float(p))

# Save results to excel
model.save_results_to_excel("outputs2.xlsx", sort='KS')
