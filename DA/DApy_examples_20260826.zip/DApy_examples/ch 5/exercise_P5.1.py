# -*- coding: utf-8 -*-
# Exercise P5.1 (2026 04 21)
import networkx as nx
from DApy.bn import DSepAnalysis

# Exercise P5.1 
Parents = {'A': ['F'], 
           'B': ['A','G'], 
           'C': ['A'], 
           'D': ['B','C'], 
           'E': ['D'], 
           'F': [],
           'G': [],
           'H': ['C']}

# List of directed arcs
Edges = [(p, child) for child, par in Parents.items() for p in par]

# Create the graph
G = nx.DiGraph()
G.add_edges_from(Edges)

# Positions to draw the nodes 
sin60 = 3**(1/2)/2 
pos = {'G': (-0.275, 0), 
       'B': (-0.125, 0),
       'C': ( 0.125, 0),
       'H': ( 0.275, 0),
       'A': ( 0, sin60),
       'F': ( 0, 2*sin60),
       'D': ( 0,-sin60),
       'E': ( 0,-2*sin60) }

dag = DSepAnalysis(G)

# Question 1(a)
X = {'B'}
Y = {'C'}
Z = {'F'}

dag.plot(X, Y, Z, pos=pos, title="Exercise P5.1(a)")

# Use networkx built-in d-separation analyser
print("\nUsing networkx built-in d-separation analyser")
print(f"  {X}⊥{Y}|{Z} is {dag.is_d_separated(X, Y, Z)}")

# Path-by-path blocking analysis
dag.path_blocking_analysis(X, Y, Z)


# Question 1(b)
X = {'B'}
Y = {'C'}
Z = {'A'}
dag.plot(X, Y, Z, pos=pos, title="Exercise P5.1(b)")

# Use networkx built-in d-separation analyser
print("\nUsing networkx built-in d-separation analyser")
print(f"  {X}⊥{Y}|{Z} is {dag.is_d_separated(X, Y, Z)}")

# Path-by-path blocking analysis
dag.path_blocking_analysis(X, Y, Z)


# Question 1(c)
X = {'B'}
Y = {'C'}
Z = {'A','E'}
dag.plot(X, Y, Z, pos=pos, title="Exercise P5.1(c)")

# Use networkx built-in d-separation analyser
print("\nUsing networkx built-in d-separation analyser")
print(f"  {X}⊥{Y}|{Z} is {dag.is_d_separated(X, Y, Z)}")

# Path-by-path blocking analysis
dag.path_blocking_analysis(X, Y, Z)


# Question 1(d)
X = {'B'}
Y = {'C'}
Z = {'A','D'}
dag.plot(X, Y, Z, pos=pos, title="Exercise P5.1(d)")

# Use networkx built-in d-separation analyser
print("\nUsing networkx built-in d-separation analyser")
print(f"  {X}⊥{Y}|{Z} is {dag.is_d_separated(X, Y, Z)}")

# Path-by-path blocking analysis
dag.path_blocking_analysis(X, Y, Z)


# Question 1(e)
X = {'A'}
Y = {'D'}
Z = {'B','G'}
dag.plot(X, Y, Z, pos=pos, title="Exercise P5.1(e)")

# Use networkx built-in d-separation analyser
print("\nUsing networkx built-in d-separation analyser")
print(f"  {X}⊥{Y}|{Z} is {dag.is_d_separated(X, Y, Z)}")

# Path-by-path blocking analysis
dag.path_blocking_analysis(X, Y, Z)


# Question 1(f)
X = {'A'}
Y = {'D'}
Z = {'B','C'}
dag.plot(X, Y, Z, pos=pos, title="Exercise P5.1(f)")

# Use networkx built-in d-separation analyser
print("\nUsing networkx built-in d-separation analyser")
print(f"  {X}⊥{Y}|{Z} is {dag.is_d_separated(X, Y, Z)}")

# Path-by-path blocking analysis
dag.path_blocking_analysis(X, Y, Z)


# Question 1(g)
X = {'E'}
Y = {'F'}
Z = {'B','C'}
dag.plot(X, Y, Z, pos=pos, title="Exercise P5.1(g)")

# Use networkx built-in d-separation analyser
print("\nUsing networkx built-in d-separation analyser")
print(f"  {X}⊥{Y}|{Z} is {dag.is_d_separated(X, Y, Z)}")

# Path-by-path blocking analysis
dag.path_blocking_analysis(X, Y, Z)
