# -*- coding: utf-8 -*-
# Exercise P5.2 (2026 04 21) 
import networkx as nx
from DApy.bn import DSepAnalysis

# Exercise P5.2
Parents = {'A': [], 
           'B': [], 
           'C': [], 
           'D': [], 
           'E': [], 
           'F': [],
           'G': ['A','B', 'F', 'H'],
           'H': ['C'],
           'I': ['H'],
           'J': ['D', 'E'],
           'K': ['G', 'Q'],
           'L': ['K', 'M', 'R'],
           'M': ['S'],
           'N': ['I', 'J', 'M'],
           'P': ['J', 'N', 'U'],
           'Q': [],
           'R': [],
           'S': [],
           'T': ['M'],
           'U': ['T'],
           'V': ['P'] }

# List of directed arcs
Edges = [(p, child) for child, par in Parents.items() for p in par]

# Create the graph
G = nx.DiGraph()
G.add_edges_from(Edges)

# Positions to draw the nodes 
sin60 = 3**(1/2)/2
pos = {'Q': (0, 0),
       'R': (1, 0),
       'S': (2, 0),
       'T': (3, 0),
       'U': (4, 0),
       'V': (5, 0),
       'K': (0.5, sin60),
       'L': (1.5, sin60),
       'M': (2.5, sin60),
       'N': (3.5, sin60),
       'P': (4.5, sin60),
       'F': (0, 2*sin60),
       'G': (1, 2*sin60),
       'H': (2, 2*sin60),
       'I': (3, 2*sin60),
       'J': (4, 2*sin60),
       'A': (0.5, 3*sin60),
       'B': (1.5, 3*sin60),
       'C': (2.5, 3*sin60),
       'D': (3.5, 3*sin60),
       'E': (4.5, 3*sin60) }

dag = DSepAnalysis(G)

# Question 2(a)
X = {'A'}
Y = {'V'}
Z = {'H','L','R'}

dag.plot(X, Y, Z, pos=pos, figsize=(8,4),
         title="Exercise P5.2(a)")

# Use networkx built-in d-separation analyser
print("\nUsing networkx built-in d-separation analyser")
print(f"  {X}⊥{Y}|{Z} is {dag.is_d_separated(X, Y, Z)}")

# Path-by-path blocking analysis
dag.path_blocking_analysis(X, Y, Z)


# Question 2(b)
X = {'A'}
Y = {'V'}
Z = {'M','S','T'}

dag.plot(X, Y, Z, pos=pos, title="Exercise P5.2(b)", figsize=(8,4))

# Use networkx built-in d-separation analyser
print("\nUsing networkx built-in d-separation analyser")
print(f"  {X}⊥{Y}|{Z} is {dag.is_d_separated(X, Y, Z)}")

# Path-by-path blocking analysis
dag.path_blocking_analysis(X, Y, Z)
