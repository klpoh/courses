# -*- coding: utf-8 -*-
# d-seperation examples set 2 (2026 04 21) 
import networkx as nx
from DApy.bn import DSepAnalysis

# Define the nodes and their parents
Parents = {'A': [],
           'B': ['C','E'],
           'C': ['A'],
           'D': ['A'], 
           'E': ['C'], 
           'F': ['E','G'],
           'G': ['C'],
           'H': ['F'],
           'I': ['G'] }

# List of directed arcs
Edges = [(p, child) for child, par in Parents.items() for p in par]

# Create the graph
G = nx.DiGraph()
G.add_edges_from(Edges)

# Positions to draw the nodes
# Spring layout will be used if this is not provide.
sin60 = 3**(0.5)/2 
pos = {'H': (1, 0),
       'I': (2, 0),
       'E': (0, sin60),
       'F': (1, sin60),
       'G': (2, sin60),
       'B': (0, 2*sin60),
       'C': (1, 2*sin60),
       'D': (2, 2*sin60),
       'A': (1, 3*sin60) }

dag = DSepAnalysis(G)

# Example 2(a)
X = {'B','E'}
Y = {'G','I'}
Z = {'A','C'}

dag.plot(X,Y,Z, pos=pos, title="d-separation Example 2(a)", figsize=(5,5))

# Use networkx built-in d-separation analyser
print("\nUsing networkx built-in d-separation analyser")
print(f"  {X}⊥{Y}|{Z} is {dag.is_d_separated(X, Y, Z)}")

# Path-by-path blocking analysis
dsep, results = dag.path_blocking_analysis(X, Y, Z)


# Example 2(b)
X = {'B','E'}
Y = {'G','I'}
Z = {'A'}

dag.plot(X,Y,Z, pos=pos, title="d-separation Example 2(b)", figsize=(5,5))

# Use networkx built-in d-separation analyser
print("\nUsing networkx built-in d-separation analyser")
print(f"  {X}⊥{Y}|{Z} is {dag.is_d_separated(X, Y, Z)}")

# Path-by-path blocking analysis
dsep, results = dag.path_blocking_analysis(X, Y, Z)

# Example 2(c)
X = {'B','E'}
Y = {'G','I'}
Z = {'C','F'}

dag.plot(X, Y,Z, pos=pos, title="d-separation Example 2(c)", figsize=(5,5))

# Use networkx built-in d-separation analyser
print("\nUsing networkx built-in d-separation analyser")
print(f"  {X}⊥{Y}|{Z} is {dag.is_d_separated(X, Y, Z)}")

# Path-by-path blocking analysis
dsep, results = dag.path_blocking_analysis(X, Y, Z)
