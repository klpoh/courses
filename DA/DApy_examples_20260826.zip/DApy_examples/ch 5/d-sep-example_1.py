# -*- coding: utf-8 -*-
# d-seperation examples set 1 (2026 04 21) 
import networkx as nx
from DApy.bn import DSepAnalysis

# Define the nodes and their parents
Parents = {'A': [],
           'B': ['D'],
           'C': [],
           'D': ['A'], 
           'E': ['B','C'], 
           'F': ['E'],
           'G': [],
           'H': ['D','G'],
           'I': ['E'],
           'J': ['F'],
           'K': ['H'],
           'L': ['H','I'],
           'M': ['I']  }

# Generate the list directed arcs
Edges = [(p, child) for child, par in Parents.items() for p in par]

# Create the graph
G = nx.DiGraph()
G.add_edges_from(Edges)

# Positions to draw the nodes
# Spring layout will be used if this is not provide.
sin60 = 3**(1/2)/2 
pos = {'K': (0, 0),
       'L': (1, 0),
       'M': (2, 0),
       'G': (-0.5, sin60),
       'H': ( 0.5, sin60),
       'I': ( 1.5, sin60),
       'J': ( 2.5, sin60),
       'D': ( 0.5, 2*sin60),
       'E': ( 1.5, 2*sin60),
       'F': ( 2.5, 2*sin60),
       'A': (0, 3*sin60),
       'B': (1, 3*sin60),
       'C': (2, 3*sin60)  }

# Example 1(a)
dag1 = DSepAnalysis(G)
X = {'A'}
Y = {'J'}
Z = {'E','I'}

dag1.plot(X, Y, Z, pos=pos, 
          title="d-separation Example 1(a)")

# Use networkx built-in d-separation analyser
print("\nUsing networkx built-in d-separation analyser")
print(f"  {X}⊥{Y}|{Z} is {dag1.is_d_separated(X, Y, Z)}")

# Path-by-path blocking analysis
dsep, results = dag1.path_blocking_analysis(X, Y, Z)


# Example 1(b)
dag2 = DSepAnalysis(G)
X = {'A'}
Y = {'J'}
Z = {'I'}

dag2.plot(X, Y, Z, pos=pos, 
          title="d-separation Example 1(b)")

# Use networkx built-in d-separation analyser
print("\nUsing networkx built-in d-separation analyser")
print(f"  {X}⊥{Y}|{Z} is {dag2.is_d_separated(X, Y, Z)}")

# Path-by-path blocking analysis
dsep, results = dag2.path_blocking_analysis(X, Y, Z)


# Example 1(c)
dag3 = DSepAnalysis(G)
X = {'A'}
Y = {'J'}
Z = {'L'}

dag3.plot(X, Y, Z, pos=pos, 
          title="d-separation Example 1(c)")

# Use networkx built-in d-separation analyser
print("\nUsing networkx built-in d-separation analyser")
print(f"  {X}⊥{Y}|{Z} is {dag3.is_d_separated(X, Y, Z)}")

# Path-by-path blocking analysis
dsep, results = dag3.path_blocking_analysis(X, Y, Z)

# Example 1(d)
# Add arc (L)->(O) to DAG
Edges = Edges+[('L','O')]
G2 = nx.DiGraph()
G2.add_edges_from(Edges)

dag4 = DSepAnalysis(G2)
pos['O'] = (1,-1*sin60)
X = {'A'}
Y = {'J'}
Z = {'O'}

dag4.plot(X, Y, Z, pos=pos, 
          title="d-separation Example 1(d)")

# Use networkx built-in d-separation analyser
print("\nUsing networkx built-in d-separation analyser")
print(f"  {X}⊥{Y}|{Z} is {dag4.is_d_separated(X, Y, Z)}")

# Path-by-path blocking analysis
dsep, results = dag4.path_blocking_analysis(X, Y, Z)
