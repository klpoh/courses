# -*- coding: utf-8 -*-
# 7.2.3_Fit_normal_dist_with_known_mean_and_1_percentile_value.py
from scipy.stats import norm
import matplotlib.pyplot as plt
import numpy as np

""" Fit normal distribution with known mean and 1 percentile value """
# Known percentile values
x1, q1 = 200, 0.5
x2, q2 = 100, 0.2
mu = x1
z2 = norm.ppf(q2)
sigma = (x2 - mu)/z2
print(f"mu = {mu}, sigma = {sigma}")

# Plot the results
xmin = norm.ppf(0.001, loc=mu, scale=sigma)
xmax = norm.ppf(0.990, loc=mu, scale=sigma)
x = np.linspace(xmin, xmax, 100)
y = norm.cdf(x, mu, sigma)
fig, ax = plt.subplots()
ax.plot(x, y, lw=2)
ax.plot([x1, x2],[q1,q2],'ro', ms=7)
ax.set_yticks(np.linspace(0, 1, 11))
ax.set_ylabel("Cumulative Probability")
ax.set_xlabel("X")
ax.grid()
plt.show()

