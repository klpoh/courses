# -*- coding: utf-8 -*-
# 4.2.9_fitting_an_equation_to_Kim's_utility_function.py
""" Fitting an equation to Kim's Utility Function """
import numpy as np
from scipy.optimize import curve_fit
import matplotlib.pyplot as plt

# Data to fit
xdata = [0, 20, 40, 50, 90, 100]
udata = [0, 0.32, 0.57, 0.67, 0.95, 1]

# Visualize the data
fig, ax = plt.subplots()
ax.plot(xdata, udata, 'bo', label='data')
ax.legend()
plt.show()

# Function to fit: u(x) = a - b exp(-x/r)
# To ensure u(0) = 0 is satisfed, we must have a = b.
# Hence u(x) = a (1 - exp(-x/r))
func = lambda x, r, a: a*(1 - np.exp(-x/r))

# Fit the function to data
popt, pcov = curve_fit(func, xdata, udata)
print(f"\nFitted parameters: {popt}")

# Compare fitted results
print("  x   data  fitted")
for x, u in zip(xdata, udata):
    print(f"{x:3}   {u:.2f}  {func(x, *popt):.2f}")

# The fitted utility function can also be written as
#       u(x) = (4/3)*(1 - 2**(-x/50))
# # Visualize the results
fig, ax = plt.subplots()
ax.plot(xdata, udata, 'bo', label='data')
x = np.linspace(0, 100, 101)
ufit = (4/3)*(1 - 2**(-x/50))
ax.plot(x, ufit, 'r-', label='fitted')
ax.set_title('u(x) = 4/3 (1 -2^(-x/50}')
ax.legend()
ax.grid()
plt.show()
