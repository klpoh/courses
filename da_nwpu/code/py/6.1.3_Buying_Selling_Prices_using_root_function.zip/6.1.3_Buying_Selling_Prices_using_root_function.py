# -*- coding: utf-8 -*-
# 6.1.3_Buying_Selling_Prices_using_root_function.py
# Updated 2023 07 24
import numpy as np
from scipy.optimize import root

""" Compute PIBP and PISP using root function """
# The wealth utility function
wuf = lambda w: np.sqrt(w) if w>=0 else -np.sqrt(-w)
wuf_vec = np.vectorize(wuf)

# The Deal
p = np.array([0.7, 0.3])
x = np.array([ 10,  -5])

# Define the Equations to Solve:
# Sell vs Don't sell: u(w0+s) = E[u(w0+x)]
def sell_func(s, w0, p, x):
    return wuf(w0+s) - np.dot(p, wuf_vec(w0+x))

# Don't buy vs Buy: u(w0) = E[u(w0-B+x)] 
def buy_func(b, w0, p, x):
    return wuf(w0) - np.dot(p, wuf_vec(w0-b+x))

# Find PISP and PIBP for different values of w0
guess = 5
for w0 in [10, 100, 1000, 10000]:
    print(f"\nw0 = {w0}:")
    
    sol_sell = root(sell_func, x0=guess, args=(w0, p, x),
                    method='hybr', options={'xtol':1E-10})
    if not sol_sell.success:
        print(f"  {sol_sell.message}, Best solution found:")
    print(f"  PISP = {sol_sell.x[0]:.6f}")
  
    sol_buy = root(buy_func, x0=guess, args=(w0, p, x),
                   method='hybr', options={'xtol':1E-10})
    if not sol_buy.success:
        print(f"  {sol_buy.message}. Best solution found:")
    print(f"  PIBP = {sol_buy.x[0]:.6f}")
   
