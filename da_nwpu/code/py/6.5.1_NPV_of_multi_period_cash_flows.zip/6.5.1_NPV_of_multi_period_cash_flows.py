# -*- coding: utf-8 -*-
# 6.5.1_NPV_of_multi_period_cash_flows.py
import numpy_financial as npf
""" Compute NPV of multi-period cash flows """
marr = 0.1
Project_A = [ -5000, 2500, 2000, 1500, 1000 ]
Project_B =	[ -5000, 1500, 1500, 1500, 2500 ]

NPV_A = npf.npv(marr, Project_A)
NPV_B = npf.npv(marr, Project_B)

print(f"NPV(A) = ${NPV_A:,.2f}")
print(f"NPV(B) = ${NPV_B:,.2f}")
