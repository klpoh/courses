# -*- coding: utf-8 -*-
# 6.1.3_Buying_Selling_Prices_using_root_scalar_function
import numpy as np
from scipy.optimize import root_scalar

# Define the wealth utility function and vectorize it
wuf = np.vectorize(
        lambda w: np.sqrt(w) if w>=0 else -np.sqrt(-w))

# The Deal
x = np.array([ 10,  -5])
p = np.array([0.7, 0.3])

# Define the Equations to solve
# u(w0+s) - E[u(w0+x)] = 0
def sell_notsell(s, w0, x, p):
    # return wuf(w0+s) - (p*wuf(w0+x)).sum()
    return wuf(w0+s) - p @ wuf(w0+x)
# u(w0) - E[u(w0-b+x) = 0
def notbuy_buy(b, w0, x, p):
    return wuf(w0) - p @ wuf(w0-b+x)

PISP = {}
PIBP = {}
# Compute the PISP and PIBP for different w0
for w0 in [10, 100, 1000, 10000]:
    sol = root_scalar(sell_notsell, args=(w0, x, p), bracket=[1e-10, w0])
    if sol.flag=='converged':
        PISP[w0] = sol.root
    else:
        PISP[w0] = None
          
    sol = root_scalar(notbuy_buy, args=(w0, x, p), bracket=[1e-10, w0])
    if sol.flag=='converged':
      PIBP[w0] = sol.root
    else:
      PIBP[w0] = None

for w0 in [10, 100, 1000, 10000]:
    print(f"w0 = {w0}")
    print(f"  PISP = {PISP[w0]:.6f}")
    print(f"  PIBP = {PIBP[w0]:.6f}")

