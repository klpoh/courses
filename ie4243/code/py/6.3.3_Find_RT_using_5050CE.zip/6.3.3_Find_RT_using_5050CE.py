# -*- coding: utf-8 -*-
# 6.3.3 Find RT using 50-50 CE method 
import numpy as np
from scipy.optimize import root_scalar

# Define the equation to solve
# (1-np.exp(-(CE50-L)/rt))/(1-np.exp(-(H-L)/rt)) - 0.5 = 0
def fun(rt, L, H, CE50):
    return (1-np.exp(-(CE50-L)/rt))/(1-np.exp(-(H-L)/rt)) - 0.5

# 1. Risk Averse case
L, H, CE50 = 0, 100, 34

sol = root_scalar(fun, args=(L, H, CE50), bracket=[1, 100])
if sol.flag=='converged':
    print(f"  Risk Tolerance = {sol.root:.6f}")
else:
    print("Error: try changing the bracket")

# 2 Risk Seeking case
L, H, CE50 = 0, 100, 65
sol = root_scalar(fun, args=(L, H, CE50), bracket=[-100, -1])
if sol.flag=='converged':
    print(f"  Risk Tolerance = {sol.root:.6f}")
else:
    print("Error: try changing the bracket")
