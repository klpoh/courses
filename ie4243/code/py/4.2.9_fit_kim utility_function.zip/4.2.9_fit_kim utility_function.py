# -*- coding: utf-8 -*-
# Fitting an equation to Kim's Utility Function (2026 04 22)
import numpy as np
from scipy.optimize import curve_fit
import matplotlib.pyplot as plt

# Data to fit
xdata = [0, 20, 40, 50, 90, 100]
udata = [0, 0.32, 0.57, 0.67, 0.95, 1]


# Visualize the data
fig, ax = plt.subplots()
ax.scatter(xdata, udata, label='data')
ax.legend()
ax.grid()
plt.show()


# Constraint u(0)=0 -> a = b
# fit 2 parameters a and r 
func = lambda x, a, r : a*(1 - np.exp(-x/r))
popt, _ = curve_fit(func, xdata, udata)
print("Fitted parameters:")
print(f"  a = {popt[0]:.2f}")
print(f"  r = {popt[1]:.2f}")

# The fitted utility function is conveniently written as
#       u(x) = (4/3)*(1 - 2**(-x/50))
fig, ax = plt.subplots()
ax.scatter(xdata, udata, label='data')
x = np.linspace(0, 100, 101)
ufit = (4/3)*(1 - 2**(-x/50))
ax.plot(x, ufit, 'r-', label='fitted')
ax.set_title('u(x) = 4/3 (1 -2^(-x/50)')
ax.legend()
ax.grid()
plt.show()
