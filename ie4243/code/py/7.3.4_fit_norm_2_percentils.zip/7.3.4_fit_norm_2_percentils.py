# -*- coding: utf-8 -*-
# 7.3.4 Fit normal distribution to 2 percentile values
import numpy as np
from scipy.stats import norm
import matplotlib.pyplot as plt

# Percentile data
x = np.array([100, 352.27])
p = np.array([0.2, 0.9])

# Compute mu and sigma
z = norm.ppf(p)
sigma = (x[1]-x[0])/(z[1]-z[0])
mu = x[0] - z[0]*sigma
print(f"mu = {mu:.2f}")
print(f"Sigma = {sigma:.2f}")

# Plot the CDF of the fitted normal distribution
xmin = norm.ppf(0.01, loc=mu, scale=sigma)
xmax = norm.ppf(0.99, loc=mu, scale=sigma)
xp = np.linspace(xmin, xmax, 500)
yp = norm.cdf(xp, mu, sigma)

fig, ax = plt.subplots()
ax.plot(xp, yp, lw=2, color='blue',
        label=fr"$N({mu:.2f}, {sigma:.2f}^2)$")
ax.plot(x, p,'ro', ms=7)
ax.set_xlim(xmin,xmax)
ax.set_ylim(0,1)
ax.set_ylabel("F(x)")
ax.legend()
ax.grid()
plt.show()